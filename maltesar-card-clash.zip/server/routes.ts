import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { User, GameProfile, CardCollectionItem, Deck } from "../shared/schema";

// Add API endpoints for game functionality
export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // User authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password, email } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Create user
      const user = await storage.createUser({ username, password, email });
      
      // Create game profile
      const gameProfile = await storage.createGameProfile({
        user_id: user.id,
        player_name: username,
      });
      
      // Add starter cards
      await storage.addStarterCards(user.id);
      
      // Create default deck
      await storage.createDeck({
        user_id: user.id,
        name: "Starter Deck",
        character_id: null,
      });
      
      return res.status(201).json({ 
        message: "Registration successful",
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(500).json({ message: "Failed to register user" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Find user and verify password
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Create session
      req.session.userId = user.id;
      
      // Update last login
      await storage.updateLastLogin(user.id);
      
      return res.status(200).json({ 
        message: "Login successful",
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Failed to login" });
    }
  });
  
  app.post("/api/auth/logout", async (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      
      return res.status(200).json({ message: "Logout successful" });
    });
  });
  
  // Game profile routes
  app.get("/api/profile", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const gameProfile = await storage.getGameProfile(userId);
      if (!gameProfile) {
        return res.status(404).json({ message: "Game profile not found" });
      }
      
      return res.status(200).json(gameProfile);
    } catch (error) {
      console.error("Get profile error:", error);
      return res.status(500).json({ message: "Failed to get profile" });
    }
  });
  
  app.put("/api/profile", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { player_name, player_level, player_exp, gold, gems, tutorial_completed, story_progress, dungeon_progress } = req.body;
      
      const updatedProfile = await storage.updateGameProfile(userId, {
        player_name,
        player_level,
        player_exp,
        gold,
        gems,
        tutorial_completed,
        story_progress,
        dungeon_progress
      });
      
      return res.status(200).json(updatedProfile);
    } catch (error) {
      console.error("Update profile error:", error);
      return res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Card collection routes
  app.get("/api/cards", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const cards = await storage.getUserCards(userId);
      return res.status(200).json(cards);
    } catch (error) {
      console.error("Get cards error:", error);
      return res.status(500).json({ message: "Failed to get cards" });
    }
  });
  
  app.post("/api/cards", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { card_id } = req.body;
      const newCard = await storage.addCard(userId, card_id);
      
      return res.status(201).json(newCard);
    } catch (error) {
      console.error("Add card error:", error);
      return res.status(500).json({ message: "Failed to add card" });
    }
  });
  
  // Deck routes
  app.get("/api/decks", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const decks = await storage.getUserDecks(userId);
      return res.status(200).json(decks);
    } catch (error) {
      console.error("Get decks error:", error);
      return res.status(500).json({ message: "Failed to get decks" });
    }
  });
  
  app.post("/api/decks", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { name, character_id } = req.body;
      const newDeck = await storage.createDeck({ user_id: userId, name, character_id });
      
      return res.status(201).json(newDeck);
    } catch (error) {
      console.error("Create deck error:", error);
      return res.status(500).json({ message: "Failed to create deck" });
    }
  });
  
  app.put("/api/decks/:deckId/active", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const deckId = parseInt(req.params.deckId);
      const updatedDeck = await storage.setActiveDeck(userId, deckId);
      
      return res.status(200).json(updatedDeck);
    } catch (error) {
      console.error("Set active deck error:", error);
      return res.status(500).json({ message: "Failed to set active deck" });
    }
  });
  
  app.post("/api/decks/:deckId/cards", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const deckId = parseInt(req.params.deckId);
      const { card_collection_id } = req.body;
      
      const result = await storage.addCardToDeck(userId, deckId, card_collection_id);
      
      return res.status(200).json(result);
    } catch (error) {
      console.error("Add card to deck error:", error);
      return res.status(500).json({ message: "Failed to add card to deck" });
    }
  });
  
  app.delete("/api/decks/:deckId/cards/:cardId", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const deckId = parseInt(req.params.deckId);
      const cardId = parseInt(req.params.cardId);
      
      const result = await storage.removeCardFromDeck(userId, deckId, cardId);
      
      return res.status(200).json(result);
    } catch (error) {
      console.error("Remove card from deck error:", error);
      return res.status(500).json({ message: "Failed to remove card from deck" });
    }
  });
  
  // Gacha routes
  app.post("/api/gacha/pull", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { banner_type, pull_count } = req.body;
      
      // Get cost based on banner type and pull count
      let cost = 0;
      let currency_type = "gold";
      
      if (banner_type === "standard") {
        cost = 100 * pull_count;
        currency_type = "gold";
      } else if (banner_type === "premium") {
        cost = 10 * pull_count;
        currency_type = "gems";
      } else {
        return res.status(400).json({ message: "Invalid banner type" });
      }
      
      // Check if user can afford the pull
      const gameProfile = await storage.getGameProfile(userId);
      if (!gameProfile) {
        return res.status(404).json({ message: "Game profile not found" });
      }
      
      if (currency_type === "gold" && gameProfile.gold < cost) {
        return res.status(400).json({ message: "Not enough gold" });
      }
      
      if (currency_type === "gems" && gameProfile.gems < cost) {
        return res.status(400).json({ message: "Not enough gems" });
      }
      
      // Process pull - in a real implementation, this would include randomization logic
      const pullResults = await storage.processGachaPull(userId, banner_type, pull_count, cost, currency_type);
      
      return res.status(200).json(pullResults);
    } catch (error) {
      console.error("Gacha pull error:", error);
      return res.status(500).json({ message: "Failed to process gacha pull" });
    }
  });
  
  // Story progress routes
  app.get("/api/story", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const storyProgress = await storage.getStoryProgress(userId);
      return res.status(200).json(storyProgress);
    } catch (error) {
      console.error("Get story progress error:", error);
      return res.status(500).json({ message: "Failed to get story progress" });
    }
  });
  
  app.post("/api/story/:chapterId/complete", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const chapterId = req.params.chapterId;
      const { choices } = req.body;
      
      const result = await storage.completeStoryChapter(userId, chapterId, choices);
      return res.status(200).json(result);
    } catch (error) {
      console.error("Complete story chapter error:", error);
      return res.status(500).json({ message: "Failed to complete story chapter" });
    }
  });
  
  // Dungeon progress routes
  app.get("/api/dungeons", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const dungeonProgress = await storage.getDungeonProgress(userId);
      return res.status(200).json(dungeonProgress);
    } catch (error) {
      console.error("Get dungeon progress error:", error);
      return res.status(500).json({ message: "Failed to get dungeon progress" });
    }
  });
  
  app.post("/api/dungeons/:dungeonId/complete", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const dungeonId = req.params.dungeonId;
      
      const result = await storage.completeDungeon(userId, dungeonId);
      return res.status(200).json(result);
    } catch (error) {
      console.error("Complete dungeon error:", error);
      return res.status(500).json({ message: "Failed to complete dungeon" });
    }
  });
  
  return httpServer;
}
