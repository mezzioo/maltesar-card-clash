# Maltesar Card Clash - Trials of the Academy

A dynamic 2D card-based RPG game featuring collectible anime characters with an immersive turn-based combat system and engaging dungeon exploration mechanics.

## Running the Game Locally

```bash
# Install dependencies
npm install

# Start the development server
npm run dev
```

## Deployment Options

### Option 1: Deploy on Replit

1. Fork this project on Replit
2. Click the "Run" button to start the development server
3. Use the "Deploy" button to publish your game to the web

### Option 2: Deploy to Vercel

1. Download the `maltesar-vercel-deploy.zip` file
2. Extract the contents
3. Create a new project on Vercel and import the extracted folder
4. Vercel will automatically detect the Vite configuration and deploy your game

### Option 3: Deploy to GitHub Pages

1. Fork this repository on GitHub
2. Update the GitHub repository URL in the `deploy-to-gh-pages.sh` script
3. Run the script:
```bash
./deploy-to-gh-pages.sh
```
4. Your game will be deployed to the gh-pages branch of your repository

## Features

- 🎮 Turn-based card combat system
- 🏰 Dungeon exploration with events and rewards
- 📚 Engaging storyline set in a magical academy
- 🎴 Collectible characters and cards with unique abilities
- 🎲 Gacha summoning system with different rarities
- 👥 Guild system for player collaboration
- 🏆 Quest system with daily challenges and achievements

## Game Mechanics

- **Card Collection**: Collect different cards with unique effects
- **Deck Building**: Create strategic decks for different challenges
- **Character System**: Unlock characters with unique abilities and storylines
- **Progression System**: Level up characters and earn better rewards
- **Guild System**: Join or create guilds to collaborate with other players
- **Quest System**: Complete quests to earn rewards and unlock new content

## License

This project is licensed under the MIT License - see the LICENSE file for details.