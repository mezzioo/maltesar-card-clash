#!/bin/bash

# Build the project
npm run build

# Move to the build output directory
cd dist/public

# Create a .nojekyll file to prevent GitHub from using Jekyll
touch .nojekyll

# Create a simple CNAME file if you have a custom domain
# echo "yourdomain.com" > CNAME

# Initialize git
git init
git add -A
git commit -m "Deploy to GitHub Pages"

# Force push to the gh-pages branch
git push -f https://github.com/yourusername/maltesar-card-clash.git master:gh-pages

# Go back to the project root
cd ../..