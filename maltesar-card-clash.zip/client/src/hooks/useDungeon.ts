import { useState, useCallback } from "react";
import { useGameState } from "@/lib/stores/useGameState";
import { useBattleSystem } from "@/lib/stores/useBattleSystem";
import { dungeons, getDungeonById, getBattleById, getEnemyById } from "@/data/dungeons";
import { getCharacterById } from "@/data/characters";

export function useDungeon() {
  const [selectedDungeonId, setSelectedDungeonId] = useState<number | null>(null);
  const [selectedBattleId, setSelectedBattleId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const { level, unlockedDungeons, completedBattles } = useGameState();
  const { setupBattle } = useBattleSystem();
  
  // Get available dungeons based on player level and progression
  const getAvailableDungeons = useCallback(() => {
    return dungeons.filter(dungeon => 
      dungeon.requiredLevel <= level && unlockedDungeons.includes(dungeon.id)
    );
  }, [level, unlockedDungeons]);
  
  // Check if a specific battle is completed
  const isBattleCompleted = useCallback((dungeonId: number, battleId: number) => {
    const battleKey = `${dungeonId}_${battleId}`;
    return completedBattles.includes(parseInt(battleKey));
  }, [completedBattles]);
  
  // Get all battles for a dungeon
  const getDungeonBattles = useCallback((dungeonId: number) => {
    const dungeon = getDungeonById(dungeonId);
    if (!dungeon) return [];
    
    return dungeon.battles.map(battle => ({
      ...battle,
      completed: isBattleCompleted(dungeonId, battle.id)
    }));
  }, [isBattleCompleted]);
  
  // Start a battle
  const startBattle = useCallback((dungeonId: number, battleId: number) => {
    setIsLoading(true);
    
    const battle = getBattleById(dungeonId, battleId);
    if (!battle) {
      setIsLoading(false);
      return false;
    }
    
    // Create enemy team
    const enemyTeam = battle.enemies.map(enemyId => {
      const enemyData = getEnemyById(enemyId);
      if (!enemyData) return null;
      
      return {
        id: `enemy_${enemyId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        characterId: enemyId,
        name: enemyData.name,
        hp: enemyData.hp,
        maxHp: enemyData.hp,
        energy: 3,
        maxEnergy: 3,
        attack: enemyData.attack,
        defense: enemyData.defense,
        cards: [],
        hand: [],
        effects: []
      };
    }).filter(enemy => enemy !== null) as any[];
    
    // Setup battle
    setupBattle(dungeonId, battleId, enemyTeam);
    
    setIsLoading(false);
    return true;
  }, [setupBattle]);
  
  // Check if all battles in a dungeon are completed
  const isDungeonCompleted = useCallback((dungeonId: number) => {
    const dungeon = getDungeonById(dungeonId);
    if (!dungeon) return false;
    
    return dungeon.battles.every(battle => 
      isBattleCompleted(dungeonId, battle.id)
    );
  }, [isBattleCompleted]);
  
  return {
    selectedDungeonId,
    setSelectedDungeonId,
    selectedBattleId,
    setSelectedBattleId,
    isLoading,
    getAvailableDungeons,
    getDungeonBattles,
    startBattle,
    isBattleCompleted,
    isDungeonCompleted
  };
}
