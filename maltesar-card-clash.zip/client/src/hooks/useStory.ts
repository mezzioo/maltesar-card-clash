import { useState, useCallback, useEffect } from "react";
import { useGameState } from "@/lib/stores/useGameState";
import { getStoryNodeById, getNextStoryNode } from "@/data/story";
import { useCardCollection } from "@/lib/stores/useCardCollection";
import { toast } from "sonner";

export function useStory() {
  const [currentNodeId, setCurrentNodeId] = useState<number>(1);
  const [storyText, setStoryText] = useState<string[]>([]);
  const [storyTitle, setStoryTitle] = useState<string>("");
  const [storyChoices, setStoryChoices] = useState<{text: string, nextId: number}[]>([]);
  const [storyImage, setStoryImage] = useState<string | undefined>(undefined);
  const [textIndex, setTextIndex] = useState(0);
  const [isChoiceVisible, setIsChoiceVisible] = useState(false);
  const [typewriterText, setTypewriterText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  
  const { 
    currentStoryId, completeStory, addExp, addGold, unlockDungeon, 
    addGems, unlockCharacter 
  } = useGameState();
  
  const { addCard } = useCardCollection();
  
  // Initialize story based on player's progress
  useEffect(() => {
    setCurrentNodeId(currentStoryId);
  }, [currentStoryId]);
  
  // Load story node
  const loadStoryNode = useCallback((nodeId: number) => {
    const node = getStoryNodeById(nodeId);
    
    if (node) {
      setStoryTitle(node.title);
      setStoryText(node.text);
      setStoryChoices(node.choices || []);
      setStoryImage(node.image);
      setTextIndex(0);
      setIsChoiceVisible(false);
      setTypewriterText("");
      setIsTyping(true);
    }
  }, []);
  
  // Effect to load story node when currentNodeId changes
  useEffect(() => {
    loadStoryNode(currentNodeId);
  }, [currentNodeId, loadStoryNode]);
  
  // Handle typewriter effect
  useEffect(() => {
    if (storyText.length === 0) return;
    
    const currentTextToType = storyText[textIndex];
    let charIndex = 0;
    
    if (isTyping) {
      const typingInterval = setInterval(() => {
        if (charIndex <= currentTextToType.length) {
          setTypewriterText(currentTextToType.substring(0, charIndex));
          charIndex++;
        } else {
          setIsTyping(false);
          clearInterval(typingInterval);
        }
      }, 30);
      
      return () => clearInterval(typingInterval);
    }
  }, [isTyping, storyText, textIndex]);
  
  // Handle advancing text
  const advanceText = useCallback(() => {
    // If currently typing, finish the text immediately
    if (isTyping) {
      setTypewriterText(storyText[textIndex]);
      setIsTyping(false);
      return;
    }
    
    // If not at the end of the text array, advance to next text
    if (textIndex < storyText.length - 1) {
      setTextIndex(prevIndex => prevIndex + 1);
      setTypewriterText("");
      setIsTyping(true);
    } else {
      // At the end of text, show choices
      setIsChoiceVisible(true);
    }
  }, [isTyping, storyText, textIndex]);
  
  // Handle making a choice
  const makeChoice = useCallback((nextNodeId: number) => {
    const currentNode = getStoryNodeById(currentNodeId);
    
    // Process rewards from current node if they exist
    if (currentNode?.rewards) {
      const { characterId, gold, exp, cardId, gems } = currentNode.rewards;
      
      let rewardMessage = "Rewards: ";
      let hasRewards = false;
      
      if (characterId) {
        unlockCharacter(characterId);
        rewardMessage += `New character! `;
        hasRewards = true;
      }
      
      if (cardId) {
        addCard(cardId, 0); // 0 is a placeholder, card system will handle correct assignment
        rewardMessage += `New card! `;
        hasRewards = true;
      }
      
      if (gold) {
        addGold(gold);
        rewardMessage += `${gold} gold! `;
        hasRewards = true;
      }
      
      if (exp) {
        addExp(exp);
        rewardMessage += `${exp} exp! `;
        hasRewards = true;
      }
      
      if (gems) {
        addGems(gems);
        rewardMessage += `${gems} gems! `;
        hasRewards = true;
      }
      
      if (hasRewards) {
        toast.success(rewardMessage);
      }
    }
    
    // Unlock dungeon if specified
    if (currentNode?.unlockDungeon) {
      unlockDungeon(currentNode.unlockDungeon);
      toast.success(`Unlocked new dungeon: ${currentNode.unlockDungeon}!`);
    }
    
    // Mark current story node as completed
    completeStory(currentNodeId);
    
    // Advance to next node
    setCurrentNodeId(nextNodeId);
  }, [currentNodeId, completeStory, addExp, addGold, unlockDungeon, addGems, unlockCharacter, addCard]);
  
  return {
    currentNodeId,
    storyTitle,
    typewriterText,
    isTyping,
    isChoiceVisible,
    storyChoices,
    storyImage,
    advanceText,
    makeChoice,
    hasMoreStory: !!getNextStoryNode(currentNodeId)
  };
}
