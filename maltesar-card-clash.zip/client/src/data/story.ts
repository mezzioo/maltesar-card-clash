export interface DialogueLine {
  speaker: string;
  text: string;
  portrait?: string; // SVG string
  choices?: {
    text: string;
    nextLineId?: string;
    effect?: {
      type: string;
      value: number;
    };
  }[];
}

export interface StoryChapter {
  id: string;
  title: string;
  description: string;
  requiredLevel: number;
  prerequisite?: {
    type: "chapter" | "dungeon";
    id: string;
  };
  dialogue: DialogueLine[];
  reward?: {
    exp?: number;
    currency?: number;
    cards?: string[];
    unlockCharacter?: string;
  };
}

// Basic SVG portraits for story characters
const portraitSVGs = {
  player: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#FFCCBC"/>
    <rect x="10" y="6" width="12" height="6" fill="#795548"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#2196F3"/>
  </svg>`,
  
  hamid: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#F5D393"/>
    <rect x="10" y="6" width="12" height="6" fill="#5D4037"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#03A9F4"/>
  </svg>`,
  
  soraya: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#FFCC80"/>
    <path d="M10 6 L22 6 L16 2 Z" fill="#8D6E63"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#4CAF50"/>
  </svg>`,
  
  polycarp: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#E0E0E0"/>
    <ellipse cx="16" cy="6" rx="8" ry="3" fill="#9E9E9E"/>
    <rect x="12" y="12" width="8" height="2" fill="#616161"/>
    <rect x="12" y="16" width="8" height="1" fill="#616161"/>
    <rect x="8" y="22" width="16" height="4" fill="#3F51B5"/>
  </svg>`,
  
  emmanuel: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#795548"/>
    <rect x="9" y="4" width="14" height="4" fill="#212121"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#FFFFFF"/>
    <rect x="18" y="12" width="2" height="2" fill="#FFFFFF"/>
    <rect x="8" y="22" width="16" height="4" fill="#4CAF50"/>
  </svg>`,
  
  crashout: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="6" width="16" height="20" fill="#424242"/>
    <rect x="10" y="8" width="12" height="6" fill="#212121"/>
    <rect x="12" y="16" width="8" height="2" fill="#FF5252"/>
    <rect x="10" y="12" width="3" height="3" fill="#F44336"/>
    <rect x="19" y="12" width="3" height="3" fill="#F44336"/>
    <rect x="6" y="22" width="20" height="4" fill="#212121"/>
  </svg>`,
  
  narrator: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="8" width="28" height="16" rx="4" fill="#CFD8DC"/>
    <text x="16" y="19" font-family="Arial" font-size="10" text-anchor="middle" fill="#37474F">N</text>
  </svg>`
};

export const storyChapters: StoryChapter[] = [
  {
    id: "chapter-1",
    title: "Awakening",
    description: "A mysterious beginning at the Maltesar Academy.",
    requiredLevel: 1,
    dialogue: [
      {
        speaker: "Narrator",
        text: "In a world ravaged by chaos and destruction, the Maltesar Academy stands as the final beacon of hope for humanity.",
        portrait: portraitSVGs.narrator
      },
      {
        speaker: "Narrator",
        text: "You awaken from a deep sleep, disoriented. Sirens wail through the halls, and people are running in panic.",
        portrait: portraitSVGs.narrator
      },
      {
        speaker: "???",
        text: "Hey! You! Get up! We need to move NOW!",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "What... what's happening?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "???",
        text: "The Crashouts are attacking! I'm Hamid, by the way. Are you a new student? I've never seen you before.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "I... I'm not sure. My memory is foggy. What are Crashouts?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "You don't know? They're monstrous creatures that seek to destroy the Academy and everything we've built. They attack regularly.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Hamid",
        text: "The Maltesar Academy is humanity's last sanctuary - a floating fortress of knowledge hovering above a broken world.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "Floating? Above the world? That sounds impossible.",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "Many things that seemed impossible became necessary for survival. Look, we don't have time for a history lesson now.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Hamid",
        text: "Take these cards. They're how we defend ourselves here.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Hamid",
        text: "Each card contains magical energy that you can channel into attacks, defenses, and special abilities.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "Cards? As weapons? That's...",
        portrait: portraitSVGs.player,
        choices: [
          {
            text: "► TAKE THE CARDS ◄",
            effect: {
              type: "cards",
              value: 2
            }
          }
        ]
      },
      {
        speaker: "You",
        text: "These are glowing! I can feel power emanating from them!",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "That's your connection to the cards forming. Each student has different affinities. These basic cards will help you get started.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Hamid",
        text: "I've given you 'Basic Strike' and 'Defensive Stance' - the fundamentals every student learns first.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Crashout Minion",
        text: "GRAAAAAAHHH!",
        portrait: portraitSVGs.crashout
      },
      {
        speaker: "Hamid",
        text: "Look out! They've found us! Quick, use the cards! Focus on the energy and release it!",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "How do I—",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "No time to explain! Trust your instincts! Channel the card's power now!",
        portrait: portraitSVGs.hamid
      }
    ],
    reward: {
      exp: 50,
      currency: 100,
      cards: ["basic-strike", "defensive-stance"]
    }
  },
  {
    id: "chapter-2",
    title: "Introducing the Academy",
    description: "Hamid shows you around the Academy and explains its importance.",
    requiredLevel: 2,
    prerequisite: {
      type: "chapter",
      id: "chapter-1"
    },
    dialogue: [
      {
        speaker: "Hamid",
        text: "Good job on your first battle! You're a natural with those cards.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "Thanks, but I still don't understand what's happening. What is this Academy?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "The Maltesar Academy is the last bastion of knowledge in our world. After the Great Collapse, this is all we have left.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Hamid",
        text: "The pyramid we're standing on is actually floating above the broken world below.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "A floating pyramid? That's impossible!",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "Many things that seem impossible are reality here. Come, let me introduce you to one of our instructors.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Mr. Polycarp",
        text: "Ah, a new student! Welcome to the Academy. I am Mr. Polycarp, instructor of defensive arts.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "Mr. Polycarp",
        text: "These are difficult times. The Crashouts grow bolder with each attack. We must prepare you quickly.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "You",
        text: "What exactly are the Crashouts? Why are they attacking us?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Mr. Polycarp",
        text: "They are manifestations of chaos and destruction. They seek to destroy the last remnants of human knowledge—us.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "Mr. Polycarp",
        text: "Take this defensive card. It will help you in the battles to come.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "You",
        text: "Thank you, sir. I'll use it well.",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "Let's continue our tour. There's much more to see.",
        portrait: portraitSVGs.hamid
      }
    ],
    reward: {
      exp: 75,
      currency: 150,
      cards: ["shield-wall"]
    }
  },
  {
    id: "chapter-3",
    title: "Strategic Allies",
    description: "You meet Soraya, a brilliant strategist, who teaches you about card combinations.",
    requiredLevel: 3,
    prerequisite: {
      type: "chapter",
      id: "chapter-2"
    },
    dialogue: [
      {
        speaker: "Hamid",
        text: "There's someone I want you to meet. She's the best strategist in our class.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Soraya",
        text: "So you're the new student everyone's talking about. I'm Soraya.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "You",
        text: "Nice to meet you, Soraya.",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Soraya",
        text: "Hamid tells me you're good with cards, but do you understand combinations?",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "You",
        text: "Combinations?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Soraya",
        text: "When certain cards are played in sequence, they create powerful combo effects. It's not just about the cards you have, but how you play them.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "Soraya",
        text: "For example, playing 'Power Strike' followed by 'Combo Attack' will deal massive damage.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "Soraya",
        text: "Here, take this card. It's one of my favorites for planning ahead.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "You",
        text: "Thank you. I'll study how to use it effectively.",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Soraya",
        text: "You'll need to. The attacks are getting worse, and we've heard rumors of Mr. Crashout himself leading the next one.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "You",
        text: "Mr. Crashout?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Hamid",
        text: "The leader of the Crashouts. He's incredibly powerful. No student has ever defeated him.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Soraya",
        text: "But with the right strategy, anything is possible. Let's train together.",
        portrait: portraitSVGs.soraya
      }
    ],
    reward: {
      exp: 100,
      currency: 200,
      cards: ["strategic-planning"]
    }
  },
  {
    id: "chapter-4",
    title: "The Secret of the Academy",
    description: "Mr. Emmanuel reveals more about the origins of the Academy and the Crashouts.",
    requiredLevel: 5,
    prerequisite: {
      type: "chapter",
      id: "chapter-3"
    },
    dialogue: [
      {
        speaker: "Mr. Emmanuel",
        text: "You've been making remarkable progress. It's time you learned more about our history.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "You",
        text: "I've been wondering about that. How did the Academy come to be on a floating pyramid?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Mr. Emmanuel",
        text: "Long ago, when the world began to fall apart, our founders used ancient knowledge to create this sanctuary.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "Mr. Emmanuel",
        text: "The Maltesars, as they were called, combined science and mystical arts to lift this pyramid above the destruction.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "You",
        text: "Maltesars? Is that where the name 'Maltesar Card Clash' comes from?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Mr. Emmanuel",
        text: "Indeed. The card system we use was their creation—a way to harness and focus energy without depleting our limited resources.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "Mr. Emmanuel",
        text: "But there's something troubling you should know. The Crashouts... they weren't always our enemies.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "You",
        text: "What do you mean?",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Mr. Emmanuel",
        text: "They were once Maltesars who disagreed with isolating ourselves above the world. They believed we should face the chaos head-on.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "Mr. Emmanuel",
        text: "A terrible accident during an experiment transformed them, warping their bodies and minds. Now they seek to bring us down to the broken world.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "You",
        text: "So they were once like us...",
        portrait: portraitSVGs.player,
        choices: [
          {
            text: "Can they be saved?",
            effect: {
              type: "continue",
              value: 1
            }
          },
          {
            text: "They must be stopped at all costs.",
            effect: {
              type: "continue",
              value: 2
            }
          }
        ]
      },
      {
        speaker: "Mr. Emmanuel",
        text: "That's a question we've been asking for generations. Some believe there's a way to reverse their transformation.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "Mr. Emmanuel",
        text: "Others believe they're too far gone. The truth may lie somewhere in the Academy's deepest archives.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "Mr. Emmanuel",
        text: "Take this card. It represents the balance we must maintain—between knowledge and action, preservation and progress.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "You",
        text: "Thank you, Mr. Emmanuel. I have much to think about.",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Mr. Emmanuel",
        text: "Indeed. And little time to do so. Prepare yourself—the Crashouts grow stronger with each attack.",
        portrait: portraitSVGs.emmanuel
      }
    ],
    reward: {
      exp: 150,
      currency: 300,
      cards: ["wisdom-share"]
    }
  },
  {
    id: "chapter-5",
    title: "The Final Battle Approaches",
    description: "Preparations for the final confrontation with Mr. Crashout.",
    requiredLevel: 8,
    prerequisite: {
      type: "dungeon",
      id: "dungeon-3"
    },
    dialogue: [
      {
        speaker: "Hamid",
        text: "The scouts have returned. Mr. Crashout is gathering his forces at the Academy Peak.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "Soraya",
        text: "This is it. The attack we've been preparing for.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "Mr. Polycarp",
        text: "Students, you've learned all we can teach you. Now you must apply that knowledge.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "You",
        text: "I'm ready. We've come too far to back down now.",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Mr. Emmanuel",
        text: "Remember what you've learned about the Crashouts' origins. It may be important in the coming battle.",
        portrait: portraitSVGs.emmanuel
      },
      {
        speaker: "Soraya",
        text: "I've analyzed all possible approaches. Our best chance is to fight through their defenses and confront Mr. Crashout directly.",
        portrait: portraitSVGs.soraya
      },
      {
        speaker: "Hamid",
        text: "I'll stand with you. My defensive cards will keep us protected.",
        portrait: portraitSVGs.hamid
      },
      {
        speaker: "You",
        text: "Together, we can do this. For the Academy!",
        portrait: portraitSVGs.player
      },
      {
        speaker: "Everyone",
        text: "For the Academy!",
        portrait: portraitSVGs.narrator
      },
      {
        speaker: "Mr. Polycarp",
        text: "Take this ultimate card. It's been passed down through generations, saved for a moment like this.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "Mr. Polycarp",
        text: "Use it wisely. Its power can only be unleashed once.",
        portrait: portraitSVGs.polycarp
      },
      {
        speaker: "You",
        text: "Thank you, everyone. Let's end this.",
        portrait: portraitSVGs.player
      }
    ],
    reward: {
      exp: 200,
      currency: 500,
      cards: ["ultimate-defense"]
    }
  }
];

// Helper functions
export const getChapterById = (id: string): StoryChapter | undefined => {
  return storyChapters.find(chapter => chapter.id === id);
};

export const getAvailableChapters = (playerLevel: number, completedChapters: string[], completedDungeons: string[]): StoryChapter[] => {
  return storyChapters.filter(chapter => {
    // Check level requirement
    if (playerLevel < chapter.requiredLevel) {
      return false;
    }
    
    // Check prerequisite chapter
    if (chapter.prerequisite?.type === "chapter") {
      if (!completedChapters.includes(chapter.prerequisite.id)) {
        return false;
      }
    }
    
    // Check prerequisite dungeon
    if (chapter.prerequisite?.type === "dungeon") {
      if (!completedDungeons.includes(chapter.prerequisite.id)) {
        return false;
      }
    }
    
    return true;
  });
};
