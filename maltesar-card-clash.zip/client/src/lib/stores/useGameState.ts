import { create } from "zustand";
import { persist } from "zustand/middleware";

export type GameScreen = 
  | "title" 
  | "menu" 
  | "battle" 
  | "collection" 
  | "dungeon" 
  | "gacha" 
  | "shop" 
  | "story"
  | "settings"
  | "quests"
  | "guild";

export type Rarity = "Common" | "Rare" | "Epic" | "Legendary";

export type GameState = {
  // Player info
  playerName: string;
  playerLevel: number;
  playerExp: number;
  expToNextLevel: number;
  
  // Game progress
  tutorialCompleted: boolean;
  storyProgress: number;
  dungeonProgress: number;
  unlockedCharacters: string[];
  
  // UI state
  currentScreen: GameScreen;
  isLoading: boolean;
  menuOpen: boolean;
  
  // Actions
  setPlayerName: (name: string) => void;
  gainExp: (amount: number) => void;
  levelUp: () => void;
  completeStoryChapter: (chapter: number) => void;
  completeDungeon: (dungeon: number) => void;
  unlockCharacter: (characterId: string) => void;
  setCurrentScreen: (screen: GameScreen) => void;
  setLoading: (loading: boolean) => void;
  toggleMenu: () => void;
  completeTutorial: () => void;
};

export const useGameState = create<GameState>()(
  persist(
    (set, get) => ({
      // Player info
      playerName: "Player",
      playerLevel: 1,
      playerExp: 0,
      expToNextLevel: 100,
      
      // Game progress
      tutorialCompleted: true, // Set to true by default to enable all features
      storyProgress: 0,
      dungeonProgress: 0,
      unlockedCharacters: ["hamid"], // Start with only Hamid, other characters must be obtained through gacha
      
      // UI state
      currentScreen: "title",
      isLoading: false,
      menuOpen: false,
      
      // Actions
      setPlayerName: (name: string) => set({ playerName: name }),
      
      gainExp: (amount: number) => {
        const { playerExp, expToNextLevel, playerLevel } = get();
        const newExp = playerExp + amount;
        
        if (newExp >= expToNextLevel) {
          // Level up
          set({
            playerExp: newExp - expToNextLevel,
            playerLevel: playerLevel + 1,
            expToNextLevel: Math.floor(expToNextLevel * 1.5)
          });
        } else {
          set({ playerExp: newExp });
        }
      },
      
      levelUp: () => {
        const { playerLevel, expToNextLevel } = get();
        set({
          playerLevel: playerLevel + 1,
          playerExp: 0,
          expToNextLevel: Math.floor(expToNextLevel * 1.5)
        });
      },
      
      completeStoryChapter: (chapter: number) => {
        const { storyProgress } = get();
        if (chapter > storyProgress) {
          set({ storyProgress: chapter });
        }
      },
      
      completeDungeon: (dungeon: number) => {
        const { dungeonProgress } = get();
        if (dungeon > dungeonProgress) {
          set({ dungeonProgress: dungeon });
        }
      },
      
      unlockCharacter: (characterId: string) => {
        const { unlockedCharacters } = get();
        if (!unlockedCharacters.includes(characterId)) {
          set({ unlockedCharacters: [...unlockedCharacters, characterId] });
        }
      },
      
      setCurrentScreen: (screen: GameScreen) => set({ currentScreen: screen }),
      
      setLoading: (loading: boolean) => set({ isLoading: loading }),
      
      toggleMenu: () => set((state) => ({ menuOpen: !state.menuOpen })),
      
      completeTutorial: () => set({ tutorialCompleted: true })
    }),
    {
      name: "maltesar-game-state"
    }
  )
);
