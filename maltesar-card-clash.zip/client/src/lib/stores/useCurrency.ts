import { create } from "zustand";
import { persist } from "zustand/middleware";

// Function to generate shop items
const generateShopItems = (): ShopItem[] => {
  // For simplicity, we'll just create a few dummy items
  return [
    {
      id: "card-fire-blast",
      name: "Fire Blast Card",
      description: "A powerful fire attack card",
      cost: 500,
      currencyType: "gold",
      type: "card",
      itemId: "fire-blast",
      available: true
    },
    {
      id: "card-ice-shield",
      name: "Ice Shield Card",
      description: "A defensive ice shield card",
      cost: 750,
      currencyType: "gold",
      type: "card",
      itemId: "ice-shield",
      available: true
    },
    {
      id: "character-idris",
      name: "Idris Character",
      description: "A powerful mage character",
      cost: 50,
      currencyType: "gems",
      type: "character",
      itemId: "idris",
      available: true
    }
  ];
};

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  cost: number;
  currencyType: "gold" | "gems";
  type: "card" | "character" | "item";
  itemId: string;
  available: boolean;
}

export interface CurrencyState {
  gold: number;
  gems: number;
  purchasedItems: string[];
  
  // Currency actions
  addGold: (amount: number) => void;
  addGems: (amount: number) => void;
  spendGold: (amount: number) => boolean;
  spendGems: (amount: number) => boolean;
  addCurrency: (amount: number, type: "gold" | "gems") => void;
  spendCurrency: (amount: number, type: "gold" | "gems") => boolean;
  
  // Shop functionality
  purchaseItem: (itemId: string) => { success: boolean; message: string };
  hasPurchased: (itemId: string) => boolean;
  
  // Helper methods
  hasEnoughGold: (amount: number) => boolean;
  hasEnoughGems: (amount: number) => boolean;
  reset: () => void;
}

export const useCurrency = create<CurrencyState>()(
  persist(
    (set, get) => ({
      gold: 5000, // Start with 5000 gold
      gems: 1000, // Start with 1000 gems
      purchasedItems: [], // Track purchased items
      
      // Add gold to the player's balance
      addGold: (amount: number) => {
        if (amount <= 0) return;
        set(state => ({ gold: state.gold + amount }));
      },
      
      // Add gems to the player's balance
      addGems: (amount: number) => {
        if (amount <= 0) return;
        set(state => ({ gems: state.gems + amount }));
      },
      
      // Generic method to add currency of a specific type
      addCurrency: (amount: number, type: "gold" | "gems") => {
        if (type === "gold") {
          get().addGold(amount);
        } else {
          get().addGems(amount);
        }
      },
      
      // Spend gold if the player has enough
      spendGold: (amount: number) => {
        if (amount <= 0) return true;
        
        const { gold } = get();
        if (gold < amount) return false;
        
        set(state => ({ gold: state.gold - amount }));
        return true;
      },
      
      // Spend gems if the player has enough
      spendGems: (amount: number) => {
        if (amount <= 0) return true;
        
        const { gems } = get();
        if (gems < amount) return false;
        
        set(state => ({ gems: state.gems - amount }));
        return true;
      },
      
      // Generic method to spend currency of a specific type
      spendCurrency: (amount: number, type: "gold" | "gems") => {
        return type === "gold" 
          ? get().spendGold(amount) 
          : get().spendGems(amount);
      },
      
      // Purchase an item from the shop
      purchaseItem: (itemId: string) => {
        // In a real app, we would fetch the item details from an API
        // For now, we'll use a simple approach
        
        // Since we can't reference the function defined above directly,
        // we'll define a simple approach here
        const findItem = (id: string): ShopItem | undefined => {
          const items: ShopItem[] = [
            {
              id: "card-fire-blast",
              name: "Fire Blast Card",
              description: "A powerful fire attack card",
              cost: 500,
              currencyType: "gold",
              type: "card",
              itemId: "fire-blast",
              available: true
            },
            {
              id: "card-ice-shield",
              name: "Ice Shield Card",
              description: "A defensive ice shield card",
              cost: 750,
              currencyType: "gold",
              type: "card",
              itemId: "ice-shield",
              available: true
            },
            {
              id: "character-idris",
              name: "Idris Character",
              description: "A powerful mage character",
              cost: 50,
              currencyType: "gems",
              type: "character",
              itemId: "idris",
              available: true
            }
          ];
          return items.find(item => item.id === id);
        };
        
        const item = findItem(itemId);
        
        if (!item) {
          return { 
            success: false, 
            message: "Item not found"
          };
        }
        
        // Check if already purchased
        if (get().hasPurchased(itemId)) {
          return { 
            success: false, 
            message: "Item already owned"
          };
        }
        
        // Try to spend the currency
        const success = get().spendCurrency(item.cost, item.currencyType);
        
        if (success) {
          // Add to purchased items
          set(state => ({ 
            purchasedItems: [...state.purchasedItems, itemId]
          }));
          
          return { 
            success: true, 
            message: `Successfully purchased ${item.name}`
          };
        } else {
          return { 
            success: false, 
            message: `Not enough ${item.currencyType} to purchase this item`
          };
        }
      },
      
      // Check if an item has been purchased
      hasPurchased: (itemId: string) => {
        return get().purchasedItems.includes(itemId);
      },
      
      // Check if the player has enough gold
      hasEnoughGold: (amount: number) => {
        return get().gold >= amount;
      },
      
      // Check if the player has enough gems
      hasEnoughGems: (amount: number) => {
        return get().gems >= amount;
      },
      
      // Reset currency to initial values
      reset: () => {
        set({ 
          gold: 5000, 
          gems: 1000,
          purchasedItems: []
        });
      }
    }),
    {
      name: "maltesar-currency-storage"
    }
  )
);