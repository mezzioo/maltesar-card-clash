import { create } from "zustand";
import { persist } from "zustand/middleware";
import { cards, characterCards, CardType } from "../../data/cards";
import { characters, Character } from "../../data/characters";
import { Rarity } from "./useGameState";

export interface PlayerCard {
  id: string;
  cardId: string;
  level: number;
  exp: number;
  inDeck: boolean;
}

export interface Deck {
  id: string;
  name: string;
  cards: string[]; // Array of playerCard ids
  characterId: string | null;
}

interface CardCollectionState {
  // Player's collected cards
  playerCards: PlayerCard[];
  
  // Player's decks
  decks: Deck[];
  activeDeckId: string;
  
  // Card actions
  addCard: (cardId: string) => void;
  removeCard: (playerCardId: string) => void;
  levelUpCard: (playerCardId: string) => void;
  
  // Deck actions
  createDeck: (name: string, characterId: string | null) => void;
  removeDeck: (deckId: string) => void;
  setActiveDeck: (deckId: string) => void;
  addCardToDeck: (deckId: string, playerCardId: string) => void;
  removeCardFromDeck: (deckId: string, playerCardId: string) => void;
  
  // Utility functions
  getCardById: (playerCardId: string) => PlayerCard | undefined;
  getCardDetails: (playerCardId: string) => CardType | undefined;
  getActiveCards: () => PlayerCard[];
  getCardsByCharacter: (characterId: string) => PlayerCard[];
  getDeckByID: (deckId: string) => Deck | undefined;
  getActiveDeck: () => Deck | undefined;
}

// Generate a unique ID
const generateId = () => Math.random().toString(36).substring(2, 15);

export const useCardCollection = create<CardCollectionState>()(
  persist(
    (set, get) => ({
      playerCards: [
        // Initialize with starter cards
        {
          id: "starter-card-1",
          cardId: "basic-attack",
          level: 1,
          exp: 0,
          inDeck: true
        },
        {
          id: "starter-card-2",
          cardId: "basic-defense",
          level: 1,
          exp: 0,
          inDeck: true
        },
        {
          id: "starter-card-3",
          cardId: "basic-heal",
          level: 1,
          exp: 0,
          inDeck: true
        },
        {
          id: "starter-card-4",
          cardId: "power-up",
          level: 1,
          exp: 0,
          inDeck: true
        },
        {
          id: "starter-card-5",
          cardId: "critical-strike",
          level: 1,
          exp: 0,
          inDeck: true
        }
      ],
      decks: [
        {
          id: "default-deck",
          name: "Starter Deck",
          cards: ["starter-card-1", "starter-card-2", "starter-card-3", "starter-card-4", "starter-card-5"],
          characterId: "hamid"
        }
      ],
      activeDeckId: "default-deck",
      
      // Card actions
      addCard: (cardId: string) => {
        // First validate that the card exists in our card data
        const cardExists = cards.find(card => card.id === cardId);
        if (!cardExists) {
          console.error(`Attempting to add card with ID ${cardId} which does not exist in the cards database`);
          return '';
        }
        
        // Check if the player already has this card
        const existingCard = get().playerCards.find(card => card.cardId === cardId);
        if (existingCard) {
          console.log(`Player already has card ${cardId}, leveling it up instead`);
          get().levelUpCard(existingCard.id);
          return existingCard.id;
        }
        
        // Create a new player card
        const newCard: PlayerCard = {
          id: generateId(),
          cardId,
          level: 1,
          exp: 0,
          inDeck: false
        };
        
        console.log(`Adding new card to collection: ${cardId}`);
        
        set((state) => ({
          playerCards: [...state.playerCards, newCard]
        }));
        
        // Add the card to the default deck if it's the first few cards
        const { decks, activeDeckId } = get();
        const defaultDeck = decks.find(d => d.id === activeDeckId);
        
        if (defaultDeck && defaultDeck.cards.length < 10) {
          get().addCardToDeck(activeDeckId, newCard.id);
        }
        
        return newCard.id;
      },
      
      removeCard: (playerCardId: string) => {
        set((state) => ({
          playerCards: state.playerCards.filter(card => card.id !== playerCardId),
          decks: state.decks.map(deck => ({
            ...deck,
            cards: deck.cards.filter(id => id !== playerCardId)
          }))
        }));
      },
      
      levelUpCard: (playerCardId: string) => {
        set((state) => ({
          playerCards: state.playerCards.map(card => 
            card.id === playerCardId
              ? { ...card, level: card.level + 1, exp: 0 }
              : card
          )
        }));
      },
      
      // Deck actions
      createDeck: (name: string, characterId: string | null) => {
        const newDeck: Deck = {
          id: generateId(),
          name,
          cards: [],
          characterId
        };
        
        set((state) => ({
          decks: [...state.decks, newDeck]
        }));
        
        return newDeck.id;
      },
      
      removeDeck: (deckId: string) => {
        const { decks, activeDeckId } = get();
        
        // Cannot remove the last deck
        if (decks.length <= 1) return;
        
        // Remove the deck
        set((state) => ({
          decks: state.decks.filter(deck => deck.id !== deckId)
        }));
        
        // If removing the active deck, set a new active deck
        if (deckId === activeDeckId) {
          const newActiveDeck = get().decks[0];
          if (newActiveDeck) {
            set({ activeDeckId: newActiveDeck.id });
          }
        }
      },
      
      setActiveDeck: (deckId: string) => {
        set({ activeDeckId: deckId });
      },
      
      addCardToDeck: (deckId: string, playerCardId: string) => {
        const { decks } = get();
        const deck = decks.find(d => d.id === deckId);
        
        if (!deck) return;
        
        // Check if card is already in deck
        if (deck.cards.includes(playerCardId)) return;
        
        // Add card to deck
        set((state) => ({
          decks: state.decks.map(d => 
            d.id === deckId
              ? { ...d, cards: [...d.cards, playerCardId] }
              : d
          ),
          playerCards: state.playerCards.map(card => 
            card.id === playerCardId
              ? { ...card, inDeck: true }
              : card
          )
        }));
      },
      
      removeCardFromDeck: (deckId: string, playerCardId: string) => {
        set((state) => ({
          decks: state.decks.map(deck => 
            deck.id === deckId
              ? { ...deck, cards: deck.cards.filter(id => id !== playerCardId) }
              : deck
          ),
          playerCards: state.playerCards.map(card => 
            card.id === playerCardId
              ? { ...card, inDeck: false }
              : card
          )
        }));
      },
      
      // Utility functions
      getCardById: (playerCardId: string) => {
        return get().playerCards.find(card => card.id === playerCardId);
      },
      
      getCardDetails: (playerCardId: string) => {
        const playerCard = get().getCardById(playerCardId);
        if (!playerCard) return undefined;
        
        const cardDetails = cards.find(card => card.id === playerCard.cardId);
        // Check if we found a card and add some debug info to help troubleshoot
        if (!cardDetails) {
          console.warn(`Could not find card with ID: ${playerCard.cardId} for player card ${playerCardId}`);
        }
        return cardDetails;
      },
      
      getActiveCards: () => {
        const { activeDeckId, decks, playerCards } = get();
        const activeDeck = decks.find(deck => deck.id === activeDeckId);
        
        if (!activeDeck) return [];
        
        return activeDeck.cards
          .map(cardId => playerCards.find(card => card.id === cardId))
          .filter((card): card is PlayerCard => card !== undefined);
      },
      
      getCardsByCharacter: (characterId: string) => {
        const { playerCards } = get();
        const characterCardIds = characterCards
          .filter(cc => cc.characterId === characterId)
          .map(cc => cc.cardId);
        
        return playerCards.filter(card => 
          characterCardIds.includes(card.cardId)
        );
      },
      
      getDeckByID: (deckId: string) => {
        return get().decks.find(deck => deck.id === deckId);
      },
      
      getActiveDeck: () => {
        const { activeDeckId, decks } = get();
        return decks.find(deck => deck.id === activeDeckId);
      }
    }),
    {
      name: "maltesar-card-collection"
    }
  )
);
