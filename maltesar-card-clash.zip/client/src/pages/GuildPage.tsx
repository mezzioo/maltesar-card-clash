import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGuildSystem, Guild, GuildMember, GuildMessage } from '@/lib/stores/useGuildSystem';
import { GameWrapper } from '@/components/GameWrapper';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { GameButton } from '@/components/ui/game-button';
import { cn } from '@/lib/utils';
import { X } from 'lucide-react';
import { MainMenu } from '@/components/MainMenu';

export default function GuildPage() {
  const navigate = useNavigate();
  const [newGuildName, setNewGuildName] = useState('');
  const [newGuildDescription, setNewGuildDescription] = useState('');
  const [newGuildEmblem, setNewGuildEmblem] = useState('');
  const [message, setMessage] = useState('');
  
  const {
    playerGuildId,
    guilds,
    pendingInvites,
    createGuild,
    joinGuild,
    leaveGuild,
    sendGuildMessage,
    getPlayerGuild,
    getGuildMembers,
    getRecentMessages,
    getPlayerGuildRank,
    dailyCheckin,
    hasCheckedInToday,
    getDailyCheckinCount,
    acceptInvite,
    declineInvite
  } = useGuildSystem();
  
  const playerGuild = getPlayerGuild();
  const guildMembers = getGuildMembers();
  const guildMessages = getRecentMessages(50);
  const playerRank = getPlayerGuildRank();
  const checkedInToday = hasCheckedInToday();
  const checkinCount = getDailyCheckinCount();
  
  const handleCreateGuild = () => {
    if (!newGuildName.trim()) {
      alert("Please enter a guild name");
      return;
    }
    
    const description = newGuildDescription.trim() || "A guild of brave warriors";
    const emblem = newGuildEmblem.trim() || "default";
    
    createGuild(newGuildName, description, emblem);
    
    // Reset the form
    setNewGuildName('');
    setNewGuildDescription('');
    setNewGuildEmblem('');
  };
  
  const handleLeaveGuild = () => {
    if (window.confirm("Are you sure you want to leave the guild?")) {
      leaveGuild();
    }
  };
  
  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    sendGuildMessage(message);
    setMessage('');
  };
  
  const handleDailyCheckin = () => {
    dailyCheckin();
  };
  
  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Render no guild view
  const renderNoGuild = () => (
    <div className="h-full flex flex-col p-4">
      <h2 className="text-xl font-semibold mb-4">Guild Hall</h2>
      
      <div className="flex-1 flex flex-col md:flex-row gap-4">
        {/* Create Guild Form */}
        <div className="w-full md:w-1/2 bg-gray-800 p-4 rounded-lg">
          <h3 className="text-lg font-medium mb-3">Create a New Guild</h3>
          
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium mb-1">Guild Name</label>
              <input
                type="text"
                value={newGuildName}
                onChange={(e) => setNewGuildName(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                placeholder="Enter guild name"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Description (Optional)</label>
              <textarea
                value={newGuildDescription}
                onChange={(e) => setNewGuildDescription(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                placeholder="Describe your guild's purpose"
                rows={3}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Emblem (Optional)</label>
              <select
                value={newGuildEmblem}
                onChange={(e) => setNewGuildEmblem(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
              >
                <option value="default">Default</option>
                <option value="sword">Sword</option>
                <option value="shield">Shield</option>
                <option value="dragon">Dragon</option>
                <option value="phoenix">Phoenix</option>
              </select>
            </div>
            
            <GameButton onClick={handleCreateGuild} className="w-full">
              Create Guild
            </GameButton>
          </div>
        </div>
        
        {/* Guild Listings and Invites */}
        <div className="w-full md:w-1/2 bg-gray-800 p-4 rounded-lg">
          <Tabs defaultValue="guilds">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="guilds">Public Guilds</TabsTrigger>
              <TabsTrigger value="invites" className="relative">
                Invites
                {pendingInvites.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-xs">
                    {pendingInvites.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="guilds" className="space-y-3 max-h-96 overflow-y-auto">
              {guilds.length > 0 ? (
                guilds.map((guild) => (
                  <div key={guild.id} className="bg-gray-700 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">{guild.name}</h4>
                      <span className="text-xs bg-gray-600 px-2 py-1 rounded">Level {guild.level}</span>
                    </div>
                    <p className="text-sm text-gray-300 mb-3">{guild.description}</p>
                    <div className="flex justify-between items-center text-xs text-gray-400 mb-2">
                      <span>{guild.members.length} members</span>
                      <span>Created {new Date(guild.creationDate).toLocaleDateString()}</span>
                    </div>
                    <GameButton 
                      onClick={() => joinGuild(guild.id)} 
                      variant="secondary"
                      className="w-full"
                    >
                      Join Guild
                    </GameButton>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-gray-400">
                  No guilds available. Create one to get started!
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="invites" className="space-y-3 max-h-96 overflow-y-auto">
              {pendingInvites.length > 0 ? (
                pendingInvites.map((invite) => (
                  <div key={invite.guildId} className="bg-gray-700 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">{invite.guildName}</h4>
                      <span className="text-xs bg-gray-600 px-2 py-1 rounded">
                        From: {invite.inviterName}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 mb-3">
                      Invited {new Date(invite.timestamp).toLocaleDateString()}
                    </div>
                    <div className="flex space-x-2">
                      <GameButton 
                        onClick={() => acceptInvite(invite.guildId)} 
                        variant="success" 
                        className="flex-1"
                      >
                        Accept
                      </GameButton>
                      <GameButton 
                        onClick={() => declineInvite(invite.guildId)} 
                        variant="destructive"
                        className="flex-1"
                      >
                        Decline
                      </GameButton>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-gray-400">
                  No pending invitations.
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
  
  // Render guild view for guild members
  const renderGuildView = () => {
    if (!playerGuild) return null;
    
    return (
      <div className="h-full flex flex-col p-4">
        {/* Guild Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-semibold">{playerGuild.name}</h2>
            <p className="text-sm text-gray-400">Level {playerGuild.level} Guild • {playerGuild.members.length} Members</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="text-xs bg-gray-800 px-3 py-1 rounded-full">
              Your Rank: <span className="text-yellow-300">{playerRank || "Member"}</span>
            </div>
            
            <GameButton 
              onClick={handleLeaveGuild} 
              variant="outline"
              size="sm"
            >
              Leave Guild
            </GameButton>
          </div>
        </div>
        
        {/* Guild Tabs */}
        <Tabs defaultValue="chat" className="flex-1 flex flex-col">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="chat">Guild Chat</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
            <TabsTrigger value="info">Guild Info</TabsTrigger>
          </TabsList>
          
          <div className="flex-1 overflow-hidden">
            {/* Chat Tab */}
            <TabsContent value="chat" className="h-full flex flex-col">
              <div className="flex-1 overflow-y-auto bg-gray-800 rounded-md p-3 mb-3">
                {guildMessages.length > 0 ? (
                  <div className="space-y-2">
                    {guildMessages.map((msg) => (
                      <div 
                        key={msg.id} 
                        className={cn(
                          "px-3 py-2 rounded",
                          msg.isSystem 
                            ? "bg-gray-700/50 text-gray-400 text-sm italic" 
                            : "bg-gray-700"
                        )}
                      >
                        {!msg.isSystem && (
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-medium text-yellow-300">{msg.senderName}</span>
                            <span className="text-gray-400">{formatTimestamp(msg.timestamp)}</span>
                          </div>
                        )}
                        <div>{msg.content}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-400">
                    No messages yet. Be the first to say hello!
                  </div>
                )}
              </div>
              
              <div className="flex gap-2">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="flex-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                  placeholder="Type a message..."
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <GameButton onClick={handleSendMessage}>Send</GameButton>
              </div>
            </TabsContent>
            
            {/* Members Tab */}
            <TabsContent value="members" className="h-full">
              <div className="h-full overflow-y-auto bg-gray-800 rounded-md p-3">
                <h3 className="font-medium mb-3">Guild Members ({guildMembers.length})</h3>
                
                <div className="space-y-2">
                  {guildMembers.map((member) => (
                    <div 
                      key={member.id} 
                      className="flex justify-between items-center bg-gray-700 p-3 rounded-md"
                    >
                      <div>
                        <div className="font-medium">{member.name}</div>
                        <div className="text-xs text-gray-400">Level {member.level}</div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "px-2 py-1 rounded text-xs",
                          member.rank === "Leader" ? "bg-red-900/50 text-red-300" :
                          member.rank === "Officer" ? "bg-yellow-900/50 text-yellow-300" :
                          member.rank === "Veteran" ? "bg-blue-900/50 text-blue-300" :
                          "bg-gray-600 text-gray-300"
                        )}>
                          {member.rank}
                        </div>
                        
                        <div className="text-xs text-gray-400">
                          Joined {new Date(member.joinDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
            
            {/* Guild Info Tab */}
            <TabsContent value="info" className="h-full">
              <div className="h-full overflow-y-auto bg-gray-800 rounded-md p-4">
                <div className="mb-4">
                  <h3 className="font-medium mb-2">Guild Information</h3>
                  <div className="bg-gray-700 p-3 rounded-md">
                    <div className="mb-2">
                      <div className="text-sm text-gray-400">Description:</div>
                      <div>{playerGuild.description}</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <div className="text-gray-400">Created:</div>
                        <div>{new Date(playerGuild.creationDate).toLocaleDateString()}</div>
                      </div>
                      
                      <div>
                        <div className="text-gray-400">Members:</div>
                        <div>{playerGuild.members.length}</div>
                      </div>
                      
                      <div>
                        <div className="text-gray-400">Level:</div>
                        <div>{playerGuild.level}</div>
                      </div>
                      
                      <div>
                        <div className="text-gray-400">EXP:</div>
                        <div>{playerGuild.exp} / {playerGuild.expToNextLevel}</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h3 className="font-medium mb-2">Daily Check-in</h3>
                  <div className="bg-gray-700 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-3">
                      <div>
                        <div className="text-sm">Guild members checked in today:</div>
                        <div className="text-xl font-bold">{checkinCount} / {playerGuild.members.length}</div>
                      </div>
                      
                      <GameButton
                        onClick={handleDailyCheckin}
                        disabled={checkedInToday}
                        variant={checkedInToday ? "outline" : "success"}
                      >
                        {checkedInToday ? "Already Checked In" : "Daily Check-in"}
                      </GameButton>
                    </div>
                    
                    <div className="text-sm text-gray-400">
                      Daily check-ins award guild EXP and personal contribution points.
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    );
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Back button */}
        <button 
          onClick={() => navigate('/')}
          className="absolute top-4 right-4 z-20 bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors shadow-md border border-gray-700"
          aria-label="Close guild page"
        >
          <X size={20} className="text-white" />
        </button>
        
        {playerGuildId && playerGuild ? renderGuildView() : renderNoGuild()}
      </div>
    </div>
  );
}