import React, { useEffect } from "react";
import { MainMenu } from "../components/MainMenu";
import { Inventory } from "../components/Inventory";
import { useGameState } from "../lib/stores/useGameState";
import { useAudio } from "../lib/stores/useAudio";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCardCollection, Deck } from "../lib/stores/useCardCollection";
import { GameButton } from "../components/ui/game-button";
import { getCharacterById } from "../data/characters";
import { toast } from "sonner";

const CollectionPage: React.FC = () => {
  const { setCurrentScreen, unlockedCharacters } = useGameState();
  const { backgroundMusic } = useAudio();
  const { 
    playerCards, 
    decks, 
    activeDeckId, 
    createDeck, 
    removeDeck, 
    setActiveDeck, 
    getCardDetails 
  } = useCardCollection();
  
  // Initialize page
  useEffect(() => {
    setCurrentScreen("collection");
    
    if (backgroundMusic && !backgroundMusic.playing()) {
      backgroundMusic.play();
    }
  }, [backgroundMusic, setCurrentScreen]);
  
  // Create a new deck
  const handleCreateDeck = () => {
    const deckName = prompt("Enter a name for your new deck:");
    if (deckName) {
      const characterId = prompt("Enter character ID for this deck (leave blank for none):");
      createDeck(deckName, characterId || null);
      toast.success(`Created new deck: ${deckName}`);
    }
  };
  
  // Remove a deck
  const handleRemoveDeck = (deckId: string) => {
    if (confirm("Are you sure you want to remove this deck?")) {
      removeDeck(deckId);
      toast.success("Deck removed successfully");
    }
  };
  
  // Set active deck
  const handleSetActiveDeck = (deckId: string) => {
    setActiveDeck(deckId);
    toast.success("Active deck updated");
  };
  
  // Render deck manager
  const renderDeckManager = () => {
    return (
      <div className="p-2 sm:p-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-2">
          <h2 className="text-xl font-semibold">Your Decks</h2>
          <GameButton 
            size="sm" 
            variant="secondary" 
            onClick={handleCreateDeck} 
            disabled={decks.length >= 5}
          >
            Create New Deck
          </GameButton>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
          {decks.map((deck: Deck) => {
            const character = deck.characterId ? getCharacterById(deck.characterId) : null;
            const deckCards = deck.cards.map(cardId => 
              playerCards.find(pc => pc.id === cardId)
            ).filter(Boolean);
            
            return (
              <div 
                key={deck.id} 
                className={`bg-gray-800 rounded-lg p-3 sm:p-4 ${deck.id === activeDeckId ? 'ring-2 ring-amber-500' : ''}`}
              >
                <div className="flex flex-col sm:flex-row justify-between items-start gap-2 mb-3">
                  <div>
                    <h3 className="font-semibold text-base sm:text-lg">{deck.name}</h3>
                    <p className="text-xs sm:text-sm text-gray-400">
                      {deck.cards.length} / 20 cards
                    </p>
                  </div>
                  
                  {character && (
                    <div className="flex items-center bg-gray-700 px-2 py-1 rounded text-xs">
                      <span className="mr-1">Character:</span>
                      <span className="font-medium">{character.name}</span>
                    </div>
                  )}
                </div>
                
                {/* Card types breakdown */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3 sm:mb-4 text-xs">
                  {['attack', 'defense', 'heal', 'buff'].map(type => {
                    const count = deckCards.filter(pc => {
                      if (!pc) return false;
                      const card = getCardDetails(pc.id);
                      return card?.type === type;
                    }).length;
                    
                    return (
                      <div key={type} className="bg-gray-700 p-2 rounded text-center">
                        <div className="capitalize">{type}</div>
                        <div className="font-semibold">{count}</div>
                      </div>
                    );
                  })}
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {deck.id !== activeDeckId && (
                    <GameButton
                      size="sm"
                      variant="secondary"
                      onClick={() => handleSetActiveDeck(deck.id)}
                    >
                      Set Active
                    </GameButton>
                  )}
                  
                  {decks.length > 1 && (
                    <GameButton
                      size="sm"
                      variant="destructive"
                      onClick={() => handleRemoveDeck(deck.id)}
                    >
                      Remove
                    </GameButton>
                  )}
                </div>
              </div>
            );
          })}
          
          {decks.length === 0 && (
            <div className="col-span-full text-center py-8 text-gray-400">
              No decks created yet. Create your first deck!
            </div>
          )}
        </div>
      </div>
    );
  };
  
  // Render character collection
  const renderCharacterCollection = () => {
    return (
      <div className="p-2 sm:p-4">
        <h2 className="text-xl font-semibold mb-4">Characters</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {unlockedCharacters.map(charId => {
            const character = getCharacterById(charId);
            if (!character) return null;
            
            return (
              <div key={charId} className="bg-gray-800 rounded-lg p-3 sm:p-4">
                <div className="flex justify-center mb-2 sm:mb-3">
                  <div 
                    className="w-20 h-20 sm:w-24 sm:h-24" 
                    dangerouslySetInnerHTML={{ __html: character.portrait }}
                  />
                </div>
                
                <h3 className="text-center font-semibold mb-1 text-sm sm:text-base">{character.name}</h3>
                <p className="text-xs text-center text-gray-400 mb-2">{character.rarity}</p>
                
                <p className="text-xs mb-3 line-clamp-3">{character.description}</p>
                
                <div className="grid grid-cols-2 gap-1 text-xs">
                  <div className="bg-gray-700 p-1 rounded text-center">HP: {character.baseHP}</div>
                  <div className="bg-gray-700 p-1 rounded text-center">ATK: {character.baseAttack}</div>
                  <div className="bg-gray-700 p-1 rounded text-center">DEF: {character.baseDefense}</div>
                  <div className="bg-gray-700 p-1 rounded text-center">SPD: {character.baseSpeed}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Collection Content */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="cards">
          <TabsList className="w-full justify-center sm:justify-start p-2 bg-gray-800 flex flex-wrap">
            <TabsTrigger value="cards" className="flex-1 sm:flex-none text-center">Cards</TabsTrigger>
            <TabsTrigger value="decks" className="flex-1 sm:flex-none text-center">Decks</TabsTrigger>
            <TabsTrigger value="characters" className="flex-1 sm:flex-none text-center">Characters</TabsTrigger>
          </TabsList>
          
          <TabsContent value="cards" className="h-full overflow-y-auto">
            <Inventory />
          </TabsContent>
          
          <TabsContent value="decks" className="h-full overflow-y-auto">
            {renderDeckManager()}
          </TabsContent>
          
          <TabsContent value="characters" className="h-full overflow-y-auto">
            {renderCharacterCollection()}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CollectionPage;
