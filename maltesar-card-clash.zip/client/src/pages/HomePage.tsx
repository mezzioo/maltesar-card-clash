import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainMenu } from "../components/MainMenu";
import { useGameState } from "../lib/stores/useGameState";
import { GameButton } from "../components/ui/game-button";
import { useAudio } from "../lib/stores/useAudio";
import { Volume2, VolumeX } from "lucide-react";

const HomePage: React.FC = () => {
  const { 
    playerName, 
    tutorialCompleted, 
    setCurrentScreen,
    completeTutorial
  } = useGameState();
  
  const { playBackgroundMusic, isMuted, toggleMute } = useAudio();
  const navigate = useNavigate();
  
  // Play background music when component mounts
  useEffect(() => {
    // Play background music if it's not already playing
    playBackgroundMusic();
    
    // Update the current screen in the game state
    setCurrentScreen("menu");
    
    return () => {
      // Don't stop music when navigating away, let it continue
    };
  }, [playBackgroundMusic, setCurrentScreen]);
  
  // Handle sound toggle
  const handleSoundToggle = () => {
    toggleMute();
  };
  
  // Start a new game
  const handleStartGame = () => {
    if (!tutorialCompleted) {
      // Navigate to story mode for tutorial
      navigate("/story");
    } else {
      // Navigate to battle for existing players
      navigate("/battle");
    }
  };
  
  // Continue game
  const handleContinueGame = () => {
    navigate("/battle");
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden bg-gray-900">
      {/* Side Menu - Hidden on mobile, visible on md screens and up */}
      <div className="hidden md:block md:w-64 h-full border-r border-gray-800">
        <MainMenu onSoundToggle={handleSoundToggle} />
      </div>
      
      {/* Mobile Menu Toggle - Visible only on small screens */}
      <div className="md:hidden bg-gray-900 p-2 border-b border-gray-800 flex justify-between items-center">
        <h1 className="text-xl font-bold text-amber-500">Maltesar</h1>
        <button 
          onClick={handleSoundToggle}
          className="p-2 rounded-md bg-gray-800"
        >
          {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
        </button>
      </div>
      
      {/* Main Content */}
      <div 
        className="flex-1 h-full flex flex-col items-center justify-center relative px-4" 
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7))',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        {/* Game title */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-amber-500 mb-2 pixel-text">Maltesar</h1>
          <h2 className="text-2xl md:text-3xl font-semibold text-white pixel-text">Card Clash</h2>
          <p className="text-lg md:text-xl text-gray-300 mt-2 pixel-text">Trials of the Academy</p>
        </div>
        
        {/* Game start buttons */}
        <div className="space-y-4 w-full max-w-xs">
          <GameButton
            onClick={handleStartGame}
            className="w-full py-3 text-lg"
          >
            {tutorialCompleted ? "Start Game" : "New Game"}
          </GameButton>
          
          {tutorialCompleted && (
            <>
              <GameButton
                variant="secondary"
                onClick={handleContinueGame}
                className="w-full py-3 text-lg"
              >
                Continue
              </GameButton>
              
              <GameButton
                variant="subtle"
                onClick={() => {
                  completeTutorial(); // This is actually redundant but reinforces state
                  navigate("/story");
                }}
                className="w-full py-3 text-lg"
              >
                Restart Tutorial
              </GameButton>
            </>
          )}
          
          <GameButton
            variant="outline"
            onClick={() => navigate("/collection")}
            className="w-full py-3"
            disabled={!tutorialCompleted}
          >
            Card Collection
          </GameButton>
        </div>
        
        {/* Version info */}
        <div className="absolute bottom-4 left-0 right-0 text-center text-gray-500 text-sm">
          v1.0.0 - Card RPG
        </div>
      </div>
    </div>
  );
};

export default HomePage;
