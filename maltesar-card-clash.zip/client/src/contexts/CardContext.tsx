import React, { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { useCardCollection, PlayerCard } from '../lib/stores/useCardCollection';
import { cards, CardType } from '../data/cards';
import { useGameState } from '../lib/stores/useGameState';
import { getCharacterById } from '../data/characters';
import { toast } from 'sonner';

// Context interface
interface CardContextInterface {
  // Card collection state
  playerCards: PlayerCard[];
  activeDeck: {
    id: string;
    name: string;
    cards: PlayerCard[];
  };
  
  // Card actions
  addCardToDeck: (deckId: string, cardId: string) => void;
  removeCardFromDeck: (deckId: string, cardId: string) => void;
  createDeck: (name: string, characterId: string | null) => string;
  getCardDetails: (cardId: string) => CardType | undefined;
  
  // Card utilities
  getCardsByType: (type: string) => PlayerCard[];
  getCardsByRarity: (rarity: string) => PlayerCard[];
  getCardsByCharacter: (characterId: string) => PlayerCard[];
}

// Create context with default values
const CardContext = createContext<CardContextInterface>({
  playerCards: [],
  activeDeck: {
    id: '',
    name: '',
    cards: []
  },
  addCardToDeck: () => {},
  removeCardFromDeck: () => {},
  createDeck: () => '',
  getCardDetails: () => undefined,
  getCardsByType: () => [],
  getCardsByRarity: () => [],
  getCardsByCharacter: () => []
});

// Hook to use the card context
export const useCards = () => useContext(CardContext);

// Card context provider
export const CardContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Get state and actions from the zustand stores
  const {
    playerCards,
    decks,
    activeDeckId,
    addCardToDeck,
    removeCardFromDeck,
    createDeck: zustandCreateDeck,
    getCardDetails,
    getCardsByCharacter: zustandGetCardsByCharacter,
    getActiveDeck
  } = useCardCollection();
  
  const { unlockedCharacters } = useGameState();
  
  // Computed active deck with cards
  const [activeDeckWithCards, setActiveDeckWithCards] = useState<{
    id: string;
    name: string;
    cards: PlayerCard[];
  }>({
    id: '',
    name: '',
    cards: []
  });
  
  // Update the active deck when it changes
  useEffect(() => {
    const activeDeck = getActiveDeck();
    
    if (activeDeck) {
      const deckCards = activeDeck.cards
        .map(cardId => playerCards.find(pc => pc.id === cardId))
        .filter((card): card is PlayerCard => card !== undefined);
      
      setActiveDeckWithCards({
        id: activeDeck.id,
        name: activeDeck.name,
        cards: deckCards
      });
    }
  }, [activeDeckId, decks, getActiveDeck, playerCards]);
  
  // Create a deck with validation
  const createDeckWithValidation = (name: string, characterId: string | null): string => {
    // Validate character
    if (characterId && !unlockedCharacters.includes(characterId)) {
      toast.error("You don't have this character unlocked!");
      return '';
    }
    
    // Create the deck
    const deckId = zustandCreateDeck(name, characterId);
    
    // If character is specified, try to add their starting cards
    if (characterId && deckId) {
      const character = getCharacterById(characterId);
      
      if (character) {
        toast.success(`Created deck for ${character.name}`);
      }
    }
    
    return deckId;
  };
  
  // Get cards by type
  const getCardsByType = (type: string): PlayerCard[] => {
    return playerCards.filter(playerCard => {
      const cardDetails = getCardDetails(playerCard.id);
      return cardDetails?.type === type;
    });
  };
  
  // Get cards by rarity
  const getCardsByRarity = (rarity: string): PlayerCard[] => {
    return playerCards.filter(playerCard => {
      const cardDetails = getCardDetails(playerCard.id);
      return cardDetails?.rarity === rarity;
    });
  };
  
  // Create the context value
  const contextValue: CardContextInterface = {
    playerCards,
    activeDeck: activeDeckWithCards,
    addCardToDeck,
    removeCardFromDeck,
    createDeck: createDeckWithValidation,
    getCardDetails,
    getCardsByType,
    getCardsByRarity,
    getCardsByCharacter: zustandGetCardsByCharacter
  };
  
  return (
    <CardContext.Provider value={contextValue}>
      {children}
    </CardContext.Provider>
  );
};
