import React from "react";
import { Link } from "react-router-dom";
import { useGameState } from "../lib/stores/useGameState";
import { useCurrency } from "../lib/stores/useCurrency";
import { useAudio } from "../lib/stores/useAudio";
import { GameButton } from "./ui/game-button";
import { cn } from "@/lib/utils";

// Icons
import { 
  Home, 
  Sword, 
  Scroll, 
  Store, 
  Layers, 
  BookOpen,
  Settings,
  Volume2,
  VolumeX,
  CheckSquare,
  Star,
  Users
} from "lucide-react";

// Helper for experience bar calculation
const calculateExpPercentage = (current: number, total: number): number => {
  return (current / total) * 100;
};

// Main menu item type
interface MenuItem {
  to: string;
  label: string;
  icon: React.ReactNode;
  isAvailable: boolean;
}

interface MainMenuProps {
  isCompact?: boolean;
  onSoundToggle?: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ isCompact = false, onSoundToggle }) => {
  const { 
    playerName, 
    playerLevel, 
    playerExp, 
    expToNextLevel,
    tutorialCompleted
  } = useGameState();
  
  const { gold, gems } = useCurrency();
  const { isMuted, toggleMute } = useAudio();
  
  // Menu items
  const menuItems: MenuItem[] = [
    {
      to: "/",
      label: "Home",
      icon: <Home className="w-5 h-5" />,
      isAvailable: true
    },
    {
      to: "/battle",
      label: "Battle",
      icon: <Sword className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/collection",
      label: "Collection",
      icon: <Layers className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/dungeon",
      label: "Dungeons",
      icon: <Scroll className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/gacha",
      label: "Summon",
      icon: <Star className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/quests",
      label: "Quests",
      icon: <CheckSquare className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/guild",
      label: "Guild",
      icon: <Users className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/shop",
      label: "Shop",
      icon: <Store className="w-5 h-5" />,
      isAvailable: tutorialCompleted
    },
    {
      to: "/story",
      label: "Story",
      icon: <BookOpen className="w-5 h-5" />,
      isAvailable: true
    }
  ];
  
  const expPercentage = calculateExpPercentage(playerExp, expToNextLevel);
  
  // Toggle sound
  const handleSoundToggle = () => {
    toggleMute();
    if (onSoundToggle) onSoundToggle();
  };
  
  if (isCompact) {
    // Compact version for in-game pages
    return (
      <div className="bg-gray-900 p-2 border-b border-gray-800 flex flex-wrap justify-between items-center">
        <div className="flex items-center space-x-2 mb-1 md:mb-0">
          <Link to="/" className="text-white font-bold">Maltesar</Link>
          
          <div className="h-6 border-l border-gray-700 mx-2 hidden sm:block"></div>
          
          {/* Navigation icons */}
          <div className="flex flex-wrap gap-1 sm:space-x-2">
            {menuItems.filter(item => item.isAvailable).map((item) => (
              <Link 
                key={item.to} 
                to={item.to} 
                className="text-gray-400 hover:text-white p-1 rounded-md hover:bg-gray-800 transition-colors"
                title={item.label}
              >
                {item.icon}
              </Link>
            ))}
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-2 sm:space-x-3">
          {/* Currency display */}
          <div className="flex items-center text-xs bg-gray-800/50 px-2 py-1 rounded">
            <span className="text-amber-400 mr-1">Gold:</span>
            <span className="text-white">{gold}</span>
          </div>
          
          <div className="flex items-center text-xs bg-gray-800/50 px-2 py-1 rounded">
            <span className="text-purple-400 mr-1">Gems:</span>
            <span className="text-white">{gems}</span>
          </div>
          
          {/* Sound toggle */}
          <button 
            onClick={handleSoundToggle} 
            className="text-gray-400 hover:text-white p-1 rounded-md hover:bg-gray-800 transition-colors"
            title={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          
          {/* Player level badge */}
          <div className="bg-blue-900 text-white text-xs px-2 py-1 rounded-full">
            Lvl {playerLevel}
          </div>
        </div>
      </div>
    );
  }
  
  // Full menu for home page
  return (
    <div className="bg-gray-900 text-white h-full flex flex-col">
      {/* Header with player info */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Maltesar</h1>
            <p className="text-gray-400 text-sm">Card Clash: Trials of the Academy</p>
          </div>
          
          {/* Sound toggle */}
          <button 
            onClick={handleSoundToggle} 
            className="bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors"
            title={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
          </button>
        </div>
      </div>
      
      {/* Player stats */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center mb-2">
          <div className="w-12 h-12 bg-blue-800 rounded-full flex items-center justify-center text-2xl font-bold mr-3">
            {playerName.charAt(0)}
          </div>
          <div>
            <div className="font-semibold">{playerName}</div>
            <div className="text-sm text-gray-400">Level {playerLevel}</div>
          </div>
        </div>
        
        {/* Experience bar */}
        <div className="mt-2">
          <div className="flex justify-between text-xs mb-1">
            <span>EXP: {playerExp}/{expToNextLevel}</span>
            <span>{Math.floor(expPercentage)}%</span>
          </div>
          <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500" 
              style={{ width: `${expPercentage}%` }}
            ></div>
          </div>
        </div>
        
        {/* Currency */}
        <div className="mt-3 flex space-x-3">
          <div className="flex items-center bg-amber-900/30 px-3 py-1 rounded-md">
            <span className="text-amber-400 mr-1">Gold:</span>
            <span>{gold}</span>
          </div>
          <div className="flex items-center bg-purple-900/30 px-3 py-1 rounded-md">
            <span className="text-purple-400 mr-1">Gems:</span>
            <span>{gems}</span>
          </div>
        </div>
      </div>
      
      {/* Menu items */}
      <div className="flex-1 p-2 overflow-y-auto">
        {menuItems.map((item) => (
          <Link 
            key={item.to} 
            to={item.to}
            className={cn(
              "block mb-2",
              !item.isAvailable && "opacity-50 pointer-events-none"
            )}
          >
            <GameButton
              variant="menu"
              disabled={!item.isAvailable}
              className="w-full justify-start"
            >
              {item.icon}
              {item.label}
            </GameButton>
          </Link>
        ))}
      </div>
      
      {/* Footer */}
      <div className="p-4 border-t border-gray-800 text-xs text-gray-400 text-center">
        Maltesar Card Clash v1.0
      </div>
    </div>
  );
};
