import { useRef, useState, Suspense } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF, OrbitControls, Environment } from "@react-three/drei";
import * as THREE from "three";
import { GLTF } from "three-stdlib";

// Preload the model
useGLTF.preload('/models/magic_card.glb');

interface MagicCard3DProps {
  scale?: number;
  position?: [number, number, number];
  rotation?: [number, number, number];
  showControls?: boolean;
}

export const MagicCard3D: React.FC<MagicCard3DProps> = ({
  scale = 2.5,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  showControls = true
}) => {
  const { scene: cardModel } = useGLTF('/models/magic_card.glb') as GLTF & {
    scene: THREE.Group
  };
  
  const [modelLoaded, setModelLoaded] = useState(false);
  const cardRef = useRef<THREE.Group>(null);
  
  // Handle model loading
  useState(() => {
    if (cardModel) {
      setModelLoaded(true);
      console.log("Magic card 3D model loaded successfully");
    }
  });
  
  // Animate the card
  useFrame((state) => {
    if (cardRef.current) {
      cardRef.current.rotation.y += 0.005;
      cardRef.current.position.y = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.2;
    }
  });
  
  return (
    <>
      <group 
        ref={cardRef} 
        position={new THREE.Vector3(...position)} 
        rotation={new THREE.Euler(...rotation)}
        scale={[scale, scale, scale]}
      >
        {modelLoaded ? (
          <Suspense fallback={
            <mesh>
              <boxGeometry args={[1, 1.4, 0.1]} />
              <meshStandardMaterial color="#ffd700" />
            </mesh>
          }>
            <primitive object={cardModel.clone()} />
          </Suspense>
        ) : (
          <mesh>
            <boxGeometry args={[1, 1.4, 0.1]} />
            <meshStandardMaterial color="#ffd700" />
          </mesh>
        )}
      </group>
      
      {/* Environment lighting */}
      <Environment preset="sunset" />
      
      {/* Camera controls */}
      {showControls && <OrbitControls makeDefault enableZoom={true} maxPolarAngle={Math.PI / 2} minPolarAngle={Math.PI / 6} />}
      
      {/* Add atmospheric lighting */}
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
      <pointLight position={[-10, -10, -5]} intensity={0.5} color="#ff00ff" />
    </>
  );
};

export default MagicCard3D;