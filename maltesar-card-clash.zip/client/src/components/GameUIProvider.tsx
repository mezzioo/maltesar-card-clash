import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { AiCompanion } from "./AiCompanion";
import { useGameState } from "../lib/stores/useGameState";

/**
 * GameUIProvider wraps the application with UI elements that need to be
 * displayed across all pages, such as the AI companion.
 */
export const GameUIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const [currentScreen, setCurrentScreen] = useState("home");
  const { tutorialCompleted } = useGameState();
  
  // Map pathname to screen name for the AI companion
  useEffect(() => {
    const path = location.pathname.replace("/", "");
    
    // Map paths to screen names used in the AI companion
    const screenMapping: Record<string, string> = {
      "": "home",
      "battle": "battle",
      "collection": "collection", 
      "dungeon": "dungeon",
      "gacha": "gacha",
      "shop": "shop", 
      "story": "story"
    };
    
    if (screenMapping[path] !== undefined) {
      setCurrentScreen(screenMapping[path]);
    } else {
      setCurrentScreen("default");
    }
  }, [location]);
  
  return (
    <>
      {children}
      <AiCompanion currentScreen={currentScreen} />
    </>
  );
};