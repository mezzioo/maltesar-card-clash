import React from "react";
import { BattleParticipant } from "../lib/stores/useBattleSystem";
import { cn } from "@/lib/utils";

interface CharacterProps {
  participant: BattleParticipant;
  isEnemy: boolean;
  isActive?: boolean;
  onClick?: () => void;
  className?: string;
}

export const Character: React.FC<CharacterProps> = ({
  participant,
  isEnemy,
  isActive = false,
  onClick,
  className,
}) => {
  const healthPercentage = (participant.currentHp / participant.maxHp) * 100;
  const healthColor = 
    healthPercentage > 70 ? 'bg-green-500' :
    healthPercentage > 30 ? 'bg-yellow-500' :
    'bg-red-500';
    
  // Generate a simple character sprite based on participant ID
  const generateCharacterSprite = () => {
    // This is a placeholder. In a real game, you would use actual character sprites
    const colors = {
      player: '#3498db',
      hamid: '#2ecc71',
      soraya: '#9b59b6',
      faris: '#e74c3c',
      polycarp: '#34495e',
      emmanuel: '#f1c40f',
      layla: '#e84393',
      idris: '#00cec9',
      zane: '#0984e3',
      tariq: '#6c5ce7',
      'minion-weak': '#95a5a6',
      'minion-medium': '#7f8c8d',
      'minion-strong': '#636e72',
      'mr-crashout': '#d63031',
      'tilawa-crashout': '#00b894',
      'history-crashout': '#0984e3',
    };
    
    // Default color if ID not found
    const color = colors[participant.id as keyof typeof colors] || '#bdc3c7';
    
    return (
      <div className="relative w-12 h-20 sm:w-16 sm:h-24">
        {/* Body */}
        <div className="absolute bottom-0 left-0 right-0 h-16 sm:h-20" style={{ backgroundColor: color }}></div>
        
        {/* Head */}
        <div className="absolute top-0 left-2 right-2 h-6 sm:h-8 rounded-t-full" style={{ backgroundColor: color }}></div>
        
        {/* Eyes */}
        <div className="absolute top-1.5 sm:top-2 left-3 w-1.5 sm:w-2 h-1.5 sm:h-2 rounded-full bg-white"></div>
        <div className="absolute top-1.5 sm:top-2 right-3 w-1.5 sm:w-2 h-1.5 sm:h-2 rounded-full bg-white"></div>
        
        {/* Mouth */}
        <div className="absolute top-4 sm:top-5 left-4 sm:left-5 right-4 sm:right-5 h-1 bg-white"></div>
        
        {/* Enemy indicator */}
        {isEnemy && (
          <div className="absolute top-0 left-0 w-3 h-3 sm:w-4 sm:h-4 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
            !
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div 
      className={cn(
        "flex flex-col items-center p-1 sm:p-2 rounded-md",
        isActive ? "bg-gray-800/50" : "bg-transparent",
        isEnemy ? "text-red-400" : "text-blue-400",
        className
      )}
      onClick={onClick}
    >
      {/* Character name */}
      <div className="text-xs sm:text-sm font-semibold mb-0.5 sm:mb-1 truncate w-full text-center">
        {participant.name}
      </div>
      
      {/* Character sprite */}
      <div className={cn(
        "character-sprite mb-1 sm:mb-2 transition-all",
        isActive ? "animate-pulse" : ""
      )}>
        {generateCharacterSprite()}
      </div>
      
      {/* Health bar */}
      <div className="w-full h-1.5 sm:h-2 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className={`h-full ${healthColor} transition-all duration-300`} 
          style={{ width: `${healthPercentage}%` }}
        ></div>
      </div>
      
      {/* Health text */}
      <div className="text-[10px] sm:text-xs mt-0.5 sm:mt-1">
        {participant.currentHp} / {participant.maxHp} HP
      </div>
      
      {/* Stats */}
      <div className="flex space-x-2 mt-0.5 sm:mt-1 text-[8px] sm:text-[10px] text-gray-400">
        <span title="Attack">A:{participant.attack}</span>
        <span title="Defense">D:{participant.defense}</span>
        <span title="Speed">S:{participant.speed}</span>
      </div>
      
      {/* Status effects */}
      {(participant.buffs.length > 0 || participant.debuffs.length > 0) && (
        <div className="flex mt-0.5 sm:mt-1 space-x-1">
          {participant.buffs.map((buff, index) => (
            <div 
              key={`buff-${index}`} 
              className="w-2 h-2 sm:w-3 sm:h-3 bg-green-500 rounded-full text-[6px] sm:text-[8px] flex items-center justify-center"
              title={`${buff.type}: +${buff.value} (${buff.duration} turns)`}
            >
              +
            </div>
          ))}
          
          {participant.debuffs.map((debuff, index) => (
            <div 
              key={`debuff-${index}`} 
              className="w-2 h-2 sm:w-3 sm:h-3 bg-red-500 rounded-full text-[6px] sm:text-[8px] flex items-center justify-center"
              title={`${debuff.type}: -${debuff.value} (${debuff.duration} turns)`}
            >
              -
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
