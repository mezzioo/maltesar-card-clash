import React, { useState, useEffect } from "react";
import { useBattleSystem, BattleParticipant } from "../lib/stores/useBattleSystem";
import { CardType } from "../data/cards";
import { Card } from "./Card";
import { Character } from "./Character";
import { GameButton } from "./ui/game-button";
import { useAudio } from "../lib/stores/useAudio";
import { cn } from "@/lib/utils";

interface BattleFieldProps {
  onVictory: () => void;
  onDefeat: () => void;
}

export const BattleField: React.FC<BattleFieldProps> = ({ onVictory, onDefeat }) => {
  const { 
    phase, 
    player, 
    enemies, 
    hand, 
    playerMana, 
    maxPlayerMana,
    currentRound,
    selectedCard, 
    selectedTarget,
    selectCard, 
    selectTarget, 
    playCard, 
    endPlayerTurn
  } = useBattleSystem();
  
  const { playHit, playSuccess } = useAudio();
  
  const [battleLog, setBattleLog] = useState<string[]>([
    "Battle has begun!"
  ]);
  
  const [shake, setShake] = useState<string | null>(null);
  
  // Check for victory or defeat
  useEffect(() => {
    if (phase === "victory") {
      playSuccess();
      setBattleLog(prev => [...prev, "Victory! You've defeated all enemies!"]);
      setTimeout(() => onVictory(), 2000);
    } else if (phase === "defeat") {
      setBattleLog(prev => [...prev, "Defeat! Your character has fallen!"]);
      setTimeout(() => onDefeat(), 2000);
    }
  }, [phase, onVictory, onDefeat, playSuccess]);
  
  // Add to battle log when damage is dealt
  const addLogMessage = (message: string) => {
    setBattleLog(prev => [...prev.slice(-4), message]);
  };
  
  // Handle card selection
  const handleCardSelect = (card: CardType) => {
    // Check if we have enough mana
    if (card.manaCost > playerMana) {
      addLogMessage(`Not enough mana to play ${card.name}!`);
      return;
    }
    
    // Select or deselect card
    if (selectedCard && selectedCard.id === card.id) {
      selectCard(null);
    } else {
      selectCard(card);
      addLogMessage(`Selected ${card.name}.`);
    }
  };
  
  // Handle target selection
  const handleTargetSelect = (target: BattleParticipant) => {
    if (!selectedCard) {
      return;
    }
    
    // Handle target selection based on card type
    if (selectedCard.type === "attack" || selectedCard.type === "debuff") {
      // Only enemies can be targeted with attacks and debuffs
      if (!target.isEnemy) {
        addLogMessage("You can't target allies with this card!");
        return;
      }
    } else if (selectedCard.type === "heal" || selectedCard.type === "buff") {
      // Only allies can be targeted with heals and buffs
      if (target.isEnemy) {
        addLogMessage("You can't target enemies with this card!");
        return;
      }
    }
    
    // Play the selected card on the target
    const cardIndex = hand.findIndex(c => c.id === selectedCard.id);
    if (cardIndex >= 0) {
      const success = playCard(cardIndex, target.id);
      
      if (success) {
        playHit();
        addLogMessage(`Used ${selectedCard.name} on ${target.name}!`);
        
        // Add shake effect to target
        setShake(target.id);
        setTimeout(() => setShake(null), 500);
      }
    }
  };
  
  // End turn button handler
  const handleEndTurn = () => {
    addLogMessage("Ending your turn...");
    endPlayerTurn();
    addLogMessage("Enemy turn beginning...");
  };
  
  // Render mana crystals
  const renderMana = () => {
    const manaArray = [];
    
    for (let i = 0; i < maxPlayerMana; i++) {
      manaArray.push(
        <div 
          key={i} 
          className={`w-5 h-5 rounded-full ${i < playerMana ? 'bg-blue-500' : 'bg-gray-700'}`}
        />
      );
    }
    
    return manaArray;
  };
  
  if (!player) {
    return <div className="flex items-center justify-center h-full">Loading battle...</div>;
  }
  
  return (
    <div className="relative w-full h-full flex flex-col bg-gray-900 text-white overflow-hidden">
      {/* Battle information */}
      <div className="absolute top-4 left-4 z-10 bg-gray-800/80 p-2 rounded-md">
        <div className="text-sm">Round: {currentRound}</div>
        <div className="flex mt-1 space-x-1">
          {renderMana()}
        </div>
      </div>
      
      {/* Battle phase indicator */}
      <div className="absolute top-4 right-4 z-10 bg-gray-800/80 p-2 rounded-md">
        <div className="text-sm">
          {phase === "playerTurn" ? "Your Turn" : 
           phase === "enemyTurn" ? "Enemy Turn" : 
           phase === "victory" ? "Victory!" : 
           phase === "defeat" ? "Defeat!" : "Battle"}
        </div>
      </div>
      
      {/* Battle field */}
      <div className="flex-grow flex flex-col">
        {/* Enemy area */}
        <div className="flex-1 flex justify-center items-center gap-10 p-4">
          {enemies.map(enemy => (
            <div 
              key={enemy.id}
              onClick={() => handleTargetSelect(enemy)}
              className={cn(
                "cursor-pointer transition-all transform",
                selectedCard && (selectedCard.type === "attack" || selectedCard.type === "debuff") ? "hover:scale-110" : "",
                selectedTarget?.id === enemy.id ? "ring-2 ring-yellow-400" : "",
                shake === enemy.id ? "animate-shake" : ""
              )}
            >
              <Character 
                participant={enemy} 
                isEnemy={true}
                isActive={phase === "enemyTurn"}
              />
            </div>
          ))}
        </div>
        
        {/* Player area */}
        <div className="flex-1 flex justify-center items-center p-4">
          <div 
            onClick={() => handleTargetSelect(player)}
            className={cn(
              "cursor-pointer transition-all transform",
              selectedCard && (selectedCard.type === "heal" || selectedCard.type === "buff") ? "hover:scale-110" : "",
              selectedTarget?.id === player.id ? "ring-2 ring-yellow-400" : "",
              shake === player.id ? "animate-shake" : ""
            )}
          >
            <Character 
              participant={player} 
              isEnemy={false}
              isActive={phase === "playerTurn"}
            />
          </div>
        </div>
      </div>
      
      {/* Battle log */}
      <div className="absolute bottom-[180px] left-4 w-64 bg-gray-800/80 rounded-md p-2 text-xs max-h-40 overflow-y-auto">
        <h3 className="font-bold mb-1">Battle Log</h3>
        {battleLog.map((log, index) => (
          <div key={index} className="mb-1">{log}</div>
        ))}
      </div>
      
      {/* Hand area */}
      <div className="h-[150px] bg-gray-800 p-2 border-t border-gray-700 flex items-center justify-center space-x-2">
        {phase === "playerTurn" ? (
          <>
            {hand.map((card, index) => (
              <div 
                key={index}
                onClick={() => handleCardSelect(card)}
                className={cn(
                  "transform transition-all",
                  selectedCard?.id === card.id ? "scale-110 -translate-y-4" : "hover:scale-105 hover:-translate-y-2",
                  card.manaCost > playerMana ? "opacity-50" : ""
                )}
              >
                <Card card={card} />
              </div>
            ))}
            
            {hand.length === 0 && (
              <div className="text-gray-400">No cards in hand</div>
            )}
          </>
        ) : (
          <div className="text-gray-400">Enemy's turn...</div>
        )}
      </div>
      
      {/* Action buttons */}
      <div className="absolute bottom-4 right-4 flex space-x-2">
        {phase === "playerTurn" && (
          <GameButton onClick={handleEndTurn} variant="secondary">
            End Turn
          </GameButton>
        )}
      </div>
    </div>
  );
};
