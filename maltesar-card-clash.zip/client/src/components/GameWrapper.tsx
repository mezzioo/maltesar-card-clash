import React from 'react';
import { useLocation } from 'react-router-dom';
import { AiCompanion } from './AiCompanion';

interface GameWrapperProps {
  children: React.ReactNode;
}

export const GameWrapper: React.FC<GameWrapperProps> = ({ children }) => {
  const location = useLocation();
  
  // Extract the current screen from the path
  const currentScreen = location.pathname.replace('/', '') || 'home';
  
  return (
    <div className="game-container relative">
      {children}
      <AiCompanion currentScreen={currentScreen} />
    </div>
  );
};