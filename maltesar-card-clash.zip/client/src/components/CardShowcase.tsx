import { useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { CardType } from '../data/cards';
import MagicCard3D from './MagicCard3D';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { useAudio } from '../lib/stores/useAudio';

interface CardShowcaseProps {
  card: CardType;
  onClose?: () => void;
  autoRotate?: boolean;
}

export const CardShowcase: React.FC<CardShowcaseProps> = ({ 
  card, 
  onClose,
  autoRotate = true
}) => {
  const [open, setOpen] = useState(false);
  const { playSound } = useAudio();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const handleOpen = () => {
    setOpen(true);
    playSound('special');
  };
  
  const handleClose = () => {
    setOpen(false);
    if (onClose) onClose();
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          onClick={handleOpen}
          className="bg-gradient-to-r from-purple-600 to-indigo-800 hover:from-purple-700 hover:to-indigo-900 text-white px-4 py-2 rounded-lg shadow-lg transform transition hover:scale-105"
        >
          View 3D
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md md:max-w-xl lg:max-w-2xl xl:max-w-4xl">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-amber-600">
            {card.name}
          </DialogTitle>
          <DialogDescription className="text-center mb-4">
            {card.rarity} • {card.type} • {card.manaCost} Mana
          </DialogDescription>
        </DialogHeader>
        
        <div className="h-[400px] w-full rounded-md overflow-hidden shadow-inner bg-gradient-to-b from-indigo-900/30 to-purple-900/30">
          <Canvas ref={canvasRef} shadows>
            <MagicCard3D scale={2.5} showControls={true} />
          </Canvas>
        </div>
        
        <div className="mt-4 text-center">
          <p className="italic text-sm mb-4">{card.description}</p>
          <Button onClick={handleClose} variant="outline">
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CardShowcase;