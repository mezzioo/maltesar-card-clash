import React, { useState, useEffect } from "react";
import { Card } from "./Card";
import { CardType } from "../data/cards";
import { Character } from "../data/characters";
import { GameButton } from "./ui/game-button";
import { cn } from "@/lib/utils";
import { useCardCollection } from "../lib/stores/useCardCollection";
import { useCurrency } from "../lib/stores/useCurrency";
import { useAudio } from "../lib/stores/useAudio";
import { useGameState } from "../lib/stores/useGameState";

// Helper function to generate a random card based on rarity
const getRandomCard = (cards: CardType[], rarityWeights: Record<string, number>) => {
  // Determine rarity first based on weights
  const rarities = Object.keys(rarityWeights);
  const totalWeight = rarities.reduce((sum, rarity) => sum + rarityWeights[rarity], 0);
  
  let randomValue = Math.random() * totalWeight;
  let selectedRarity: string | null = null;
  
  for (const rarity of rarities) {
    randomValue -= rarityWeights[rarity];
    if (randomValue <= 0) {
      selectedRarity = rarity;
      break;
    }
  }
  
  // Filter cards by rarity
  const rarityCards = cards.filter(card => card.rarity === selectedRarity);
  
  // Return a random card of that rarity
  return rarityCards[Math.floor(Math.random() * rarityCards.length)];
};

// Helper function to generate a random character based on rarity
const getRandomCharacter = (characters: Character[], rarityWeights: Record<string, number>) => {
  // Similar to getRandomCard but for characters
  const rarities = Object.keys(rarityWeights);
  const totalWeight = rarities.reduce((sum, rarity) => sum + rarityWeights[rarity], 0);
  
  let randomValue = Math.random() * totalWeight;
  let selectedRarity: string | null = null;
  
  for (const rarity of rarities) {
    randomValue -= rarityWeights[rarity];
    if (randomValue <= 0) {
      selectedRarity = rarity;
      break;
    }
  }
  
  // Filter characters by rarity
  const rarityCharacters = characters.filter(character => character.rarity === selectedRarity);
  
  // Return a random character of that rarity
  return rarityCharacters[Math.floor(Math.random() * rarityCharacters.length)];
};

interface GachaBannerProps {
  name: string;
  description: string;
  cards: CardType[];
  characters: Character[];
  cost: number;
  currencyType: "gold" | "gems";
  isFreePull?: boolean;
  freePullCooldown?: number; // in seconds
  rarityWeights: Record<string, number>;
  onPull: (results: (CardType | Character)[]) => void;
}

export const GachaBanner: React.FC<GachaBannerProps> = ({
  name,
  description,
  cards,
  characters,
  cost,
  currencyType,
  isFreePull = false,
  freePullCooldown = 86400, // Default 24 hours
  rarityWeights,
  onPull,
}) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [results, setResults] = useState<(CardType | Character)[]>([]);
  const [freePullAvailable, setFreePullAvailable] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);
  
  const { addCard } = useCardCollection();
  const { gold, gems, spendCurrency } = useCurrency();
  const { playHit } = useAudio();
  const { unlockCharacter } = useGameState();
  
  // Check if free pull is available
  useEffect(() => {
    if (isFreePull) {
      const lastPullTime = localStorage.getItem(`lastFreePull_${name}`);
      
      if (!lastPullTime) {
        setFreePullAvailable(true);
      } else {
        const elapsed = Math.floor(Date.now() / 1000) - parseInt(lastPullTime);
        if (elapsed >= freePullCooldown) {
          setFreePullAvailable(true);
        } else {
          setFreePullAvailable(false);
          setTimeRemaining(freePullCooldown - elapsed);
          
          // Set up timer
          const interval = setInterval(() => {
            setTimeRemaining(prev => {
              if (prev <= 1) {
                clearInterval(interval);
                setFreePullAvailable(true);
                return 0;
              }
              return prev - 1;
            });
          }, 1000);
          
          return () => clearInterval(interval);
        }
      }
    }
  }, [isFreePull, name, freePullCooldown]);
  
  // Format time remaining
  const formatTimeRemaining = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  const handlePull = (pullCount: number) => {
    // Check if we can afford the pull
    if (!isFreePull && currencyType === "gold" && gold < cost * pullCount) {
      alert("Not enough gold!");
      return;
    }
    
    if (!isFreePull && currencyType === "gems" && gems < cost * pullCount) {
      alert("Not enough gems!");
      return;
    }
    
    // Spend currency if not a free pull
    if (!isFreePull || !freePullAvailable) {
      const success = spendCurrency(cost * pullCount, currencyType);
      if (!success) {
        alert(`Not enough ${currencyType}!`);
        return;
      }
    } else {
      // Record free pull time
      localStorage.setItem(`lastFreePull_${name}`, Math.floor(Date.now() / 1000).toString());
      setFreePullAvailable(false);
      setTimeRemaining(freePullCooldown);
    }
    
    // Animate the pull
    setIsAnimating(true);
    
    // Play pull sound
    playHit();
    
    // Generate results
    const pullResults: (CardType | Character)[] = [];
    
    for (let i = 0; i < pullCount; i++) {
      // 70% chance for card, 30% chance for character
      if (Math.random() < 0.7) {
        const card = getRandomCard(cards, rarityWeights);
        if (card) pullResults.push(card);
      } else {
        const character = getRandomCharacter(characters, rarityWeights);
        if (character) pullResults.push(character);
      }
    }
    
    // After a delay, show results
    setTimeout(() => {
      setResults(pullResults);
      setIsAnimating(false);
      
      // Add cards to collection and unlock characters
      pullResults.forEach(item => {
        if ('manaCost' in item) {
          // It's a card
          addCard(item.id);
        } else {
          // It's a character - unlock it in the game state
          const character = item as Character;
          unlockCharacter(character.id.toLowerCase());
          console.log(`Obtained character: ${character.name}`);
        }
      });
      
      // Call the onPull callback
      onPull(pullResults);
    }, 2000);
  };
  
  return (
    <div className="relative w-full max-w-2xl bg-gray-800 rounded-lg overflow-hidden shadow-xl">
      {/* Banner header */}
      <div className="bg-gradient-to-r from-indigo-800 to-purple-800 p-4">
        <h2 className="text-xl font-bold text-white">{name}</h2>
        <p className="text-gray-200 text-sm">{description}</p>
      </div>
      
      {/* Banner content */}
      <div className="p-4">
        {isAnimating ? (
          <div className="flex items-center justify-center h-60">
            <div className="text-white text-lg animate-bounce">Summoning...</div>
          </div>
        ) : results.length > 0 ? (
          <div className="flex flex-col items-center">
            <h3 className="text-white mb-4">Pull Results!</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {results.map((item, index) => (
                <div key={index} className="animate-fade-in">
                  {'manaCost' in item ? (
                    <Card card={item as CardType} />
                  ) : (
                    <div className="w-24 h-32 bg-gray-700 rounded-md flex flex-col items-center justify-center p-2">
                      <div 
                        className="w-16 h-16 mb-2" 
                        dangerouslySetInnerHTML={{ __html: (item as Character).portrait }}
                      />
                      <div className="text-xs text-white text-center">
                        {(item as Character).name}
                      </div>
                      <div className={cn(
                        "text-[10px] font-semibold",
                        (item as Character).rarity === "Common" ? "text-gray-300" :
                        (item as Character).rarity === "Rare" ? "text-blue-300" :
                        (item as Character).rarity === "Epic" ? "text-purple-300" :
                        "text-yellow-300"
                      )}>
                        {(item as Character).rarity}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <GameButton 
              className="mt-4"
              onClick={() => setResults([])}
            >
              Done
            </GameButton>
          </div>
        ) : (
          <div className="flex flex-col items-center p-4">
            <div className="grid grid-cols-5 gap-2 mb-6">
              {Array(5).fill(0).map((_, index) => (
                <Card 
                  key={index} 
                  card={cards[0]} // Placeholder card
                  showBack={true} 
                />
              ))}
            </div>
            
            <div className="flex flex-col space-y-3 w-full max-w-xs">
              {isFreePull && (
                <GameButton
                  variant="secondary"
                  onClick={() => handlePull(1)}
                  disabled={!freePullAvailable}
                >
                  {freePullAvailable 
                    ? "Free Daily Pull" 
                    : `Next free pull in: ${formatTimeRemaining(timeRemaining)}`}
                </GameButton>
              )}
              
              <GameButton
                onClick={() => handlePull(1)}
              >
                Single Pull ({cost} {currencyType})
              </GameButton>
              
              <GameButton
                variant="outline"
                onClick={() => handlePull(10)}
              >
                10x Pull ({cost * 10} {currencyType})
              </GameButton>
            </div>
          </div>
        )}
      </div>
      
      {/* Pity counter - could be implemented with state */}
      <div className="bg-gray-900 p-2 text-xs text-center text-gray-400">
        Guaranteed rare or better every 10 pulls! (Pity counter: 0/10)
      </div>
    </div>
  );
};
