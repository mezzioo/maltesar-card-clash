import React, { useState, useEffect } from "react";
import { useQuestSystem, Quest } from "../lib/stores/useQuestSystem";
import { cn } from "@/lib/utils";
import { GameButton } from "./ui/game-button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export const QuestLog: React.FC = () => {
  const {
    dailyQuests,
    weeklyQuests,
    achievements,
    getDailyQuestCompletion,
    claimQuestReward,
    resetDailyQuests,
    resetWeeklyQuests,
    getClaimableQuests
  } = useQuestSystem();

  const [activeTab, setActiveTab] = useState("daily");
  const [claimableCount, setClaimableCount] = useState(0);

  // Update claimable count when quests change
  useEffect(() => {
    const count = getClaimableQuests().length;
    setClaimableCount(count);
  }, [dailyQuests, weeklyQuests, achievements, getClaimableQuests]);

  // Format the display of rewards
  const renderRewards = (quest: Quest) => {
    return (
      <div className="flex flex-wrap gap-2 mt-1">
        {quest.rewards.exp && (
          <div className="bg-blue-900/40 text-blue-300 px-2 py-1 rounded text-xs">
            {quest.rewards.exp} EXP
          </div>
        )}
        {quest.rewards.gold && (
          <div className="bg-amber-900/40 text-amber-300 px-2 py-1 rounded text-xs">
            {quest.rewards.gold} Gold
          </div>
        )}
        {quest.rewards.gems && (
          <div className="bg-purple-900/40 text-purple-300 px-2 py-1 rounded text-xs">
            {quest.rewards.gems} Gems
          </div>
        )}
        {quest.rewards.cardId && (
          <div className="bg-green-900/40 text-green-300 px-2 py-1 rounded text-xs">
            Card Reward
          </div>
        )}
      </div>
    );
  };

  // Render progress bar for quest
  const renderProgress = (quest: Quest) => {
    const progress = quest.objective.progress;
    const target = quest.objective.target;
    const percentage = Math.min(100, (progress / target) * 100);

    return (
      <div className="mt-2">
        <div className="flex justify-between text-xs mb-1">
          <span>Progress</span>
          <span>{progress}/{target}</span>
        </div>
        <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className={cn(
              "h-full transition-all duration-300",
              quest.completed ? "bg-green-500" : "bg-blue-500"
            )}
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
      </div>
    );
  };

  // Render a quest item
  const renderQuest = (quest: Quest) => {
    return (
      <div 
        key={quest.id}
        className={cn(
          "bg-gray-800 p-3 rounded-md mb-3 border-l-4",
          quest.completed && !quest.claimed ? "border-green-500" : "border-gray-700",
          quest.claimed && "opacity-60"
        )}
      >
        <div className="flex justify-between">
          <h3 className="font-semibold">{quest.title}</h3>
          {quest.completed && !quest.claimed && (
            <span className="text-green-400 text-xs bg-green-900/30 px-2 py-1 rounded-full">
              Complete
            </span>
          )}
          {quest.claimed && (
            <span className="text-gray-400 text-xs bg-gray-700 px-2 py-1 rounded-full">
              Claimed
            </span>
          )}
        </div>
        
        <p className="text-sm text-gray-400 mt-1">{quest.description}</p>
        
        {renderProgress(quest)}
        {renderRewards(quest)}
        
        {quest.completed && !quest.claimed && (
          <GameButton 
            onClick={() => claimQuestReward(quest.id)}
            variant="success"
            className="mt-3 w-full"
          >
            Claim Reward
          </GameButton>
        )}
      </div>
    );
  };

  // Daily quest completion percentage
  const dailyCompletion = getDailyQuestCompletion();

  return (
    <div className="bg-gray-900 text-white p-4 h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Quest Log</h2>
        
        {claimableCount > 0 && (
          <div className="bg-green-900/30 text-green-300 px-3 py-1 rounded-full text-sm">
            {claimableCount} {claimableCount === 1 ? 'reward' : 'rewards'} available
          </div>
        )}
      </div>
      
      {/* Daily progress */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-1">
          <span className="text-sm">Daily Quest Completion</span>
          <span className="text-sm">{Math.floor(dailyCompletion)}%</span>
        </div>
        <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-amber-500" 
            style={{ width: `${dailyCompletion}%` }}
          ></div>
        </div>
      </div>
      
      {/* Quest tabs */}
      <Tabs defaultValue="daily" value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="daily" className="relative">
            Daily
            {dailyQuests.some(q => q.completed && !q.claimed) && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full"></span>
            )}
          </TabsTrigger>
          <TabsTrigger value="weekly" className="relative">
            Weekly
            {weeklyQuests.some(q => q.completed && !q.claimed) && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full"></span>
            )}
          </TabsTrigger>
          <TabsTrigger value="achievements" className="relative">
            Achievements
            {achievements.some(q => q.completed && !q.claimed) && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full"></span>
            )}
          </TabsTrigger>
        </TabsList>
        
        <div className="flex-1 overflow-y-auto">
          <TabsContent value="daily" className="h-full">
            {dailyQuests.length > 0 ? (
              dailyQuests.map(renderQuest)
            ) : (
              <div className="text-center py-8 text-gray-400">
                No daily quests available.
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="weekly" className="h-full">
            {weeklyQuests.length > 0 ? (
              weeklyQuests.map(renderQuest)
            ) : (
              <div className="text-center py-8 text-gray-400">
                No weekly quests available.
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="achievements" className="h-full">
            {achievements.length > 0 ? (
              achievements.map(renderQuest)
            ) : (
              <div className="text-center py-8 text-gray-400">
                No achievements available.
              </div>
            )}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};