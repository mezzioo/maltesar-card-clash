import React from "react";
import { useLocation, useRoute, Link } from "wouter";
import { cn } from "@/lib/utils";
import { useGameState } from "@/lib/stores/useGameState";
import { useAudio } from "@/lib/stores/useAudio";
import { AlertCircle, BookOpen, User, ShoppingBag, Map, PlaySquare, Volume2, VolumeX } from "lucide-react";

export const GameHeader: React.FC = () => {
  const [location, setLocation] = useLocation();
  const { level, gold, gems } = useGameState();
  const { toggleMute, isMuted } = useAudio();
  
  // Define navigation items
  const navItems = [
    { path: "/", icon: <BookOpen size={20} />, label: "Story" },
    { path: "/dungeon", icon: <Map size={20} />, label: "Dungeon" },
    { path: "/battle", icon: <PlaySquare size={20} />, label: "Battle" },
    { path: "/summon", icon: <AlertCircle size={20} />, label: "Summon" },
    { path: "/inventory", icon: <User size={20} />, label: "Inventory" },
    { path: "/shop", icon: <ShoppingBag size={20} />, label: "Shop" },
  ];
  
  return (
    <header className="w-full bg-gray-800 border-b-2 border-gray-700 px-4 py-2 z-10">
      <div className="flex justify-between items-center">
        {/* Game title and logo */}
        <div className="flex items-center">
          <h1 className="text-xl font-bold mr-2 text-white">Maltesar Card Clash</h1>
          <div className="hidden md:block text-sm text-gray-400">Trials of the Academy</div>
        </div>
        
        {/* Player stats */}
        <div className="flex items-center gap-4">
          {/* Level badge */}
          <div className="bg-blue-700 rounded-full w-8 h-8 flex items-center justify-center">
            <span className="text-white font-bold text-sm">Lv{level}</span>
          </div>
          
          {/* Gold counter */}
          <div className="flex items-center">
            <div className="w-5 h-5 bg-yellow-500 rounded-full mr-1"></div>
            <span className="text-white">{gold}</span>
          </div>
          
          {/* Gems counter */}
          <div className="flex items-center">
            <div className="w-5 h-5 bg-purple-500 rounded-full mr-1"></div>
            <span className="text-white">{gems}</span>
          </div>
          
          {/* Audio toggle */}
          <button 
            className="p-2 rounded-full hover:bg-gray-700 transition"
            onClick={toggleMute}
          >
            {isMuted ? (
              <VolumeX size={20} className="text-gray-400" />
            ) : (
              <Volume2 size={20} className="text-white" />
            )}
          </button>
        </div>
      </div>
      
      {/* Navigation tabs */}
      <nav className="flex mt-2 space-x-1 overflow-x-auto pb-1 scrollbar-none">
        {navItems.map((item) => {
          const isActive = location === item.path;
          
          return (
            <Link 
              key={item.path} 
              href={item.path}
              onClick={() => setLocation(item.path)}
            >
              <a className={cn(
                "flex items-center px-4 py-1 rounded-t-md transition-colors",
                "text-sm font-medium",
                isActive
                  ? "bg-gray-700 text-white"
                  : "text-gray-400 hover:text-white hover:bg-gray-700/50"
              )}>
                <span className="mr-2">{item.icon}</span>
                <span>{item.label}</span>
              </a>
            </Link>
          );
        })}
      </nav>
    </header>
  );
};
