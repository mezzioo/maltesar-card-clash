import React, { useState, useEffect } from "react";
import { dungeons, Dungeon, DungeonStage, DungeonEvent } from "../data/dungeons";
import { useDungeon } from "../lib/stores/useDungeon";
import { useGameState } from "../lib/stores/useGameState";
import { GameButton } from "./ui/game-button";
import { cn } from "@/lib/utils";

interface DungeonMapProps {
  onSelectDungeon: (dungeonId: string) => void;
  onSelectEvent: (event: DungeonEvent) => void;
}

export const DungeonMap: React.FC<DungeonMapProps> = ({ onSelectDungeon, onSelectEvent }) => {
  const { 
    currentDungeonId, 
    dungeonHistory, 
    isDungeonCompleted,
    getCurrentDungeon,
    getCurrentStage,
    getNextEvent,
    getProgress
  } = useDungeon();
  
  const { playerLevel, dungeonProgress } = useGameState();
  
  const [availableDungeons, setAvailableDungeons] = useState<Dungeon[]>([]);
  const [selectedDungeonId, setSelectedDungeonId] = useState<string | null>(currentDungeonId);
  
  // Set up available dungeons - make all dungeons available for testing
  useEffect(() => {
    // Make all dungeons available for easier testing
    const unlocked = dungeons;
    
    setAvailableDungeons(unlocked);
    
    // If we have a current dungeon, select it by default
    if (currentDungeonId) {
      setSelectedDungeonId(currentDungeonId);
    } else if (unlocked.length > 0 && !selectedDungeonId) {
      setSelectedDungeonId(unlocked[0].id);
    }
  }, [currentDungeonId, selectedDungeonId]);
  
  // Get details of selected dungeon
  const selectedDungeon = dungeons.find(d => d.id === selectedDungeonId);
  
  // Handle dungeon selection
  const handleSelectDungeon = (dungeonId: string) => {
    setSelectedDungeonId(dungeonId);
  };
  
  // Handle enter dungeon
  const handleEnterDungeon = () => {
    if (selectedDungeonId) {
      onSelectDungeon(selectedDungeonId);
    }
  };
  
  // Handle continue current dungeon
  const handleContinueDungeon = () => {
    if (currentDungeonId) {
      const nextEvent = getNextEvent();
      if (nextEvent) {
        onSelectEvent(nextEvent);
      }
    }
  };
  
  // Render dungeon progress bar
  const renderProgressBar = () => {
    const progress = getProgress();
    
    return (
      <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-green-500 transition-all duration-300" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    );
  };
  
  // Render current dungeon info
  const renderCurrentDungeon = () => {
    const dungeon = getCurrentDungeon();
    const stage = getCurrentStage();
    
    if (!dungeon || !stage) return null;
    
    return (
      <div className="mb-6 bg-gray-800 p-4 rounded-md">
        <h3 className="text-lg font-semibold">{dungeon.name}</h3>
        <p className="text-sm text-gray-300 mb-2">{dungeon.description}</p>
        
        <div className="mb-2">
          <div className="flex justify-between text-xs mb-1">
            <span>Current Stage: {stage.name}</span>
            <span>Progress</span>
          </div>
          {renderProgressBar()}
        </div>
        
        <GameButton onClick={handleContinueDungeon}>Continue Dungeon</GameButton>
      </div>
    );
  };
  
  return (
    <div className="h-full flex flex-col bg-gray-900 text-white p-4">
      <h2 className="text-xl font-semibold mb-4">Dungeon Map</h2>
      
      {/* Current dungeon info (if in a dungeon) */}
      {currentDungeonId && renderCurrentDungeon()}
      
      {/* Dungeon selection - Flex col on mobile, row on larger screens */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Dungeon list */}
        <div className="w-full md:w-1/3 md:pr-4 border-b md:border-b-0 md:border-r border-gray-800 overflow-y-auto mb-4 md:mb-0 pb-4 md:pb-0">
          <h3 className="text-lg font-semibold mb-3">Available Dungeons</h3>
          
          <div className="space-y-2">
            {availableDungeons.map(dungeon => (
              <div
                key={dungeon.id}
                className={cn(
                  "p-2 rounded-md cursor-pointer transition-colors",
                  isDungeonCompleted(dungeon.id) ? "bg-green-900/30" : "bg-gray-800",
                  selectedDungeonId === dungeon.id ? "ring-2 ring-amber-500" : "",
                  currentDungeonId === dungeon.id ? "bg-blue-900/30" : ""
                )}
                onClick={() => handleSelectDungeon(dungeon.id)}
              >
                <div className="flex justify-between items-center">
                  <span className="font-medium">{dungeon.name}</span>
                  <span className="text-xs">
                    {isDungeonCompleted(dungeon.id) ? "Completed" : `Difficulty: ${dungeon.difficulty}`}
                  </span>
                </div>
                
                {currentDungeonId === dungeon.id && (
                  <div className="mt-1">
                    <div className="text-xs mb-1">Progress</div>
                    {renderProgressBar()}
                  </div>
                )}
              </div>
            ))}
            
            {availableDungeons.length === 0 && (
              <div className="text-center py-4 text-gray-400 text-sm">
                No dungeons available yet. Level up or complete story chapters to unlock more.
              </div>
            )}
          </div>
        </div>
        
        {/* Dungeon details */}
        <div className="w-full md:w-2/3 md:pl-4 overflow-y-auto">
          {selectedDungeon ? (
            <div>
              <h3 className="text-xl font-semibold mb-2">{selectedDungeon.name}</h3>
              <p className="text-sm text-gray-300 mb-4">{selectedDungeon.description}</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm mb-4">
                <div className="bg-gray-800 p-2 rounded">
                  <span className="text-gray-400">Difficulty:</span>
                  <div className="flex mt-1">
                    {Array(5).fill(0).map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-4 h-4 rounded-full mr-1 ${i < selectedDungeon.difficulty ? 'bg-red-500' : 'bg-gray-600'}`} 
                      />
                    ))}
                  </div>
                </div>
                <div className="bg-gray-800 p-2 rounded">
                  <span className="text-gray-400">Status:</span>
                  <span className={`block ${isDungeonCompleted(selectedDungeon.id) ? 'text-green-400' : 'text-yellow-400'}`}>
                    {isDungeonCompleted(selectedDungeon.id) ? 'Completed' : 'Available'}
                  </span>
                </div>
              </div>
              
              <div className="mb-4">
                <h4 className="font-semibold mb-2">Rewards:</h4>
                <div className="bg-gray-800 p-3 rounded text-sm">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {selectedDungeon.reward.exp && (
                      <div className="mb-1">
                        <span className="text-gray-400">EXP:</span>
                        <span className="ml-2 text-green-400">{selectedDungeon.reward.exp}</span>
                      </div>
                    )}
                    {selectedDungeon.reward.currency && (
                      <div className="mb-1">
                        <span className="text-gray-400">Currency:</span>
                        <span className="ml-2 text-amber-400">{selectedDungeon.reward.currency} Gold</span>
                      </div>
                    )}
                    {selectedDungeon.reward.cards && selectedDungeon.reward.cards.length > 0 && (
                      <div className="mb-1">
                        <span className="text-gray-400">Cards:</span>
                        <span className="ml-2 text-blue-400">{selectedDungeon.reward.cards.length} card(s)</span>
                      </div>
                    )}
                    {selectedDungeon.reward.characters && selectedDungeon.reward.characters.length > 0 && (
                      <div>
                        <span className="text-gray-400">Characters:</span>
                        <span className="ml-2 text-purple-400">{selectedDungeon.reward.characters.join(', ')}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <h4 className="font-semibold mb-2">Stages:</h4>
              <div className="space-y-2 mb-6">
                {selectedDungeon.stages.map((stage, index) => (
                  <div key={index} className="bg-gray-800 p-3 rounded">
                    <h5 className="font-medium">{stage.name}</h5>
                    <p className="text-sm text-gray-300 mb-2">{stage.description}</p>
                    <div className="text-xs text-gray-400">
                      {stage.events.filter(e => e.type === "battle").length} battles
                      {stage.events.filter(e => e.type === "story").length > 0 ? ', story events' : ''}
                      {stage.events.filter(e => e.type === "reward").length > 0 ? ', rewards' : ''}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex justify-center mb-6">
                {currentDungeonId === selectedDungeon.id ? (
                  <GameButton onClick={handleContinueDungeon} variant="secondary" className="w-full sm:w-auto">
                    Continue Dungeon
                  </GameButton>
                ) : (
                  <GameButton 
                    onClick={handleEnterDungeon}
                    disabled={currentDungeonId !== null} // Can't enter a new dungeon while in another
                    className="w-full sm:w-auto"
                  >
                    Enter Dungeon
                  </GameButton>
                )}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              Select a dungeon to view details
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
