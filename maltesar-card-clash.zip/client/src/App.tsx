import { Suspense, useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "sonner";

// Pages
import HomePage from "./pages/HomePage";
import BattlePage from "./pages/BattlePage";
import CollectionPage from "./pages/CollectionPage";
import DungeonPage from "./pages/DungeonPage";
import GachaPage from "./pages/GachaPage";
import ShopPage from "./pages/ShopPage";
import StoryPage from "./pages/StoryPage";
import QuestsPage from "./pages/QuestsPage";
import GuildPage from "./pages/GuildPage";
import NotFound from "./pages/not-found";

// Components
import { GameWrapper } from "./components/GameWrapper";

// Contexts
import { GameContextProvider } from "./contexts/GameContext";
import { CardContextProvider } from "./contexts/CardContext";

// Styles
import "@fontsource/inter";
import "./assets/pixelStyles.css";

// Initialize audio
import { useAudio } from "./lib/stores/useAudio";
import { Howl } from "howler";

function App() {
  const { 
    setBackgroundMusic,
    setHitSound,
    setSuccessSound,
    setBattleSound,
    setCardFlipSound,
    setVictorySound,
    setGachaPullSound,
    playBackgroundMusic
  } = useAudio();

  // Initialize sounds on app load
  useEffect(() => {
    // Background music
    const bgMusic = new Howl({
      src: ["/sounds/background.mp3"],
      loop: true,
      volume: 0.3,
      preload: true,
    });

    // Hit sound
    const hitSfx = new Howl({
      src: ["/sounds/hit.mp3"],
      volume: 0.5,
      preload: true,
    });

    // Success sound
    const successSfx = new Howl({
      src: ["/sounds/success.mp3"],
      volume: 0.5,
      preload: true,
    });

    // Battle sound
    const battleSfx = new Howl({
      src: ["/sounds/battle.mp3"],
      loop: true,
      volume: 0.4,
      preload: true,
    });

    // Card flip sound
    const cardFlipSfx = new Howl({
      src: ["/sounds/card-flip.mp3"],
      volume: 0.4,
      preload: true,
    });

    // Victory sound
    const victorySfx = new Howl({
      src: ["/sounds/victory.mp3"],
      volume: 0.5,
      preload: true,
    });

    // Gacha pull sound
    const gachaPullSfx = new Howl({
      src: ["/sounds/gacha-pull.mp3"],
      volume: 0.5,
      preload: true,
    });

    // Set the sounds in the store
    setBackgroundMusic(bgMusic);
    setHitSound(hitSfx);
    setSuccessSound(successSfx);
    setBattleSound(battleSfx);
    setCardFlipSound(cardFlipSfx);
    setVictorySound(victorySfx);
    setGachaPullSound(gachaPullSfx);

    // Play background music when app loads with proper error handling and retries
    const startBackgroundMusic = () => {
      try {
        // Attempt to start playing music
        playBackgroundMusic();
        
        // Check if music actually started
        const { backgroundMusic } = useAudio.getState();
        if (backgroundMusic && !backgroundMusic.playing()) {
          console.log("Music initialization delayed, retrying...");
          setTimeout(startBackgroundMusic, 1000);
        } else {
          console.log("Background music started successfully");
        }
      } catch (error) {
        console.error("Error starting background music:", error);
        setTimeout(startBackgroundMusic, 2000);
      }
    };
    
    // Initial delay for sounds to load
    setTimeout(startBackgroundMusic, 1000);

    // Clean up sounds on unmount
    return () => {
      bgMusic.unload();
      hitSfx.unload();
      successSfx.unload();
      battleSfx.unload();
      cardFlipSfx.unload();
      victorySfx.unload();
      gachaPullSfx.unload();
    };
  }, [
    setBackgroundMusic, 
    setHitSound, 
    setSuccessSound, 
    setBattleSound,
    setCardFlipSound,
    setVictorySound,
    setGachaPullSound,
    playBackgroundMusic
  ]);

  return (
    <QueryClientProvider client={queryClient}>
      <Suspense fallback={<div>Loading...</div>}>
        <GameContextProvider>
          <CardContextProvider>
            <Router>
              <GameWrapper>
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/battle" element={<BattlePage />} />
                  <Route path="/collection" element={<CollectionPage />} />
                  <Route path="/dungeon" element={<DungeonPage />} />
                  <Route path="/gacha" element={<GachaPage />} />
                  <Route path="/shop" element={<ShopPage />} />
                  <Route path="/story" element={<StoryPage />} />
                  <Route path="/quests" element={<QuestsPage />} />
                  <Route path="/guild" element={<GuildPage />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </GameWrapper>
            </Router>
          </CardContextProvider>
        </GameContextProvider>
      </Suspense>
      <Toaster position="top-right" />
    </QueryClientProvider>
  );
}

export default App;
