import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  created_at: timestamp("created_at").defaultNow(),
  last_login: timestamp("last_login"),
  is_admin: boolean("is_admin").default(false),
});

// Game profiles table to store player progress
export const gameProfiles = pgTable("game_profiles", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  player_name: text("player_name").notNull(),
  player_level: integer("player_level").default(1),
  player_exp: integer("player_exp").default(0),
  gold: integer("gold").default(100),
  gems: integer("gems").default(10),
  tutorial_completed: boolean("tutorial_completed").default(false),
  story_progress: integer("story_progress").default(0),
  dungeon_progress: integer("dungeon_progress").default(0),
  unlocked_characters: json("unlocked_characters").$type<string[]>().default(['hamid', 'soraya']),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
});

// Cards collection table
export const cardCollection = pgTable("card_collection", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  card_id: text("card_id").notNull(),
  card_level: integer("card_level").default(1),
  card_exp: integer("card_exp").default(0),
  in_deck: boolean("in_deck").default(false),
  obtained_at: timestamp("obtained_at").defaultNow(),
});

// Decks table
export const decks = pgTable("decks", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  character_id: text("character_id"),
  is_active: boolean("is_active").default(false),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
});

// Deck cards junction table
export const deckCards = pgTable("deck_cards", {
  id: serial("id").primaryKey(),
  deck_id: integer("deck_id").references(() => decks.id).notNull(),
  card_collection_id: integer("card_collection_id").references(() => cardCollection.id).notNull(),
  position: integer("position").default(0),
});

// Gacha history table
export const gachaHistory = pgTable("gacha_history", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  item_type: text("item_type").notNull(), // 'card' or 'character'
  item_id: text("item_id").notNull(),
  banner_type: text("banner_type").notNull(), // 'standard' or 'premium'
  cost: integer("cost").notNull(),
  currency_type: text("currency_type").notNull(), // 'gold' or 'gems'
  pulled_at: timestamp("pulled_at").defaultNow(),
});

// Story progress table
export const storyProgress = pgTable("story_progress", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  chapter_id: text("chapter_id").notNull(),
  completed: boolean("completed").default(false),
  choices: json("choices").$type<number[]>().default([]),
  completed_at: timestamp("completed_at"),
});

// Dungeon progress table
export const dungeonProgress = pgTable("dungeon_progress", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  dungeon_id: text("dungeon_id").notNull(),
  completed: boolean("completed").default(false),
  times_completed: integer("times_completed").default(0),
  last_completed_at: timestamp("last_completed_at"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export const insertGameProfileSchema = createInsertSchema(gameProfiles).pick({
  user_id: true,
  player_name: true,
});

export const insertCardCollectionSchema = createInsertSchema(cardCollection).pick({
  user_id: true,
  card_id: true,
});

export const insertDeckSchema = createInsertSchema(decks).pick({
  user_id: true,
  name: true,
  character_id: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGameProfile = z.infer<typeof insertGameProfileSchema>;
export type GameProfile = typeof gameProfiles.$inferSelect;

export type InsertCardCollection = z.infer<typeof insertCardCollectionSchema>;
export type CardCollectionItem = typeof cardCollection.$inferSelect;

export type InsertDeck = z.infer<typeof insertDeckSchema>;
export type Deck = typeof decks.$inferSelect;
