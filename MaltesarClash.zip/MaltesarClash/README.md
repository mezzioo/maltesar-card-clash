# Maltesar Card Clash - Trials of the Academy

A dynamic 2D card-based RPG game featuring collectible anime characters with an immersive turn-based combat system and engaging dungeon exploration mechanics.

## Features

- Dynamic card-based combat system
- Character collection through gacha mechanics
- Dungeon exploration
- Story-based progression
- Guild system

## Technologies

- React with TypeScript
- Zustand for state management
- Tailwind CSS for styling
- Custom card collection and deck-building systems
- Interactive storytelling components

## Getting Started

```bash
# Install dependencies
npm install

# Run the development server
npm run dev

# Build for production
npm run build
```

## How to Play

1. Start with the default character (Hamid)
2. Complete quests to earn currency
3. Use the gacha system to unlock new characters
4. Build your deck and battle in dungeons
5. Progress through the story to unlock new features

## Deployment

This game is deployed using Vercel. Visit [Maltesar Card Clash](https://maltesar-card-clash.vercel.app) to play!