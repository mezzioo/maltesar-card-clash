import React, { createContext, useContext, ReactNode, useEffect } from 'react';
import { useGameState } from '../lib/stores/useGameState';
import { useCurrency } from '../lib/stores/useCurrency';
import { useCardCollection } from '../lib/stores/useCardCollection';

// Context interface
interface GameContextInterface {
  // Game state
  playerName: string;
  playerLevel: number;
  playerExp: number;
  expToNextLevel: number;
  tutorialCompleted: boolean;
  storyProgress: number;
  dungeonProgress: number;
  
  // Currency state
  gold: number;
  gems: number;
  
  // Actions
  gainExp: (amount: number) => void;
  addCurrency: (amount: number, type?: "gold" | "gems") => void;
  spendCurrency: (amount: number, type: "gold" | "gems") => boolean;
  unlockCharacter: (characterId: string) => void;
}

// Create context with default values
const GameContext = createContext<GameContextInterface>({
  playerName: 'Player',
  playerLevel: 1,
  playerExp: 0,
  expToNextLevel: 100,
  tutorialCompleted: false,
  storyProgress: 0,
  dungeonProgress: 0,
  gold: 0,
  gems: 0,
  gainExp: () => {},
  addCurrency: () => {},
  spendCurrency: () => false,
  unlockCharacter: () => {},
});

// Hook to use the game context
export const useGame = () => useContext(GameContext);

// Game context provider
export const GameContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Get state and actions from the zustand stores
  const {
    playerName,
    playerLevel,
    playerExp,
    expToNextLevel,
    tutorialCompleted,
    storyProgress,
    dungeonProgress,
    gainExp,
    unlockCharacter,
  } = useGameState();
  
  const { gold, gems, addCurrency, spendCurrency } = useCurrency();
  const { addCard } = useCardCollection();
  
  // Initial setup - add starter cards if needed
  useEffect(() => {
    // Add basic cards to the player's collection if they're new
    const hasStarterCards = localStorage.getItem('maltesar-starter-cards');
    
    if (!hasStarterCards) {
      // Clear localStorage to ensure a fresh start
      localStorage.removeItem('maltesar-card-collection');
      
      console.log("Adding starter cards to collection");
      
      // Add basic cards
      addCard('basic-strike');
      addCard('defensive-stance');
      addCard('healing-touch');
      addCard('power-up');
      addCard('weaken');
      
      // Add character specific cards for starter characters
      addCard('shield-wall'); // Hamid
      addCard('endurance'); // Hamid
      addCard('strategic-planning'); // Soraya
      addCard('critical-analysis'); // Soraya
      addCard('power-strike'); // Faris
      addCard('rage'); // Faris
      
      // Mark that we've added starter cards
      localStorage.setItem('maltesar-starter-cards', 'true');
    }
  }, [addCard]);
  
  // Create the context value
  const contextValue: GameContextInterface = {
    playerName,
    playerLevel,
    playerExp,
    expToNextLevel,
    tutorialCompleted,
    storyProgress,
    dungeonProgress,
    gold,
    gems,
    gainExp,
    addCurrency,
    spendCurrency,
    unlockCharacter,
  };
  
  return (
    <GameContext.Provider value={contextValue}>
      {children}
    </GameContext.Provider>
  );
};
