import React, { useState, useEffect } from "react";
import { useCurrency, ShopItem } from "../lib/stores/useCurrency";
import { useCardCollection } from "../lib/stores/useCardCollection";
import { cards, getCardById } from "../data/cards";
import { characters, getCharacterById } from "../data/characters";
import { Card } from "./Card";
import { GameButton } from "./ui/game-button";
import { useAudio } from "../lib/stores/useAudio";
import { cn } from "@/lib/utils";

// Generate shop items
const generateShopItems = (): ShopItem[] => {
  const shopItems: ShopItem[] = [];
  
  // Add card items
  cards.forEach(card => {
    // Skip some basic cards that should be earned through gameplay
    if (card.id === "basic-strike" || card.id === "defensive-stance") return;
    
    // Calculate cost based on rarity
    let cost = 0;
    let currencyType: "gold" | "gems" = "gold";
    
    switch (card.rarity) {
      case "Common":
        cost = 100;
        currencyType = "gold";
        break;
      case "Rare":
        cost = 300;
        currencyType = "gold";
        break;
      case "Epic":
        cost = 800;
        currencyType = "gold";
        break;
      case "Legendary":
        cost = 25;
        currencyType = "gems";
        break;
    }
    
    shopItems.push({
      id: `card-${card.id}`,
      name: card.name,
      description: card.description,
      cost,
      currencyType,
      type: "card",
      itemId: card.id,
      available: true
    });
  });
  
  // Add character items (only special ones that require purchase)
  characters.forEach(character => {
    // Skip starter characters
    if (character.id === "hamid" || character.id === "soraya") return;
    
    // Skip characters with unlock conditions
    if (character.unlockCondition) return;
    
    // Calculate cost based on rarity
    let cost = 0;
    let currencyType: "gold" | "gems" = "gems";
    
    switch (character.rarity) {
      case "Common":
        cost = 10;
        break;
      case "Rare":
        cost = 25;
        break;
      case "Epic":
        cost = 50;
        break;
      case "Legendary":
        cost = 100;
        break;
    }
    
    shopItems.push({
      id: `character-${character.id}`,
      name: character.name,
      description: character.description,
      cost,
      currencyType,
      type: "character",
      itemId: character.id,
      available: true
    });
  });
  
  return shopItems;
};

interface ShopProps {
  onPurchase?: (item: ShopItem) => void;
}

export const Shop: React.FC<ShopProps> = ({ onPurchase }) => {
  const { gold, gems, purchaseItem, hasPurchased } = useCurrency();
  const { addCard } = useCardCollection();
  const { playSuccess } = useAudio();
  
  const [shopItems, setShopItems] = useState<ShopItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<ShopItem | null>(null);
  const [filter, setFilter] = useState<"all" | "cards" | "characters" | "gold" | "gems">("all");
  
  // Initialize shop items
  useEffect(() => {
    const items = generateShopItems();
    setShopItems(items);
    
    if (items.length > 0) {
      setSelectedItem(items[0]);
    }
  }, []);
  
  // Handle item selection
  const handleSelectItem = (item: ShopItem) => {
    setSelectedItem(item);
  };
  
  // Handle purchase
  const handlePurchase = () => {
    if (!selectedItem) return;
    
    const result = purchaseItem(selectedItem.id);
    
    if (result.success) {
      playSuccess();
      
      // Handle the purchased item
      if (selectedItem.type === "card") {
        // Add card to collection
        addCard(selectedItem.itemId);
      } else if (selectedItem.type === "character") {
        // Character would be handled by character collection system
        console.log(`Purchased character: ${selectedItem.name}`);
      }
      
      // Call onPurchase callback
      if (onPurchase) onPurchase(selectedItem);
      
      // Update UI
      setShopItems(prev => 
        prev.map(item => 
          item.id === selectedItem.id 
            ? { ...item, available: false } 
            : item
        )
      );
    } else {
      alert(result.message);
    }
  };
  
  // Filter shop items
  const filteredItems = shopItems.filter(item => {
    if (filter === "all") return true;
    if (filter === "cards" && item.type === "card") return true;
    if (filter === "characters" && item.type === "character") return true;
    if (filter === "gold" && item.currencyType === "gold") return true;
    if (filter === "gems" && item.currencyType === "gems") return true;
    return false;
  });
  
  // Render item details for cards
  const renderCardDetails = (cardId: string) => {
    const card = getCardById(cardId);
    if (!card) return null;
    
    return (
      <div className="flex flex-col items-center">
        <Card card={card} className="mb-4" />
        <div className="text-sm text-gray-300">{card.description}</div>
        
        <div className="mt-4 grid grid-cols-2 gap-2 w-full text-xs">
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Type:</span>
            <span className="block">{card.type.charAt(0).toUpperCase() + card.type.slice(1)}</span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Rarity:</span>
            <span 
              className={cn(
                "block",
                card.rarity === "Common" ? "text-gray-300" :
                card.rarity === "Rare" ? "text-blue-300" :
                card.rarity === "Epic" ? "text-purple-300" :
                "text-yellow-300"
              )}
            >
              {card.rarity}
            </span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Mana Cost:</span>
            <span className="block">{card.manaCost}</span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Value:</span>
            <span className="block">{card.value}</span>
          </div>
        </div>
      </div>
    );
  };
  
  // Render item details for characters
  const renderCharacterDetails = (characterId: string) => {
    const character = getCharacterById(characterId);
    if (!character) return null;
    
    return (
      <div className="flex flex-col items-center">
        <div 
          className="w-32 h-32 mb-4"
          dangerouslySetInnerHTML={{ __html: character.portrait }}
        />
        
        <div className="text-sm text-gray-300 mb-4">{character.description}</div>
        
        <div className="grid grid-cols-2 gap-2 w-full text-xs">
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Rarity:</span>
            <span 
              className={cn(
                "block",
                character.rarity === "Common" ? "text-gray-300" :
                character.rarity === "Rare" ? "text-blue-300" :
                character.rarity === "Epic" ? "text-purple-300" :
                "text-yellow-300"
              )}
            >
              {character.rarity}
            </span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Element:</span>
            <span className="block">{character.element}</span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">HP:</span>
            <span className="block">{character.baseHP}</span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Attack:</span>
            <span className="block">{character.baseAttack}</span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Defense:</span>
            <span className="block">{character.baseDefense}</span>
          </div>
          <div className="bg-gray-800 p-2 rounded">
            <span className="text-gray-400">Speed:</span>
            <span className="block">{character.baseSpeed}</span>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="h-full flex flex-col bg-gray-900 text-white">
      {/* Shop header */}
      <div className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700">
        <h2 className="text-xl font-semibold">Academy Shop</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center bg-amber-800/50 px-3 py-1 rounded-md">
            <span className="text-amber-300 mr-1">Gold:</span>
            <span>{gold}</span>
          </div>
          <div className="flex items-center bg-purple-800/50 px-3 py-1 rounded-md">
            <span className="text-purple-300 mr-1">Gems:</span>
            <span>{gems}</span>
          </div>
        </div>
      </div>
      
      {/* Filter buttons */}
      <div className="bg-gray-800 p-2 flex border-b border-gray-700">
        <div className="flex space-x-2">
          <button 
            className={`px-3 py-1 rounded-md text-sm ${filter === "all" ? "bg-blue-600" : "bg-gray-700"}`}
            onClick={() => setFilter("all")}
          >
            All
          </button>
          <button 
            className={`px-3 py-1 rounded-md text-sm ${filter === "cards" ? "bg-blue-600" : "bg-gray-700"}`}
            onClick={() => setFilter("cards")}
          >
            Cards
          </button>
          <button 
            className={`px-3 py-1 rounded-md text-sm ${filter === "characters" ? "bg-blue-600" : "bg-gray-700"}`}
            onClick={() => setFilter("characters")}
          >
            Characters
          </button>
          <button 
            className={`px-3 py-1 rounded-md text-sm ${filter === "gold" ? "bg-blue-600" : "bg-gray-700"}`}
            onClick={() => setFilter("gold")}
          >
            Gold Items
          </button>
          <button 
            className={`px-3 py-1 rounded-md text-sm ${filter === "gems" ? "bg-blue-600" : "bg-gray-700"}`}
            onClick={() => setFilter("gems")}
          >
            Gem Items
          </button>
        </div>
      </div>
      
      {/* Shop content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Item list */}
        <div className="w-2/3 p-4 overflow-y-auto">
          <div className="grid grid-cols-3 gap-4">
            {filteredItems.map(item => (
              <div
                key={item.id}
                className={cn(
                  "bg-gray-800 p-3 rounded-md cursor-pointer transition-all",
                  selectedItem?.id === item.id ? "ring-2 ring-amber-500" : "",
                  hasPurchased(item.id) ? "opacity-50" : ""
                )}
                onClick={() => handleSelectItem(item)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium">{item.name}</h3>
                  <div 
                    className={`px-2 py-1 rounded text-xs ${item.currencyType === "gold" ? "bg-amber-800/50 text-amber-300" : "bg-purple-800/50 text-purple-300"}`}
                  >
                    {item.cost} {item.currencyType === "gold" ? "Gold" : "Gems"}
                  </div>
                </div>
                
                <p className="text-xs text-gray-400 line-clamp-2 mb-2">{item.description}</p>
                
                <div className="flex justify-between items-center">
                  <span 
                    className={`text-xs ${item.type === "card" ? "text-blue-400" : "text-green-400"}`}
                  >
                    {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                  </span>
                  
                  {hasPurchased(item.id) && (
                    <span className="text-xs text-green-400">Owned</span>
                  )}
                </div>
              </div>
            ))}
            
            {filteredItems.length === 0 && (
              <div className="col-span-3 text-center py-8 text-gray-400">
                No items found in this category.
              </div>
            )}
          </div>
        </div>
        
        {/* Item details */}
        <div className="w-1/3 border-l border-gray-700 p-4 overflow-y-auto">
          {selectedItem ? (
            <div className="flex flex-col h-full">
              <div className="flex-1">
                <h3 className="text-lg font-semibold mb-1">{selectedItem.name}</h3>
                
                <div 
                  className={`inline-block px-2 py-1 rounded text-xs mb-4 ${selectedItem.currencyType === "gold" ? "bg-amber-800/50 text-amber-300" : "bg-purple-800/50 text-purple-300"}`}
                >
                  {selectedItem.cost} {selectedItem.currencyType === "gold" ? "Gold" : "Gems"}
                </div>
                
                {selectedItem.type === "card" && renderCardDetails(selectedItem.itemId)}
                {selectedItem.type === "character" && renderCharacterDetails(selectedItem.itemId)}
              </div>
              
              <div className="mt-4">
                <GameButton 
                  onClick={handlePurchase}
                  disabled={
                    hasPurchased(selectedItem.id) || 
                    (selectedItem.currencyType === "gold" && gold < selectedItem.cost) ||
                    (selectedItem.currencyType === "gems" && gems < selectedItem.cost)
                  }
                  className="w-full"
                >
                  {hasPurchased(selectedItem.id) 
                    ? "Already Owned" 
                    : `Buy for ${selectedItem.cost} ${selectedItem.currencyType === "gold" ? "Gold" : "Gems"}`}
                </GameButton>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              Select an item to view details
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
