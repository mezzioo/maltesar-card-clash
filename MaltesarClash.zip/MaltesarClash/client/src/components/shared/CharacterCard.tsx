import React from "react";
import { cn } from "@/lib/utils";
import { Character, CharacterRarity, generateCharacterPortrait } from "@/data/characters";

interface CharacterCardProps {
  character: Character;
  size?: "sm" | "md" | "lg";
  isSelected?: boolean;
  onClick?: () => void;
  showStats?: boolean;
}

// Rarity color mapping
const rarityColors = {
  [CharacterRarity.COMMON]: "bg-gray-700 border-gray-500",
  [CharacterRarity.RARE]: "bg-blue-700 border-blue-500",
  [CharacterRarity.EPIC]: "bg-purple-700 border-purple-500",
  [CharacterRarity.LEGENDARY]: "bg-amber-700 border-amber-500",
};

export const CharacterCard: React.FC<CharacterCardProps> = ({
  character,
  size = "md",
  isSelected = false,
  onClick,
  showStats = false
}) => {
  const { name, title, rarity, description, baseHp, baseAttack, baseDefense } = character;
  const portrait = generateCharacterPortrait(character);
  
  // Size classes for different card sizes
  const sizeClasses = {
    sm: "w-24 h-32",
    md: "w-40 h-56",
    lg: "w-56 h-80"
  };
  
  // Title and description text sizes
  const textSizes = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base"
  };
  
  // Convert SVG to a data URL for use as background
  const portraitDataUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(portrait)}`;
  
  return (
    <div 
      className={cn(
        "relative rounded-lg overflow-hidden border-2 transition-all transform cursor-pointer",
        sizeClasses[size],
        rarityColors[rarity],
        isSelected ? "scale-105 ring-4 ring-white" : "hover:scale-102",
        onClick ? "cursor-pointer" : "cursor-default"
      )}
      onClick={onClick}
    >
      {/* Rarity indicator */}
      <div className="absolute top-0 right-0 p-1 z-10">
        <div className={cn(
          "text-white font-bold rounded-full w-5 h-5 flex items-center justify-center text-xs",
          rarity === CharacterRarity.COMMON && "bg-gray-500",
          rarity === CharacterRarity.RARE && "bg-blue-500",
          rarity === CharacterRarity.EPIC && "bg-purple-500",
          rarity === CharacterRarity.LEGENDARY && "bg-amber-500",
        )}>
          {rarity === CharacterRarity.COMMON && "C"}
          {rarity === CharacterRarity.RARE && "R"}
          {rarity === CharacterRarity.EPIC && "E"}
          {rarity === CharacterRarity.LEGENDARY && "L"}
        </div>
      </div>
      
      {/* Character portrait */}
      <div className="h-2/3 bg-black bg-opacity-30 flex items-center justify-center">
        <div 
          className="w-full h-full bg-center bg-no-repeat bg-contain"
          style={{ backgroundImage: `url('${portraitDataUrl}')` }}
        />
      </div>
      
      {/* Character info */}
      <div className="h-1/3 p-1 bg-black bg-opacity-50 flex flex-col justify-between">
        <div>
          <h3 className={cn("font-bold text-white truncate", textSizes[size])}>{name}</h3>
          <p className={cn("text-gray-300 truncate", size === "sm" ? "text-xs" : "text-xs")}>{title}</p>
        </div>
        
        {/* Stats (only shown when showStats is true) */}
        {showStats && size !== "sm" && (
          <div className="grid grid-cols-3 gap-1 mt-1">
            <div className="bg-red-900 rounded px-1 text-center">
              <span className="text-xs text-white">HP:{baseHp}</span>
            </div>
            <div className="bg-orange-900 rounded px-1 text-center">
              <span className="text-xs text-white">ATK:{baseAttack}</span>
            </div>
            <div className="bg-blue-900 rounded px-1 text-center">
              <span className="text-xs text-white">DEF:{baseDefense}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CharacterCard;
