import React from "react";
import { cn } from "@/lib/utils";

interface PixelButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "success" | "danger" | "warning";
  size?: "sm" | "md" | "lg";
  isActive?: boolean;
  isDisabled?: boolean;
}

export const PixelButton: React.FC<PixelButtonProps> = ({
  children,
  variant = "primary",
  size = "md",
  isActive = false,
  isDisabled = false,
  className,
  ...props
}) => {
  const variantStyles = {
    primary: "bg-blue-600 border-blue-400 hover:bg-blue-700 shadow-blue-900/50",
    secondary: "bg-gray-600 border-gray-400 hover:bg-gray-700 shadow-gray-900/50",
    success: "bg-green-600 border-green-400 hover:bg-green-700 shadow-green-900/50",
    danger: "bg-red-600 border-red-400 hover:bg-red-700 shadow-red-900/50",
    warning: "bg-yellow-600 border-yellow-400 hover:bg-yellow-700 shadow-yellow-900/50",
  };

  const sizeStyles = {
    sm: "text-xs py-1 px-2",
    md: "text-sm py-2 px-4",
    lg: "text-base py-3 px-6",
  };

  return (
    <button
      className={cn(
        "relative font-medium text-white border-b-4 transition-transform transform active:translate-y-1 active:border-b-0 active:shadow-none",
        "disabled:opacity-50 disabled:pointer-events-none",
        "shadow-md rounded-md uppercase tracking-wider font-bold focus:outline-none",
        "before:absolute before:inset-0 before:bg-white before:opacity-0 before:transition-opacity",
        "hover:before:opacity-10",
        isActive ? "translate-y-1 border-b-0 shadow-none" : "",
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
      disabled={isDisabled}
      {...props}
    >
      <span className="relative z-10">{children}</span>
    </button>
  );
};

export default PixelButton;
