import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useBattleSystem, BattleCharacter } from "@/lib/stores/useBattleSystem";
import { getCardById } from "@/data/cards";
import { getCharacterById } from "@/data/characters";
import PixelButton from "@/components/shared/PixelButton";
import { CardDisplay } from "@/components/ui/card-display";
import { cn } from "@/lib/utils";
import { useCardCollection } from "@/lib/stores/useCardCollection";
import { useGameState } from "@/lib/stores/useGameState";
import { RotateCw, Heart, Shield, Zap } from "lucide-react";
import { toast } from "sonner";

export const BattleScene: React.FC = () => {
  const [_, setLocation] = useLocation();
  const { 
    state, playerTeam, enemyTeam, activeCharacterId, 
    selectedCardId, targetCharacterId, turn,
    lastAction, addPlayerCharacter, startBattle, 
    selectCard, selectTarget, playCard, endTurn, endBattle,
    getCharacterById: getBattleCharacterById, isCharacterDead
  } = useBattleSystem();
  
  const { getActiveDeckCards } = useCardCollection();
  const { unlockedCharacters } = useGameState();

  const [animating, setAnimating] = useState(false);
  const [showCharacterSelection, setShowCharacterSelection] = useState(false);
  const [selectedCharacters, setSelectedCharacters] = useState<number[]>([]);

  // When battle state changes to setup, show character selection
  useEffect(() => {
    if (state === "setup") {
      setShowCharacterSelection(true);
    }
  }, [state]);

  // Handle character selection
  const toggleCharacterSelection = (characterId: number) => {
    if (selectedCharacters.includes(characterId)) {
      setSelectedCharacters(prev => prev.filter(id => id !== characterId));
    } else {
      if (selectedCharacters.length < 3) {
        setSelectedCharacters(prev => [...prev, characterId]);
      } else {
        toast.error("Maximum 3 characters can be selected");
      }
    }
  };

  // Confirm character selection
  const confirmCharacterSelection = () => {
    if (selectedCharacters.length === 0) {
      toast.error("Please select at least one character");
      return;
    }

    // Add selected characters to battle
    selectedCharacters.forEach(characterId => {
      addPlayerCharacter(characterId);
    });

    // Start battle
    startBattle();
    setShowCharacterSelection(false);
  };

  // Handle card selection
  const handleCardSelect = (cardId: string) => {
    selectCard(cardId);
  };

  // Handle target selection
  const handleTargetSelect = (characterId: string) => {
    if (selectedCardId) {
      selectTarget(characterId);
    }
  };

  // Handle playing a card
  const handlePlayCard = () => {
    if (selectedCardId && targetCharacterId) {
      setAnimating(true);
      playCard();
      
      // Animation delay
      setTimeout(() => {
        setAnimating(false);
      }, 1000);
    } else {
      toast.error("Select a card and target first");
    }
  };

  // Handle end turn
  const handleEndTurn = () => {
    endTurn();
  };

  // Handle battle end
  const handleEndBattle = () => {
    endBattle();
    setLocation("/dungeon");
  };

  // Render character selection screen
  if (showCharacterSelection) {
    return (
      <div className="flex-1 flex flex-col bg-gray-900 p-4">
        <h2 className="text-xl font-bold text-white mb-4">Select Your Team (Max 3)</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {unlockedCharacters.map(characterId => {
            const character = getCharacterById(characterId);
            if (!character) return null;
            
            return (
              <div 
                key={characterId} 
                className={cn(
                  "border-2 rounded-lg p-2 cursor-pointer", 
                  selectedCharacters.includes(characterId) 
                    ? "border-blue-500 bg-blue-900/30" 
                    : "border-gray-700 hover:border-gray-500"
                )}
                onClick={() => toggleCharacterSelection(characterId)}
              >
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center">
                    {character.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-white">{character.name}</h3>
                    <p className="text-xs text-gray-400">{character.title}</p>
                  </div>
                </div>
                <div className="mt-2 flex justify-between">
                  <div className="flex items-center">
                    <Heart size={14} className="text-red-500 mr-1" />
                    <span className="text-sm">{character.baseHp}</span>
                  </div>
                  <div className="flex items-center">
                    <Shield size={14} className="text-blue-500 mr-1" />
                    <span className="text-sm">{character.baseDefense}</span>
                  </div>
                  <div className="flex items-center">
                    <Zap size={14} className="text-yellow-500 mr-1" />
                    <span className="text-sm">{character.baseAttack}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-4 flex justify-end">
          <PixelButton
            onClick={confirmCharacterSelection}
            disabled={selectedCharacters.length === 0}
          >
            Start Battle
          </PixelButton>
        </div>
      </div>
    );
  }

  // Render victory screen
  if (state === "victory") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-900">
        <div className="text-4xl font-bold text-yellow-500 mb-4">Victory!</div>
        <div className="text-xl text-white mb-8">You have defeated all enemies!</div>
        <PixelButton onClick={handleEndBattle}>Continue</PixelButton>
      </div>
    );
  }

  // Render defeat screen
  if (state === "defeat") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-900">
        <div className="text-4xl font-bold text-red-500 mb-4">Defeat</div>
        <div className="text-xl text-white mb-8">Your team has been defeated...</div>
        <PixelButton onClick={handleEndBattle}>Return to Map</PixelButton>
      </div>
    );
  }

  // Get active character
  const activeCharacter = activeCharacterId 
    ? getBattleCharacterById(activeCharacterId) 
    : undefined;

  // Render main battle screen
  return (
    <div className="flex-1 flex flex-col bg-gray-900 overflow-hidden">
      {/* Battle info */}
      <div className="bg-gray-800 p-2 flex justify-between items-center">
        <div className="text-white">Turn: {turn}</div>
        <div className="text-white">
          {state === "playerTurn" ? "Your Turn" : "Enemy Turn"}
        </div>
        <div className="text-white">
          {activeCharacter?.name || ""}
        </div>
      </div>
      
      {/* Battle field */}
      <div className="flex-1 flex flex-col p-4">
        {/* Enemy team */}
        <div className="flex justify-center gap-4 mb-4">
          {enemyTeam.map(enemy => (
            <BattleCharacterDisplay
              key={enemy.id}
              character={enemy}
              isTarget={targetCharacterId === enemy.id}
              isAnimating={animating && lastAction.targetId === enemy.id}
              onClick={() => handleTargetSelect(enemy.id)}
              side="enemy"
            />
          ))}
        </div>
        
        {/* Battle effects visualizer */}
        <div className="flex-1 flex items-center justify-center">
          {animating && lastAction.damage !== null && (
            <div className="text-4xl font-bold text-red-500">
              {lastAction.damage}
            </div>
          )}
        </div>
        
        {/* Player team */}
        <div className="flex justify-center gap-4 mt-4">
          {playerTeam.map(player => (
            <BattleCharacterDisplay
              key={player.id}
              character={player}
              isActive={activeCharacterId === player.id}
              isTarget={targetCharacterId === player.id}
              isAnimating={animating && lastAction.targetId === player.id}
              onClick={() => handleTargetSelect(player.id)}
              side="player"
            />
          ))}
        </div>
      </div>
      
      {/* Card hand */}
      {state === "playerTurn" && activeCharacter && (
        <div className="bg-gray-800 p-2">
          <div className="flex justify-between items-center mb-2">
            <div className="text-white">
              Energy: {activeCharacter.energy}/{activeCharacter.maxEnergy}
            </div>
            <div className="flex gap-2">
              <PixelButton
                onClick={handlePlayCard}
                disabled={!selectedCardId || !targetCharacterId}
                variant="success"
                size="sm"
              >
                Play Card
              </PixelButton>
              <PixelButton
                onClick={handleEndTurn}
                variant="secondary"
                size="sm"
              >
                End Turn
              </PixelButton>
            </div>
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2">
            {activeCharacter.hand.map(card => {
              const cardData = getCardById(card.cardId);
              if (!cardData) return null;
              
              return (
                <CardDisplay
                  key={card.id}
                  card={cardData}
                  level={card.level}
                  size="sm"
                  isSelected={selectedCardId === card.id}
                  isPlayable={activeCharacter.energy >= cardData.energyCost}
                  onClick={() => handleCardSelect(card.id)}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

// Character display component for battle
interface BattleCharacterDisplayProps {
  character: BattleCharacter;
  isActive?: boolean;
  isTarget?: boolean;
  isAnimating?: boolean;
  onClick?: () => void;
  side: "player" | "enemy";
}

const BattleCharacterDisplay: React.FC<BattleCharacterDisplayProps> = ({
  character,
  isActive = false,
  isTarget = false,
  isAnimating = false,
  onClick,
  side
}) => {
  const isDead = character.hp <= 0;
  
  // Get character data from global characters
  const characterData = getCharacterById(character.characterId);
  
  return (
    <div 
      className={cn(
        "w-24 flex flex-col items-center",
        isDead ? "opacity-50" : "cursor-pointer",
        isActive && "ring-2 ring-blue-500 rounded-lg",
        isTarget && "ring-2 ring-green-500 rounded-lg",
        isAnimating && "animate-bounce"
      )}
      onClick={() => {
        if (!isDead && onClick) onClick();
      }}
    >
      {/* Character avatar */}
      <div 
        className={cn(
          "w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center mb-1",
          side === "enemy" ? "bg-red-900" : "bg-blue-900",
          isDead && "bg-opacity-50"
        )}
      >
        <span className="text-white font-bold">
          {character.name.charAt(0)}
        </span>
      </div>
      
      {/* Character name */}
      <div className="text-sm text-center text-white mb-1 truncate w-full">
        {character.name}
      </div>
      
      {/* HP bar */}
      <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-red-500" 
          style={{ width: `${(character.hp / character.maxHp) * 100}%` }}
        />
      </div>
      
      {/* HP text */}
      <div className="text-xs text-white mt-1">
        {character.hp}/{character.maxHp}
      </div>
      
      {/* Effects */}
      {character.effects.length > 0 && (
        <div className="flex mt-1 gap-1">
          {character.effects.map(effect => (
            <div 
              key={effect.id}
              className={cn(
                "w-4 h-4 rounded-full flex items-center justify-center text-xs",
                effect.type === "buff" ? "bg-green-500" : "bg-purple-500"
              )}
              title={`${effect.name} (${effect.duration} turns)`}
            >
              {effect.duration}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BattleScene;
