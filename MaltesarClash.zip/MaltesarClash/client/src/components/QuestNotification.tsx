import React, { useState, useEffect } from 'react';
import { useQuestSystem, Quest } from '../lib/stores/useQuestSystem';
import { cn } from '@/lib/utils';

export const QuestNotification: React.FC = () => {
  const {
    dailyQuests,
    weeklyQuests,
    achievements,
    claimQuestReward,
    getClaimableQuests
  } = useQuestSystem();

  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Quest[]>([]);

  useEffect(() => {
    // Get all newly completed quests
    const claimableQuests = getClaimableQuests();
    
    if (claimableQuests.length > 0) {
      setNotifications(claimableQuests);
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  }, [dailyQuests, weeklyQuests, achievements, getClaimableQuests]);

  if (!isOpen || notifications.length === 0) return null;

  // Get the first notification
  const currentQuest = notifications[0];

  // Format to show what type of quest it is
  const getQuestTypeLabel = (quest: Quest) => {
    switch (quest.type) {
      case 'daily':
        return 'Daily Quest';
      case 'weekly':
        return 'Weekly Quest';
      case 'achievement':
        return 'Achievement';
      default:
        return 'Quest';
    }
  };

  // Handle claiming the reward
  const handleClaim = () => {
    if (currentQuest) {
      claimQuestReward(currentQuest.id);
      
      // Remove this quest from notifications
      setNotifications(prev => prev.filter(q => q.id !== currentQuest.id));
      
      // If no more notifications, close the notification panel
      if (notifications.length <= 1) {
        setIsOpen(false);
      }
    }
  };

  // Handle dismissing the notification
  const handleDismiss = () => {
    // Just remove from the notifications list, don't claim
    setNotifications(prev => prev.filter(q => q.id !== currentQuest.id));
    
    // If no more notifications, close the notification panel
    if (notifications.length <= 1) {
      setIsOpen(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-md w-full sm:w-96 shadow-lg animate-slide-up">
      <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
        {/* Header */}
        <div className="bg-green-900/40 px-4 py-2 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-green-400 rounded-full"></span>
            <span className="font-semibold text-green-300">{getQuestTypeLabel(currentQuest)}</span>
          </div>
          <span className="text-xs text-gray-400">
            {notifications.length > 1 ? `+${notifications.length - 1} more` : ''}
          </span>
        </div>
        
        {/* Content */}
        <div className="p-4">
          <h3 className="font-semibold text-white mb-1">{currentQuest.title}</h3>
          <p className="text-sm text-gray-300 mb-3">{currentQuest.description}</p>
          
          {/* Progress */}
          <div className="mb-3">
            <div className="flex justify-between text-xs text-gray-400 mb-1">
              <span>Progress</span>
              <span>{currentQuest.objective.progress}/{currentQuest.objective.target}</span>
            </div>
            <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-500"
                style={{ width: `${Math.min(100, (currentQuest.objective.progress / currentQuest.objective.target) * 100)}%` }}
              ></div>
            </div>
          </div>
          
          {/* Rewards */}
          <div className="mb-4">
            <div className="text-xs text-gray-400 mb-1">Rewards:</div>
            <div className="flex flex-wrap gap-2">
              {currentQuest.rewards.exp && (
                <div className="bg-blue-900/40 text-blue-300 px-2 py-1 rounded text-xs">
                  {currentQuest.rewards.exp} EXP
                </div>
              )}
              {currentQuest.rewards.gold && (
                <div className="bg-amber-900/40 text-amber-300 px-2 py-1 rounded text-xs">
                  {currentQuest.rewards.gold} Gold
                </div>
              )}
              {currentQuest.rewards.gems && (
                <div className="bg-purple-900/40 text-purple-300 px-2 py-1 rounded text-xs">
                  {currentQuest.rewards.gems} Gems
                </div>
              )}
              {currentQuest.rewards.cardId && (
                <div className="bg-green-900/40 text-green-300 px-2 py-1 rounded text-xs">
                  Card Reward
                </div>
              )}
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex space-x-2">
            <button
              onClick={handleClaim}
              className={cn(
                "flex-1 bg-green-700 hover:bg-green-600 text-white py-2 px-4 rounded-md text-sm",
                "transition-colors"
              )}
            >
              Claim Reward
            </button>
            <button
              onClick={handleDismiss}
              className={cn(
                "bg-gray-700 hover:bg-gray-600 text-gray-300 py-2 px-4 rounded-md text-sm",
                "transition-colors"
              )}
            >
              Later
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};