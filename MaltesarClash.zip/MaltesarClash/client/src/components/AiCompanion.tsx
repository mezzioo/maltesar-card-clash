import React, { useState, useEffect, useCallback } from 'react';
import { useGame } from '../lib/stores/useGame';
import { MessageSquare, X, ArrowLeftCircle } from 'lucide-react';
import { toast } from 'sonner';
import { GameButton } from '../components/ui/game-button';

// Define interface for component props
interface AiCompanionProps {
  currentScreen: string;
}

// List of possible tips based on different game sections
const tipsBySection: Record<string, string[]> = {
  home: [
    "Welcome to Maltesar Card Clash! Explore the academy to find new adventures.",
    "Click on Story Mode to continue your journey through the academy.",
    "Your deck is critical to your success. Visit Collection to manage your cards.",
    "Try the Gacha to find rare and powerful cards!",
    "Complete daily quests for extra currency and rewards.",
  ],
  battle: [
    "Pay attention to card combos for maximum damage!",
    "Buffs and debuffs can turn the tide of battle - use them wisely!",
    "Some enemies are weak to specific card types - experiment to find out!",
    "Don't forget to use healing cards to stay in the fight longer.",
    "Position matters! Some cards affect multiple targets based on positioning.",
  ],
  collection: [
    "You can create multiple decks for different battle situations.",
    "Balance your deck with a mix of attack, defense, and utility cards.",
    "Higher rarity cards have better effects but may cost more mana.",
    "Tap on cards to see their detailed effects and possible combos.",
    "Character-specific cards work best when that character is in your party.",
  ],
  dungeon: [
    "Dungeons offer better rewards as you progress through them.",
    "Some paths may be more dangerous but offer greater rewards.",
    "Rest points can restore your health but may reduce your final rewards.",
    "Scout the dungeon first to plan your route carefully.",
    "Look for hidden treasures by exploring optional branches.",
  ],
  gacha: [
    "Save your gems for special banner events with increased rates!",
    "The daily free pull resets every 24 hours - don't forget to use it!",
    "Premium banners have higher chances for rare cards and characters.",
    "Duplicate cards aren't wasted - they level up your existing cards.",
    "The pity system ensures you'll eventually get a high-rarity pull.",
  ],
  shop: [
    "The shop inventory refreshes daily - check back often!",
    "Look for discounted items to maximize your currency value.",
    "Premium currency (gems) can be earned through achievements and quests.",
    "Consider saving for the high-value bundle deals rather than individual items.",
    "Some special items only appear in the shop for a limited time.",
  ],
  story: [
    "Your choices in the story may affect relationships with characters.",
    "Story chapters unlock new areas and game features.",
    "Completing story chapters awards special cards and characters.",
    "Pay attention to the lore for hints about card combos and strategies.",
    "You can replay story chapters to review the lore or make different choices.",
  ],
};

// Beginner tips that show for new players
const beginnerTips = [
  "Tap cards in your hand to see more details about their effects.",
  "Complete the tutorial to get your first set of cards!",
  "Visit the Collection page to build your first custom deck.",
  "Mana refreshes each turn - plan your card usage accordingly.",
  "Different characters have special synergies with certain card types.",
];

// Tips for more experienced players
const advancedTips = [
  "Try building mono-element decks for powerful resonance effects.",
  "Some rare enemy types only appear under specific conditions.",
  "Secret combos exist between certain card pairs - experiment!",
  "Challenge the Arena after level 10 to compete against other students.",
  "Ultimate cards charge faster when you use cards of the same element.",
];

export const AiCompanion: React.FC<AiCompanionProps> = ({ currentScreen }) => {
  // Get player data from game store
  const { phase } = useGame();
  
  // For this implementation, we'll use phase as a proxy for player progress
  // In a full implementation, we would connect to the actual player state
  const playerLevel = 1;
  const tutorialCompleted = phase === "playing" || phase === "ended";
  
  // State for the current tip and whether the companion is visible
  const [currentTip, setCurrentTip] = useState<string>("");
  const [isOpen, setIsOpen] = useState<boolean>(false);
  
  // Get the appropriate tips based on player experience and current screen
  const getRelevantTips = useCallback(() => {
    let tips: string[] = [];
    
    // Add section-specific tips
    if (currentScreen && tipsBySection[currentScreen]) {
      tips = tips.concat(tipsBySection[currentScreen]);
    } else {
      // Fallback to home tips if screen not recognized
      tips = tips.concat(tipsBySection.home);
    }
    
    // Add either beginner or advanced tips based on player level
    if (!tutorialCompleted || playerLevel < 5) {
      tips = tips.concat(beginnerTips);
    } else {
      tips = tips.concat(advancedTips);
    }
    
    return tips;
  }, [currentScreen, playerLevel, tutorialCompleted]);
  
  // Rotate tips every 15 seconds
  useEffect(() => {
    const tips = getRelevantTips();
    
    // Set initial tip
    setCurrentTip(tips[Math.floor(Math.random() * tips.length)]);
    
    // Set up interval to change tip
    const interval = setInterval(() => {
      const newTip = tips[Math.floor(Math.random() * tips.length)];
      setCurrentTip(newTip);
    }, 15000);
    
    return () => clearInterval(interval);
  }, [getRelevantTips]);
  
  // Toggle companion visibility
  const toggleCompanion = () => {
    setIsOpen(prev => !prev);
  };
  
  // Ask AI assistant for more help
  const askForHelp = () => {
    toast.info("Additional help will be available in a future update!", {
      duration: 3000,
    });
  };
  
  return (
    <>
      {/* Bubble button to toggle the companion */}
      <button 
        onClick={toggleCompanion}
        className="fixed bottom-20 right-4 z-50 bg-gray-800 hover:bg-gray-700 text-white p-3 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 border-2 border-amber-500"
        aria-label="AI Companion"
      >
        <MessageSquare size={22} className="text-amber-400" />
      </button>
      
      {/* AI Companion panel */}
      {isOpen && (
        <div className="fixed bottom-36 right-4 z-50 w-80 bg-gray-800 border-2 border-amber-500 rounded-lg shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gray-900 px-4 py-2 flex justify-between items-center border-b border-amber-500/50">
            <h3 className="text-amber-400 font-bold">Academy Assistant</h3>
            <button 
              onClick={toggleCompanion}
              className="text-amber-400 hover:text-amber-300"
              aria-label="Close assistant"
            >
              <X size={18} />
            </button>
          </div>
          
          {/* Content */}
          <div className="px-4 py-3 text-white">
            <p className="mb-4 text-sm">
              {currentTip}
            </p>
            
            <GameButton
              onClick={askForHelp}
              variant="default"
              className="w-full"
            >
              Ask for More Help
            </GameButton>
          </div>
        </div>
      )}
    </>
  );
};