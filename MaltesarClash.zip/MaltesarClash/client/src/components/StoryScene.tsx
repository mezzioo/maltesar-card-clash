import React, { useState, useEffect } from "react";
import { DialogueLine } from "../data/story";
import { GameButton } from "./ui/game-button";
import { useAudio } from "../lib/stores/useAudio";
import { FastForward, SkipForward } from "lucide-react";
import { cn } from "../lib/utils";
import { toast } from "sonner";

// Type guard function to check if a dialogue line has choices
function hasChoices(line: DialogueLine | undefined): boolean {
  return !!line && !!line.choices && Array.isArray(line.choices) && line.choices.length > 0;
}

interface StorySceneProps {
  dialogue: DialogueLine[];
  onComplete: () => void;
  onChoice?: (choiceIndex: number) => void;
}

export const StoryScene: React.FC<StorySceneProps> = ({ 
  dialogue, 
  onComplete,
  onChoice
}) => {
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(30); // ms per character
  
  const { playHit, playCardFlip, playSuccess } = useAudio();
  
  const currentLine = dialogue[currentLineIndex];
  
  // Text typing effect
  useEffect(() => {
    if (!currentLine) return;
    
    setDisplayedText("");
    setIsTyping(true);
    
    let index = 0;
    const text = currentLine.text;
    
    const typingInterval = setInterval(() => {
      setDisplayedText(prev => prev + text.charAt(index));
      index++;
      
      // Play typing sound occasionally
      if (index % 10 === 0) {
        // Quiet sound for typing
        // playHit();
      }
      
      if (index >= text.length) {
        clearInterval(typingInterval);
        setIsTyping(false);
      }
    }, typingSpeed);
    
    return () => clearInterval(typingInterval);
  }, [currentLine, typingSpeed, playHit]);
  
  // Handle next line
  const handleNext = () => {
    // If still typing, show full text immediately
    if (isTyping) {
      setDisplayedText(currentLine.text);
      setIsTyping(false);
      return;
    }
    
    // Play sound effect for next dialogue
    playHit();
    
    // Check if there are more lines
    if (currentLineIndex < dialogue.length - 1) {
      setCurrentLineIndex(prev => prev + 1);
    } else {
      // End of dialogue
      onComplete();
    }
  };
  
  // Skip to the end of the dialogue
  const handleSkipStory = () => {
    // Play success sound
    playSuccess();
    
    // Show notification
    toast.info("Story skipped! Rewards have been added to your inventory.", {
      duration: 3000,
    });
    
    // Complete the story immediately
    onComplete();
  };
  
  // Skip to the next choice or end
  const handleFastForward = () => {
    // Find the next line with choices or the end
    let nextLineWithChoices = -1;
    
    // Safely find the next line with choices
    const remainingLines = dialogue.slice(currentLineIndex + 1);
    const choiceLineIndex = remainingLines.findIndex(line => 
      line && line.choices && Array.isArray(line.choices) && line.choices.length > 0
    );
    
    if (choiceLineIndex !== -1) {
      nextLineWithChoices = currentLineIndex + 1 + choiceLineIndex;
    }
    
    if (nextLineWithChoices >= 0) {
      // Skip to the next choice
      setCurrentLineIndex(nextLineWithChoices);
      setIsTyping(false);
      
      // Safely access the text
      const nextLine = dialogue[nextLineWithChoices];
      if (nextLine && nextLine.text) {
        setDisplayedText(nextLine.text);
      }
      
      // Play a sound
      playHit();
      
      toast.info("Skipped to next choice", {
        duration: 1000,
      });
    } else {
      // No more choices, skip to the end
      handleSkipStory();
    }
  };
  
  // Handle choice selection
  const handleChoice = (choiceIndex: number) => {
    // Play card or choice sound effect
    playCardFlip();
    
    // If still typing, show full text immediately
    if (isTyping) {
      setDisplayedText(currentLine.text);
      setIsTyping(false);
    }
    
    // Call the onChoice callback
    if (onChoice) {
      onChoice(choiceIndex);
    }
  };
  
  if (!currentLine) {
    return null;
  }
  
  return (
    <div className="relative w-full h-full flex flex-col">
      {/* Background - could be a dynamic image based on story chapter */}
      <div className="absolute inset-0 bg-gray-900 z-0"></div>
      
      {/* Character portrait */}
      {currentLine.portrait && (
        <div className="absolute left-1/2 top-1/3 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 sm:w-40 sm:h-40 z-10">
          <div 
            className="w-full h-full"
            dangerouslySetInnerHTML={{ __html: currentLine.portrait }} 
          />
        </div>
      )}
      
      {/* Skip buttons in top right */}
      <div className="absolute top-4 right-4 z-30 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
        <GameButton
          size="sm"
          variant="outline"
          onClick={handleFastForward}
          className="bg-gray-800/80 border-amber-500 text-amber-300 hover:bg-amber-900/70 flex items-center px-2 sm:px-3 py-1"
        >
          <FastForward size={14} className="mr-1" /> <span className="text-xs sm:text-sm">Skip to choice</span>
        </GameButton>
        <GameButton
          size="sm"
          variant="outline"
          onClick={handleSkipStory}
          className="bg-gray-800/80 border-amber-500 text-amber-300 hover:bg-amber-900/70 flex items-center px-2 sm:px-3 py-1"
        >
          <SkipForward size={14} className="mr-1" /> <span className="text-xs sm:text-sm">Skip story</span>
        </GameButton>
      </div>
      
      {/* Dialogue box */}
      <div className="absolute bottom-0 left-0 right-0 bg-gray-800/95 border-t-2 border-amber-500 p-3 sm:p-4 z-20">
        <div className="max-w-3xl mx-auto">
          {/* Speaker name */}
          <div className="bg-amber-600 text-white px-2 sm:px-3 py-1 inline-block rounded-t-md -mt-8 mb-2 text-sm sm:text-base font-medium">
            {currentLine.speaker}
          </div>
          
          {/* Dialogue text */}
          <div className="text-white text-base sm:text-lg mb-3 sm:mb-4 min-h-[80px] sm:min-h-[100px]">
            {displayedText}
            {isTyping && <span className="animate-pulse">|</span>}
          </div>
          
          {/* Choices or continue button */}
          <div className="flex justify-end">
            {currentLine.choices ? (
              <div className="flex flex-col space-y-2 w-full">
                {currentLine.choices.map((choice, index) => (
                  <GameButton
                    key={index}
                    variant={choice.text.includes("TAKE THE CARDS") ? "default" : "outline"}
                    onClick={() => handleChoice(index)}
                    className={`text-left text-sm sm:text-base py-2 transition-colors ${
                      choice.text.includes("TAKE THE CARDS") 
                        ? "bg-green-600 hover:bg-green-700 text-white font-bold tracking-wide animate-pulse" 
                        : "hover:bg-amber-700"
                    }`}
                  >
                    {choice.text}
                  </GameButton>
                ))}
              </div>
            ) : (
              <GameButton 
                onClick={handleNext}
                className="hover:bg-amber-700 transition-colors px-6 sm:px-8 text-sm sm:text-base"
              >
                {currentLineIndex < dialogue.length - 1 ? "Continue" : "End"}
              </GameButton>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
