import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useDungeon } from "@/hooks/useDungeon";
import { getDungeonById, getBattleById, getEnemyById } from "@/data/dungeons";
import PixelButton from "@/components/shared/PixelButton";
import { cn } from "@/lib/utils";
import { useGameState } from "@/lib/stores/useGameState";
import { toast } from "sonner";
import { Skull, Trophy, Star, Lock, Check, AlertTriangle, X } from "lucide-react";

export const DungeonMap: React.FC = () => {
  const [_, setLocation] = useLocation();
  const { 
    selectedDungeonId, setSelectedDungeonId,
    selectedBattleId, setSelectedBattleId,
    getAvailableDungeons, getDungeonBattles,
    startBattle, isBattleCompleted, isDungeonCompleted
  } = useDungeon();
  
  const { level } = useGameState();
  
  const [showDungeonDetail, setShowDungeonDetail] = useState(false);
  const [showBattleDetail, setShowBattleDetail] = useState(false);
  
  // Available dungeons for the player
  const availableDungeons = getAvailableDungeons();
  
  // Select a dungeon
  const handleSelectDungeon = (dungeonId: number) => {
    setSelectedDungeonId(dungeonId);
    setSelectedBattleId(null);
    setShowDungeonDetail(true);
    setShowBattleDetail(false);
  };
  
  // Select a battle
  const handleSelectBattle = (battleId: number) => {
    setSelectedBattleId(battleId);
    setShowBattleDetail(true);
  };
  
  // Start a battle
  const handleStartBattle = () => {
    if (selectedDungeonId === null || selectedBattleId === null) {
      toast.error("Please select a dungeon and battle first");
      return;
    }
    
    const success = startBattle(selectedDungeonId, selectedBattleId);
    if (success) {
      setLocation("/battle");
    } else {
      toast.error("Failed to start battle");
    }
  };
  
  // Go back to dungeon list
  const handleBackToDungeons = () => {
    setShowDungeonDetail(false);
    setSelectedDungeonId(null);
  };
  
  // Go back to battle list
  const handleBackToBattles = () => {
    setShowBattleDetail(false);
    setSelectedBattleId(null);
  };
  
  // Get dungeon details if selected
  const selectedDungeon = selectedDungeonId ? getDungeonById(selectedDungeonId) : null;
  
  // Get battle details if selected
  const selectedBattle = selectedDungeonId && selectedBattleId 
    ? getBattleById(selectedDungeonId, selectedBattleId) 
    : null;
  
  // Render battle detail screen
  if (showBattleDetail && selectedDungeon && selectedBattle) {
    // Get enemies for this battle
    const battleEnemies = selectedBattle.enemies.map(enemyId => getEnemyById(enemyId)).filter(Boolean);
    
    return (
      <div className="flex-1 bg-gray-900 p-4 overflow-auto">
        <div className="mb-4 flex items-center">
          <PixelButton
            onClick={handleBackToBattles}
            variant="secondary"
            size="sm"
            className="mr-2"
          >
            <X size={16} className="mr-1" /> Back
          </PixelButton>
          
          <div className="text-xl font-bold text-white">
            {selectedBattle.name}
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-4 mb-4">
          <div className="text-gray-300 mb-4">
            {selectedBattle.description}
          </div>
          
          <div className="mb-4">
            <div className="text-white font-bold mb-2">Enemies:</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {battleEnemies.map(enemy => (
                <div key={enemy?.id} className="bg-gray-700 rounded-lg p-3 flex">
                  {enemy?.isBoss ? (
                    <div className="w-10 h-10 mr-3 bg-red-900 rounded-full flex items-center justify-center">
                      <Skull size={20} className="text-white" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 mr-3 bg-orange-900 rounded-full flex items-center justify-center">
                      <AlertTriangle size={20} className="text-white" />
                    </div>
                  )}
                  
                  <div>
                    <div className="font-bold text-white">
                      {enemy?.name}
                      {enemy?.isBoss && (
                        <span className="ml-2 text-xs bg-red-900 text-white px-1 py-0.5 rounded">
                          BOSS
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-300 mt-1">
                      HP: {enemy?.hp} | ATK: {enemy?.attack} | DEF: {enemy?.defense}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div>
              <div className="text-gray-300 text-sm">
                Status: {isBattleCompleted(selectedDungeonId, selectedBattleId) ? (
                  <span className="text-green-500">Completed</span>
                ) : (
                  <span className="text-yellow-500">Not Completed</span>
                )}
              </div>
            </div>
            
            <PixelButton 
              onClick={handleStartBattle}
              variant="success"
            >
              Start Battle
            </PixelButton>
          </div>
        </div>
      </div>
    );
  }
  
  // Render dungeon detail screen
  if (showDungeonDetail && selectedDungeon) {
    const battles = getDungeonBattles(selectedDungeonId!);
    const isCompleted = isDungeonCompleted(selectedDungeonId!);
    
    return (
      <div className="flex-1 bg-gray-900 p-4 overflow-auto">
        <div className="mb-4 flex items-center">
          <PixelButton
            onClick={handleBackToDungeons}
            variant="secondary"
            size="sm"
            className="mr-2"
          >
            <X size={16} className="mr-1" /> Back
          </PixelButton>
          
          <div className="text-xl font-bold text-white">
            {selectedDungeon.name}
            {isCompleted && (
              <span className="ml-2 text-sm bg-green-700 text-white px-2 py-0.5 rounded-full">
                Completed
              </span>
            )}
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-4 mb-4">
          <div className="text-gray-300 mb-4">
            {selectedDungeon.description}
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            <div className="bg-blue-900 px-2 py-1 rounded-md text-white text-sm">
              Required Level: {selectedDungeon.requiredLevel}
            </div>
            <div className="bg-yellow-900 px-2 py-1 rounded-md text-white text-sm">
              Gold Reward: {selectedDungeon.rewards.gold}
            </div>
            <div className="bg-purple-900 px-2 py-1 rounded-md text-white text-sm">
              Gem Reward: {selectedDungeon.rewards.gems}
            </div>
            <div className="bg-green-900 px-2 py-1 rounded-md text-white text-sm">
              EXP Reward: {selectedDungeon.rewards.exp}
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <h3 className="text-white font-bold mb-2">Battles:</h3>
          <div className="space-y-2">
            {battles.map((battle, index) => (
              <div 
                key={battle.id}
                className={cn(
                  "bg-gray-800 rounded-lg p-3 flex items-center",
                  battle.completed ? "border-l-4 border-green-500" : "border-l-4 border-yellow-500",
                  index > 0 && !battles[index - 1].completed ? "opacity-50" : ""
                )}
              >
                <div className="mr-3">
                  {battle.completed ? (
                    <Check size={20} className="text-green-500" />
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-yellow-700 flex items-center justify-center">
                      {battle.id}
                    </div>
                  )}
                </div>
                
                <div className="flex-grow">
                  <div className="font-bold text-white">{battle.name}</div>
                  <div className="text-xs text-gray-400 truncate max-w-xs">
                    {battle.description}
                  </div>
                </div>
                
                <PixelButton
                  size="sm"
                  onClick={() => handleSelectBattle(battle.id)}
                  disabled={index > 0 && !battles[index - 1].completed}
                >
                  {battle.completed ? "Replay" : "Play"}
                </PixelButton>
              </div>
            ))}
          </div>
        </div>
        
        {isCompleted && selectedDungeon.rewards.guaranteedCardId && (
          <div className="bg-purple-900 bg-opacity-30 border border-purple-800 rounded-lg p-4 mb-4">
            <div className="flex items-center">
              <Trophy size={20} className="text-yellow-500 mr-2" />
              <div className="text-white font-bold">Dungeon Completion Reward</div>
            </div>
            <div className="text-gray-300 text-sm mt-1">
              Complete all battles to receive a guaranteed card!
            </div>
          </div>
        )}
      </div>
    );
  }
  
  // Render dungeon selection screen
  return (
    <div className="flex-1 bg-gray-900 p-4 overflow-auto">
      <h2 className="text-2xl font-bold text-white mb-4">Dungeons</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {availableDungeons.map(dungeon => (
          <div
            key={dungeon.id}
            className={cn(
              "border border-gray-700 rounded-lg overflow-hidden cursor-pointer transition-all hover:border-gray-500",
              isDungeonCompleted(dungeon.id) ? "bg-gray-800" : "bg-gray-800"
            )}
            onClick={() => handleSelectDungeon(dungeon.id)}
          >
            <div className="bg-gray-700 p-3 flex justify-between items-center">
              <h3 className="font-bold text-white">{dungeon.name}</h3>
              {isDungeonCompleted(dungeon.id) && (
                <div className="bg-green-700 text-white text-xs px-2 py-0.5 rounded">
                  Completed
                </div>
              )}
            </div>
            
            <div className="p-3">
              <p className="text-gray-300 text-sm mb-3 line-clamp-2">
                {dungeon.description}
              </p>
              
              <div className="flex flex-wrap gap-2">
                <div className="bg-blue-900 bg-opacity-50 px-2 py-0.5 rounded text-white text-xs">
                  Level {dungeon.requiredLevel}+
                </div>
                <div className="bg-yellow-900 bg-opacity-50 px-2 py-0.5 rounded text-white text-xs">
                  {dungeon.battles.length} Battles
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Locked dungeons */}
      <h3 className="text-xl font-bold text-white mt-8 mb-4">Locked Dungeons</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[...Array(4)].map((_, index) => {
          const dungeonId = index + 1;
          const dungeon = getDungeonById(dungeonId);
          
          // Skip if dungeon is already available
          if (!dungeon || availableDungeons.some(d => d.id === dungeonId)) {
            return null;
          }
          
          return (
            <div
              key={dungeonId}
              className="border border-gray-700 rounded-lg overflow-hidden bg-gray-800 opacity-70"
            >
              <div className="bg-gray-700 p-3 flex items-center">
                <Lock size={16} className="text-gray-500 mr-2" />
                <h3 className="font-bold text-gray-400">
                  {dungeon.name}
                </h3>
              </div>
              
              <div className="p-3">
                <p className="text-gray-500 text-sm mb-3">
                  Unlocks at level {dungeon.requiredLevel}
                </p>
                
                <div className="flex items-center">
                  <div className="bg-red-900 bg-opacity-30 px-2 py-0.5 rounded text-red-300 text-xs">
                    Required Level: {dungeon.requiredLevel} (You: {level})
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DungeonMap;
