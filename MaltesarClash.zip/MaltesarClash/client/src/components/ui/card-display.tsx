import React from "react";
import { cn } from "@/lib/utils";
import { Card as CardData, CardType } from "@/data/cards";
import { Character, getCharacterById } from "@/data/characters";

interface CardDisplayProps {
  card: CardData;
  level?: number;
  size?: "sm" | "md" | "lg";
  isSelected?: boolean;
  isPlayable?: boolean;
  onClick?: () => void;
}

// Card type color mapping
const typeColors = {
  [CardType.ATTACK]: "bg-red-700 border-red-500 text-white",
  [CardType.DEFENSE]: "bg-blue-700 border-blue-500 text-white",
  [CardType.BUFF]: "bg-green-700 border-green-500 text-white",
  [CardType.DEBUFF]: "bg-purple-700 border-purple-500 text-white",
};

// Card rarity styling
const rarityStyles = {
  "common": "border-gray-400",
  "rare": "border-blue-400",
  "epic": "border-purple-400",
  "legendary": "border-amber-400",
};

export const CardDisplay: React.FC<CardDisplayProps> = ({
  card,
  level = 1,
  size = "md",
  isSelected = false,
  isPlayable = true,
  onClick
}) => {
  const { name, type, value, description, energyCost, characterId, rarity } = card;
  
  // Get character if this is a character-specific card
  const character = characterId > 0 ? getCharacterById(characterId) : null;
  
  // Calculate adjusted value based on card level
  const adjustedValue = Math.floor(value * (1 + (level - 1) * 0.1));
  
  // Size classes for different card sizes
  const sizeClasses = {
    sm: "w-24 h-32 text-xs",
    md: "w-36 h-48 text-sm",
    lg: "w-48 h-64 text-base"
  };
  
  return (
    <div 
      className={cn(
        "rounded-md overflow-hidden border-2 flex flex-col transition-all transform",
        typeColors[type],
        rarityStyles[rarity],
        sizeClasses[size],
        isSelected ? "scale-105 ring-2 ring-white" : "hover:scale-102",
        isPlayable ? "cursor-pointer opacity-100" : "opacity-60 cursor-not-allowed",
        onClick && isPlayable ? "cursor-pointer" : "cursor-default"
      )}
      onClick={() => {
        if (isPlayable && onClick) {
          onClick();
        }
      }}
    >
      {/* Card header with name and energy cost */}
      <div className="px-2 py-1 bg-black bg-opacity-30 flex justify-between items-center">
        <h3 className="font-bold truncate flex-1">{name}</h3>
        <div className="bg-blue-500 rounded-full w-5 h-5 flex items-center justify-center text-white text-xs font-bold">
          {energyCost}
        </div>
      </div>
      
      {/* Card type indicator */}
      <div className="px-2 py-0.5 bg-black bg-opacity-50 text-xs uppercase tracking-wider font-bold">
        {type}
      </div>
      
      {/* Card image/illustration (simplified placeholder) */}
      <div className="bg-black bg-opacity-30 h-1/3 flex items-center justify-center">
        {type === CardType.ATTACK && (
          <div className="w-8 h-8 bg-red-500 rounded-md flex items-center justify-center">
            <span className="text-white font-bold">{adjustedValue}</span>
          </div>
        )}
        {type === CardType.DEFENSE && (
          <div className="w-8 h-8 bg-blue-500 rounded-md flex items-center justify-center">
            <span className="text-white font-bold">{adjustedValue}</span>
          </div>
        )}
        {type === CardType.BUFF && (
          <div className="w-8 h-8 bg-green-500 rounded-md flex items-center justify-center">
            <span className="text-white font-bold">+{adjustedValue}</span>
          </div>
        )}
        {type === CardType.DEBUFF && (
          <div className="w-8 h-8 bg-purple-500 rounded-md flex items-center justify-center">
            <span className="text-white font-bold">-{adjustedValue}</span>
          </div>
        )}
      </div>
      
      {/* Card description */}
      <div className="p-2 flex-1 flex flex-col justify-between">
        <p className="text-xs opacity-90 mb-1">{description}</p>
        
        {/* Character info if applicable */}
        {character && (
          <div className="mt-auto text-xs opacity-70">
            {character.name}'s Card
          </div>
        )}
        
        {/* Level indicator if higher than 1 */}
        {level > 1 && (
          <div className="mt-1 text-xs bg-black bg-opacity-30 rounded px-1 py-0.5 self-end">
            Lv.{level}
          </div>
        )}
      </div>
    </div>
  );
};

export default CardDisplay;
