import React from "react";
import { CardType } from "../data/cards";
import { cn } from "@/lib/utils";

interface CardProps {
  card: CardType;
  onClick?: () => void;
  showBack?: boolean;
  className?: string;
}

// Card rarity colors
const rarityColors = {
  Common: "border-gray-400 bg-gradient-to-br from-gray-700 to-gray-900",
  Rare: "border-blue-400 bg-gradient-to-br from-blue-700 to-blue-900",
  Epic: "border-purple-400 bg-gradient-to-br from-purple-700 to-purple-900",
  Legendary: "border-yellow-400 bg-gradient-to-br from-yellow-600 to-amber-900",
};

// Card type colors
const typeColors = {
  attack: "text-red-400",
  defense: "text-blue-400",
  heal: "text-green-400",
  buff: "text-purple-400",
  debuff: "text-yellow-400",
};

// Card back design
const CardBack = () => (
  <div className="relative w-full h-full flex items-center justify-center">
    <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 to-purple-900 opacity-90"></div>
    <div className="z-10 w-3/4 h-3/4 border-2 border-amber-500 rounded-md flex items-center justify-center">
      <div className="text-amber-400 text-xl font-bold">Maltesar</div>
    </div>
    <div className="absolute inset-0 grid grid-cols-3 grid-rows-4 gap-1 p-2 opacity-20">
      {Array(12).fill(0).map((_, i) => (
        <div key={i} className="bg-white rounded-full"></div>
      ))}
    </div>
  </div>
);

export const Card: React.FC<CardProps> = ({ 
  card, 
  onClick, 
  showBack = false,
  className 
}) => {
  const handleCardClick = () => {
    if (onClick) onClick();
  };
  
  return (
    <div
      className={cn(
        "relative w-24 h-32 rounded-md shadow-xl transition-transform cursor-pointer",
        "card-container", // For pixelated rendering
        rarityColors[card.rarity],
        "border-2",
        className
      )}
      onClick={handleCardClick}
    >
      {showBack ? (
        <CardBack />
      ) : (
        <>
          {/* Card header */}
          <div className="absolute top-0 left-0 right-0 flex justify-between items-center p-1 text-xs">
            <span className={`font-semibold ${typeColors[card.type]}`}>
              {card.type.charAt(0).toUpperCase()}
            </span>
            <div className="bg-blue-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold">
              {card.manaCost}
            </div>
          </div>
          
          {/* Card art */}
          <div className="absolute top-6 left-1 right-1 h-12 flex items-center justify-center bg-gray-800 rounded-md overflow-hidden">
            <div 
              className="w-full h-full"
              dangerouslySetInnerHTML={{ __html: card.artwork }} 
            />
          </div>
          
          {/* Card name */}
          <div className="absolute top-[4.5rem] left-0 right-0 text-center text-white text-[10px] font-semibold">
            {card.name}
          </div>
          
          {/* Card description */}
          <div className="absolute bottom-1 left-1 right-1 h-7 text-[8px] text-gray-300 overflow-hidden">
            {card.description}
          </div>
          
          {/* Card value/power */}
          {card.value > 0 && (
            <div className="absolute bottom-0 right-0 bg-red-500 text-white rounded-bl-md rounded-tr-md w-5 h-5 flex items-center justify-center text-xs font-bold">
              {card.value}
            </div>
          )}
          
          {/* Ultimate indicator */}
          {card.isUltimate && (
            <div className="absolute top-0 left-0 right-0 bottom-0 border-2 border-yellow-400 rounded-md pointer-events-none"></div>
          )}
        </>
      )}
    </div>
  );
};
