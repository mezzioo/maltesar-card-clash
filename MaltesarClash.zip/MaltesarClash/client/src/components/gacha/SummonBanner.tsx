import React, { useState, useEffect } from "react";
import { useSummon, SummonResult } from "@/hooks/useSummon";
import { useGameState } from "@/lib/stores/useGameState";
import { getCharacterById, CharacterRarity } from "@/data/characters";
import { getCardById } from "@/data/cards";
import PixelButton from "@/components/shared/PixelButton";
import { CharacterCard } from "@/components/shared/CharacterCard";
import { CardDisplay } from "@/components/ui/card-display";
import { cn } from "@/lib/utils";
import { useAudio } from "@/lib/stores/useAudio";
import { motion } from "framer-motion";
import { Sparkles, RefreshCcw } from "lucide-react";

export const SummonBanner: React.FC = () => {
  const { gold, gems, lastDailySummon } = useGameState();
  const { performSummon, isAnimating, results, resetResults } = useSummon();
  const { playSuccess } = useAudio();
  
  const [showResults, setShowResults] = useState(false);
  const [currentResultIndex, setCurrentResultIndex] = useState(0);
  
  // Reset state when component unmounts
  useEffect(() => {
    return () => {
      resetResults();
    };
  }, [resetResults]);
  
  // Show results when summon animation completes
  useEffect(() => {
    if (!isAnimating && results.length > 0) {
      setShowResults(true);
      playSuccess();
    }
  }, [isAnimating, results, playSuccess]);
  
  // Handle normal summon
  const handleNormalSummon = (count: number) => {
    if (isAnimating || showResults) return;
    performSummon("normal", count);
  };
  
  // Handle premium summon
  const handlePremiumSummon = (count: number) => {
    if (isAnimating || showResults) return;
    performSummon("premium", count);
  };
  
  // Handle viewing next result
  const handleNextResult = () => {
    if (currentResultIndex < results.length - 1) {
      setCurrentResultIndex(currentResultIndex + 1);
    } else {
      // Close results view when all results are seen
      setShowResults(false);
      resetResults();
      setCurrentResultIndex(0);
    }
  };
  
  // Render summon results screen
  if (showResults && results.length > 0) {
    const result = results[currentResultIndex];
    const character = getCharacterById(result.characterId);
    const card = getCardById(result.cardId);
    
    if (!character || !card) {
      return <div>Error loading result data</div>;
    }
    
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-900 p-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-2xl font-bold text-white mb-8"
        >
          <div className={cn(
            "mb-2 text-center",
            result.rarity === CharacterRarity.COMMON && "text-gray-300",
            result.rarity === CharacterRarity.RARE && "text-blue-300",
            result.rarity === CharacterRarity.EPIC && "text-purple-300",
            result.rarity === CharacterRarity.LEGENDARY && "text-yellow-300",
          )}>
            {result.rarity} {result.isNew ? "New Character!" : "Character"}
          </div>
        </motion.div>
        
        <div className="flex flex-col md:flex-row items-center gap-8">
          {/* Character card */}
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <CharacterCard 
              character={character} 
              size="lg"
              showStats={true}
            />
            {result.isNew && (
              <div className="mt-2 text-center bg-green-700 rounded-md py-1 px-2 text-white">
                NEW!
              </div>
            )}
          </motion.div>
          
          {/* Card */}
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <CardDisplay 
              card={card}
              size="lg"
            />
          </motion.div>
        </div>
        
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="mt-8"
        >
          <PixelButton onClick={handleNextResult}>
            {currentResultIndex < results.length - 1 ? "Next Result" : "Done"}
          </PixelButton>
        </motion.div>
        
        <div className="mt-4 text-gray-400 text-sm">
          Result {currentResultIndex + 1} of {results.length}
        </div>
      </div>
    );
  }
  
  // Render main summon screen
  return (
    <div className="flex-1 bg-gray-900 p-4 overflow-auto">
      <div className="max-w-4xl mx-auto">
        <div className="text-2xl font-bold text-white mb-4">Summon Cards</div>
        
        {/* Summon banners */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {/* Normal Summon */}
          <div className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700">
            <div className="bg-blue-800 p-4">
              <h3 className="text-xl font-bold text-white flex items-center">
                <RefreshCcw size={20} className="mr-2" />
                Normal Summon
              </h3>
              <p className="text-blue-200 text-sm mt-1">
                Summon cards with standard rates
              </p>
            </div>
            
            <div className="p-4">
              <div className="mb-4">
                <div className="text-gray-400 text-sm mb-1">Rates:</div>
                <div className="flex flex-wrap gap-2 text-xs">
                  <div className="bg-gray-700 px-2 py-1 rounded">Common: 80%</div>
                  <div className="bg-blue-900 px-2 py-1 rounded">Rare: 15%</div>
                  <div className="bg-purple-900 px-2 py-1 rounded">Epic: 4%</div>
                  <div className="bg-yellow-900 px-2 py-1 rounded">Legendary: 1%</div>
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                <div className="flex justify-between">
                  <PixelButton 
                    onClick={() => handleNormalSummon(1)}
                    disabled={isAnimating || (lastDailySummon !== null && gold < 100)}
                    size="md"
                  >
                    Single Pull
                    <div className="text-xs">
                      {lastDailySummon === null ? "Free (Daily)" : "100 Gold"}
                    </div>
                  </PixelButton>
                  
                  <PixelButton 
                    onClick={() => handleNormalSummon(10)}
                    disabled={isAnimating || gold < 800}
                    size="md"
                  >
                    Multi Pull (10)
                    <div className="text-xs">800 Gold</div>
                  </PixelButton>
                </div>
                
                <div className="text-xs text-gray-400 mt-1">
                  Available: {gold} Gold
                </div>
              </div>
            </div>
          </div>
          
          {/* Premium Summon */}
          <div className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700">
            <div className="bg-purple-800 p-4">
              <h3 className="text-xl font-bold text-white flex items-center">
                <Sparkles size={20} className="mr-2" />
                Premium Summon
              </h3>
              <p className="text-purple-200 text-sm mt-1">
                Summon cards with better rates for rare cards
              </p>
            </div>
            
            <div className="p-4">
              <div className="mb-4">
                <div className="text-gray-400 text-sm mb-1">Rates:</div>
                <div className="flex flex-wrap gap-2 text-xs">
                  <div className="bg-gray-700 px-2 py-1 rounded">Common: 50%</div>
                  <div className="bg-blue-900 px-2 py-1 rounded">Rare: 30%</div>
                  <div className="bg-purple-900 px-2 py-1 rounded">Epic: 15%</div>
                  <div className="bg-yellow-900 px-2 py-1 rounded">Legendary: 5%</div>
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                <div className="flex justify-between">
                  <PixelButton 
                    onClick={() => handlePremiumSummon(1)}
                    disabled={isAnimating || gems < 10}
                    size="md"
                  >
                    Single Pull
                    <div className="text-xs">10 Gems</div>
                  </PixelButton>
                  
                  <PixelButton 
                    onClick={() => handlePremiumSummon(10)}
                    disabled={isAnimating || gems < 90}
                    size="md"
                  >
                    Multi Pull (10)
                    <div className="text-xs">90 Gems</div>
                  </PixelButton>
                </div>
                
                <div className="text-xs text-gray-400 mt-1">
                  Available: {gems} Gems
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Pity System Explanation */}
        <div className="bg-gray-800 rounded-lg p-4 mb-8">
          <h3 className="font-bold text-white mb-2">Pity System</h3>
          <p className="text-gray-300 text-sm">
            Every 10 summons will guarantee at least one Rare or higher rarity character.
          </p>
        </div>
        
        {/* Card Banner */}
        <div className="bg-gray-800 rounded-lg p-4">
          <h3 className="font-bold text-white mb-2">Featured Cards</h3>
          <div className="flex overflow-x-auto gap-4 pb-2">
            {[501, 502, 503, 401, 301].map(cardId => {
              const card = getCardById(cardId);
              if (!card) return null;
              
              return (
                <CardDisplay
                  key={cardId}
                  card={card}
                  size="md"
                />
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Summon animation */}
      {isAnimating && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-70 z-50">
          <motion.div
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          >
            <div className="w-32 h-32 bg-purple-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">Summoning...</span>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default SummonBanner;
