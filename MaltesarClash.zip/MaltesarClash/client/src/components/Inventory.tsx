import React, { useState } from "react";
import { useCardCollection, PlayerCard } from "../lib/stores/useCardCollection";
import { cards, getCardById, getCardsByRarity } from "../data/cards";
import { Rarity } from "../lib/stores/useGameState";
import { Card } from "./Card";
import { GameButton } from "./ui/game-button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

interface InventoryProps {
  onSelectCard?: (cardId: string) => void;
}

export const Inventory: React.FC<InventoryProps> = ({ onSelectCard }) => {
  const { playerCards, decks, activeDeckId, addCardToDeck, removeCardFromDeck, getCardDetails } = useCardCollection();
  
  const [activeTab, setActiveTab] = useState<string>("all");
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [selectedDeckId, setSelectedDeckId] = useState<string>(activeDeckId);
  
  // Get selected card details
  const selectedPlayerCard = playerCards.find(pc => pc.id === selectedCardId);
  const selectedCardDetails = selectedPlayerCard ? getCardDetails(selectedPlayerCard.id) : null;
  
  // Filter cards based on active tab
  const getFilteredCards = (): PlayerCard[] => {
    if (activeTab === "all") {
      return playerCards;
    }
    
    if (activeTab === "in-deck") {
      return playerCards.filter(card => card.inDeck);
    }
    
    // Filter by rarity
    const rarity = activeTab as Rarity;
    return playerCards.filter(playerCard => {
      const cardDetails = getCardDetails(playerCard.id);
      return cardDetails?.rarity === rarity;
    });
  };
  
  // Handle card click
  const handleCardClick = (playerCardId: string) => {
    setSelectedCardId(playerCardId);
    if (onSelectCard) {
      onSelectCard(playerCardId);
    }
  };
  
  // Add card to selected deck
  const handleAddToDeck = () => {
    if (selectedCardId && selectedDeckId) {
      addCardToDeck(selectedDeckId, selectedCardId);
    }
  };
  
  // Remove card from selected deck
  const handleRemoveFromDeck = () => {
    if (selectedCardId && selectedDeckId) {
      removeCardFromDeck(selectedDeckId, selectedCardId);
    }
  };
  
  // Get deck info
  const selectedDeck = decks.find(deck => deck.id === selectedDeckId) || null;
  const isCardInSelectedDeck = selectedCardId && selectedDeck && selectedDeck.cards.includes(selectedCardId);
  
  // Check if the deck is full (20 cards max)
  const isDeckFull = selectedDeck ? selectedDeck.cards.length >= 20 : false;
  
  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Card list */}
        <div className="w-full lg:w-3/4 h-full flex flex-col">
          <Tabs defaultValue="all" className="w-full h-full">
            <div className="p-2 sm:p-4 border-b border-gray-800 overflow-x-auto">
              <TabsList className="w-full flex flex-wrap">
                <TabsTrigger value="all" onClick={() => setActiveTab("all")}>All Cards</TabsTrigger>
                <TabsTrigger value="in-deck" onClick={() => setActiveTab("in-deck")}>In Deck</TabsTrigger>
                <TabsTrigger value="Common" onClick={() => setActiveTab("Common")}>Common</TabsTrigger>
                <TabsTrigger value="Rare" onClick={() => setActiveTab("Rare")}>Rare</TabsTrigger>
                <TabsTrigger value="Epic" onClick={() => setActiveTab("Epic")}>Epic</TabsTrigger>
                <TabsTrigger value="Legendary" onClick={() => setActiveTab("Legendary")}>Legendary</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="all" className="flex-1 overflow-y-auto p-2 sm:p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-4">
                {getFilteredCards().map((playerCard) => {
                  const cardDetails = getCardDetails(playerCard.id);
                  return cardDetails ? (
                    <div
                      key={playerCard.id}
                      className={cn(
                        "cursor-pointer transition-transform hover:scale-105",
                        selectedCardId === playerCard.id ? "ring-2 ring-yellow-400" : ""
                      )}
                      onClick={() => handleCardClick(playerCard.id)}
                    >
                      <Card card={cardDetails} />
                      <div className="mt-1 text-xs flex justify-between">
                        <span>Lvl {playerCard.level}</span>
                        {playerCard.inDeck && <span className="text-green-400">In Deck</span>}
                      </div>
                    </div>
                  ) : null;
                })}
                
                {getFilteredCards().length === 0 && (
                  <div className="col-span-full text-center py-8 text-gray-400">
                    No cards found in this category.
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="in-deck" className="flex-1 overflow-y-auto p-2 sm:p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-4">
                {getFilteredCards().map((playerCard) => {
                  const cardDetails = getCardDetails(playerCard.id);
                  return cardDetails ? (
                    <div
                      key={playerCard.id}
                      className={cn(
                        "cursor-pointer transition-transform hover:scale-105",
                        selectedCardId === playerCard.id ? "ring-2 ring-yellow-400" : ""
                      )}
                      onClick={() => handleCardClick(playerCard.id)}
                    >
                      <Card card={cardDetails} />
                      <div className="mt-1 text-xs">
                        <span>Lvl {playerCard.level}</span>
                      </div>
                    </div>
                  ) : null;
                })}
                
                {getFilteredCards().length === 0 && (
                  <div className="col-span-full text-center py-8 text-gray-400">
                    No cards in your deck yet.
                  </div>
                )}
              </div>
            </TabsContent>
            
            {["Common", "Rare", "Epic", "Legendary"].map((rarity) => (
              <TabsContent key={rarity} value={rarity} className="flex-1 overflow-y-auto p-2 sm:p-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-4">
                  {getFilteredCards().map((playerCard) => {
                    const cardDetails = getCardDetails(playerCard.id);
                    return cardDetails ? (
                      <div
                        key={playerCard.id}
                        className={cn(
                          "cursor-pointer transition-transform hover:scale-105",
                          selectedCardId === playerCard.id ? "ring-2 ring-yellow-400" : ""
                        )}
                        onClick={() => handleCardClick(playerCard.id)}
                      >
                        <Card card={cardDetails} />
                        <div className="mt-1 text-xs flex justify-between">
                          <span>Lvl {playerCard.level}</span>
                          {playerCard.inDeck && <span className="text-green-400">In Deck</span>}
                        </div>
                      </div>
                    ) : null;
                  })}
                  
                  {getFilteredCards().length === 0 && (
                    <div className="col-span-full text-center py-8 text-gray-400">
                      No {rarity} cards found.
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
        
        {/* Card details - Full width on mobile, 1/4 width on larger screens */}
        <div className="w-full lg:w-1/4 h-full border-t lg:border-t-0 lg:border-l border-gray-800 p-3 sm:p-4 flex flex-col">
          <h2 className="text-lg font-semibold mb-4">Card Details</h2>
          
          {selectedCardDetails ? (
            <div className="flex flex-col items-center">
              <div className="hidden sm:block">
                <Card card={selectedCardDetails} className="scale-125 mb-6" />
              </div>
              <div className="block sm:hidden mb-4">
                <Card card={selectedCardDetails} />
              </div>
              
              <div className="w-full mt-2 sm:mt-4">
                <h3 className="text-md font-semibold">{selectedCardDetails.name}</h3>
                <p className="text-sm text-gray-300 mb-2">{selectedCardDetails.description}</p>
                
                <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                  <div className="bg-gray-800 p-2 rounded">
                    <span className="text-gray-400">Type:</span>
                    <span className="block">{selectedCardDetails.type.charAt(0).toUpperCase() + selectedCardDetails.type.slice(1)}</span>
                  </div>
                  <div className="bg-gray-800 p-2 rounded">
                    <span className="text-gray-400">Rarity:</span>
                    <span 
                      className={cn(
                        "block",
                        selectedCardDetails.rarity === "Common" ? "text-gray-300" :
                        selectedCardDetails.rarity === "Rare" ? "text-blue-300" :
                        selectedCardDetails.rarity === "Epic" ? "text-purple-300" :
                        "text-yellow-300"
                      )}
                    >
                      {selectedCardDetails.rarity}
                    </span>
                  </div>
                  <div className="bg-gray-800 p-2 rounded">
                    <span className="text-gray-400">Mana Cost:</span>
                    <span className="block">{selectedCardDetails.manaCost}</span>
                  </div>
                  <div className="bg-gray-800 p-2 rounded">
                    <span className="text-gray-400">Value:</span>
                    <span className="block">{selectedCardDetails.value}</span>
                  </div>
                </div>
                
                {/* Deck management buttons */}
                <div className="flex flex-col space-y-2 mt-2 sm:mt-4">
                  <select 
                    className="bg-gray-800 text-white rounded p-2 mb-2 text-sm"
                    value={selectedDeckId}
                    onChange={(e) => setSelectedDeckId(e.target.value)}
                  >
                    {decks.map(deck => (
                      <option key={deck.id} value={deck.id}>
                        {deck.name} {deck.id === activeDeckId ? "(Active)" : ""}
                      </option>
                    ))}
                  </select>
                  
                  {isCardInSelectedDeck ? (
                    <GameButton 
                      variant="destructive" 
                      onClick={handleRemoveFromDeck}
                      size="sm"
                      className="w-full"
                    >
                      Remove from Deck
                    </GameButton>
                  ) : (
                    <GameButton 
                      variant="secondary" 
                      onClick={handleAddToDeck}
                      size="sm"
                      className="w-full"
                      disabled={isDeckFull}
                    >
                      Add to Deck
                    </GameButton>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">
              Select a card to view details
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
