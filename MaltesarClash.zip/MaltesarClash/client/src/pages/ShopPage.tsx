import React, { useEffect } from "react";
import { MainMenu } from "../components/MainMenu";
import { Shop } from "../components/Shop";
import { useGameState } from "../lib/stores/useGameState";
import { useAudio } from "../lib/stores/useAudio";
import { useCurrency, ShopItem } from "../lib/stores/useCurrency";
import { toast } from "sonner";

const ShopPage: React.FC = () => {
  const { setCurrentScreen } = useGameState();
  const { backgroundMusic } = useAudio();
  
  // Initialize page
  useEffect(() => {
    setCurrentScreen("shop");
    
    if (backgroundMusic && !backgroundMusic.playing()) {
      backgroundMusic.play();
    }
  }, [backgroundMusic, setCurrentScreen]);
  
  // Handle item purchase
  const handlePurchase = (item: ShopItem) => {
    toast.success(`Successfully purchased ${item.name}!`);
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Shop Content */}
      <div className="flex-1 overflow-hidden">
        <Shop onPurchase={handlePurchase} />
      </div>
    </div>
  );
};

export default ShopPage;
