import React, { useEffect, useState } from "react";
import { MainMenu } from "../components/MainMenu";
import { GachaBanner } from "../components/GachaBanner";
import { useGameState } from "../lib/stores/useGameState";
import { useCurrency } from "../lib/stores/useCurrency";
import { useAudio } from "../lib/stores/useAudio";
import { cards, CardType } from "../data/cards";
import { characters, Character } from "../data/characters";
import { Card } from "../components/Card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const GachaPage: React.FC = () => {
  const { setCurrentScreen } = useGameState();
  const { gold, gems } = useCurrency();
  const { backgroundMusic } = useAudio();
  
  const [pullHistory, setPullHistory] = useState<(CardType | Character)[]>([]);
  
  // Initialize page
  useEffect(() => {
    setCurrentScreen("gacha");
    
    if (backgroundMusic && !backgroundMusic.playing()) {
      backgroundMusic.play();
    }
  }, [backgroundMusic, setCurrentScreen]);
  
  // Handle gacha pull
  const handlePull = (results: (CardType | Character)[]) => {
    setPullHistory(prev => [...results, ...prev].slice(0, 50)); // Keep last 50 pulls
  };
  
  // Filter available characters (don't include unlockable by story/dungeon)
  const availableCharacters = characters.filter(char => !char.unlockCondition);
  
  // Standard Banner weights
  const standardWeights = {
    "Common": 70,
    "Rare": 25,
    "Epic": 4,
    "Legendary": 1
  };
  
  // Premium Banner weights
  const premiumWeights = {
    "Common": 40,
    "Rare": 40,
    "Epic": 15,
    "Legendary": 5
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Currency Display */}
      <div className="bg-gray-800 p-3 border-b border-gray-700 flex justify-center space-x-8">
        <div className="flex items-center">
          <span className="text-amber-400 mr-2">Gold:</span>
          <span className="font-semibold">{gold}</span>
        </div>
        <div className="flex items-center">
          <span className="text-purple-400 mr-2">Gems:</span>
          <span className="font-semibold">{gems}</span>
        </div>
      </div>
      
      {/* Gacha Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <Tabs defaultValue="standard">
          <TabsList className="w-full max-w-md mx-auto mb-6">
            <TabsTrigger value="standard">Standard Banner</TabsTrigger>
            <TabsTrigger value="premium">Premium Banner</TabsTrigger>
            <TabsTrigger value="history">Pull History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="standard">
            <div className="flex justify-center">
              <GachaBanner 
                name="Standard Banner"
                description="A standard banner with a chance to obtain all characters and cards."
                cards={cards}
                characters={availableCharacters}
                cost={100}
                currencyType="gold"
                isFreePull={true}
                rarityWeights={standardWeights}
                onPull={handlePull}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="premium">
            <div className="flex justify-center">
              <GachaBanner 
                name="Premium Banner"
                description="A premium banner with increased rates for rare cards and characters."
                cards={cards}
                characters={availableCharacters}
                cost={10}
                currencyType="gems"
                rarityWeights={premiumWeights}
                onPull={handlePull}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="history">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-xl font-semibold mb-4">Pull History</h2>
              
              {pullHistory.length > 0 ? (
                <div className="grid grid-cols-5 gap-4">
                  {pullHistory.map((item, index) => (
                    <div key={index}>
                      {'manaCost' in item ? (
                        // It's a card
                        <Card card={item as CardType} />
                      ) : (
                        // It's a character
                        <div className="w-24 h-32 bg-gray-800 rounded-md flex flex-col items-center justify-center p-2">
                          <div 
                            className="w-16 h-16 mb-1" 
                            dangerouslySetInnerHTML={{ __html: (item as Character).portrait }}
                          />
                          <div className="text-xs text-center">
                            {(item as Character).name}
                          </div>
                          <div className="text-[10px] font-semibold text-center" style={{
                            color: 
                              (item as Character).rarity === "Common" ? "#9ca3af" :
                              (item as Character).rarity === "Rare" ? "#3b82f6" :
                              (item as Character).rarity === "Epic" ? "#8b5cf6" :
                              "#f59e0b"
                          }}>
                            {(item as Character).rarity}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-gray-400 py-10">
                  No pull history yet. Try your luck on one of the banners!
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        {/* Banner Rates */}
        <div className="mt-8 max-w-md mx-auto bg-gray-800 rounded-lg p-4">
          <h3 className="font-semibold mb-2">Banner Rates</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Standard Banner</h4>
              <ul className="text-xs space-y-1">
                <li className="flex justify-between">
                  <span className="text-gray-400">Common:</span>
                  <span>70%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-blue-400">Rare:</span>
                  <span>25%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-purple-400">Epic:</span>
                  <span>4%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-yellow-400">Legendary:</span>
                  <span>1%</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-sm font-medium mb-1">Premium Banner</h4>
              <ul className="text-xs space-y-1">
                <li className="flex justify-between">
                  <span className="text-gray-400">Common:</span>
                  <span>40%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-blue-400">Rare:</span>
                  <span>40%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-purple-400">Epic:</span>
                  <span>15%</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-yellow-400">Legendary:</span>
                  <span>5%</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-3 text-xs text-gray-400">
            Note: A pity system guarantees at least one Rare or better item every 10 pulls.
          </div>
        </div>
      </div>
    </div>
  );
};

export default GachaPage;
