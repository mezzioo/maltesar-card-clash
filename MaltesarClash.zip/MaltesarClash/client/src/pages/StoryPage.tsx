import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainMenu } from "../components/MainMenu";
import { StoryScene } from "../components/StoryScene";
import { useGameState } from "../lib/stores/useGameState";
import { useStoryMode } from "../lib/stores/useStoryMode";
import { useAudio } from "../lib/stores/useAudio";
import { storyChapters, StoryChapter, DialogueLine } from "../data/story";
import { GameButton } from "../components/ui/game-button";
import { toast } from "sonner";

const StoryPage: React.FC = () => {
  const { 
    playerLevel, 
    setCurrentScreen, 
    tutorialCompleted, 
    completeTutorial 
  } = useGameState();
  
  const { 
    currentChapterId, 
    completedChapters, 
    startChapter, 
    getCurrentChapter, 
    getCurrentLine, 
    nextLine, 
    makeChoice,
    completeChapter,
    getAvailableChapters
  } = useStoryMode();
  
  const { backgroundMusic } = useAudio();
  const navigate = useNavigate();
  
  const [activeStoryMode, setActiveStoryMode] = useState<boolean>(false);
  const [availableChapters, setAvailableChapters] = useState<StoryChapter[]>([]);
  const [currentDialogue, setCurrentDialogue] = useState<DialogueLine[]>([]);
  
  // Initialize page
  useEffect(() => {
    setCurrentScreen("story");
    
    if (backgroundMusic && !backgroundMusic.playing()) {
      backgroundMusic.play();
    }
    
    // If this is the first time, start the tutorial (Chapter 1)
    if (!tutorialCompleted && !currentChapterId) {
      handleStartChapter('chapter-1');
    }
    
    // Get available chapters
    const chapters = getAvailableChapters();
    setAvailableChapters(chapters);
  }, [backgroundMusic, currentChapterId, getAvailableChapters, setCurrentScreen, tutorialCompleted]);
  
  // Update dialogue when chapter changes
  useEffect(() => {
    if (currentChapterId) {
      const chapter = getCurrentChapter();
      if (chapter) {
        setCurrentDialogue(chapter.dialogue);
        setActiveStoryMode(true);
      }
    }
  }, [currentChapterId, getCurrentChapter]);
  
  // Handle starting a chapter
  const handleStartChapter = (chapterId: string) => {
    startChapter(chapterId);
    setActiveStoryMode(true);
    toast.info(`Starting chapter: ${storyChapters.find(c => c.id === chapterId)?.title}`);
  };
  
  // Handle completing a chapter
  const handleCompleteStory = () => {
    // Check if this was the tutorial chapter
    if (currentChapterId === 'chapter-1' && !tutorialCompleted) {
      completeTutorial();
      toast.success("Tutorial completed! You can now access all game features.");
    }
    
    completeChapter();
    setActiveStoryMode(false);
    
    // Get updated available chapters
    const chapters = getAvailableChapters();
    setAvailableChapters(chapters);
  };
  
  // Handle choice selection
  const handleChoice = (choiceIndex: number) => {
    // Get the current line to check if it's a card choice
    const currentLine = getCurrentLine();
    if (currentLine?.choices && currentLine.choices[choiceIndex]?.effect?.type === "cards") {
      // It's a card choice, show a toast notification
      const cardCount = currentLine.choices[choiceIndex].effect?.value || 0;
      const chapter = getCurrentChapter();
      
      if (chapter?.reward?.cards && cardCount > 0) {
        const cardNames = chapter.reward.cards.slice(0, cardCount)
          .map(cardId => cardId.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '))
          .join(' and ');
          
        // Show a very noticeable success toast for the cards
        toast.success(`You received ${cardCount} cards: ${cardNames}!`, {
          duration: 5000,
          position: "top-center",
          style: { 
            background: "#059669", 
            color: "white",
            fontSize: "1.1rem",
            border: "2px solid #10b981",
            padding: "16px"
          },
        });
      }
    }
    
    // Make the choice in the story state
    makeChoice(choiceIndex);
  };
  
  // Render story selection
  const renderStorySelection = () => {
    return (
      <div className="container mx-auto p-6">
        <h2 className="text-2xl font-bold mb-6">Story Chapters</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {availableChapters.map(chapter => {
            const isCompleted = completedChapters.includes(chapter.id);
            
            return (
              <div 
                key={chapter.id} 
                className={`bg-gray-800 rounded-lg p-4 border-l-4 ${isCompleted ? 'border-green-500' : 'border-amber-500'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold">{chapter.title}</h3>
                  <div 
                    className={`px-2 py-1 text-xs rounded ${isCompleted ? 'bg-green-900 text-green-300' : 'bg-amber-900 text-amber-300'}`}
                  >
                    {isCompleted ? 'Completed' : 'Available'}
                  </div>
                </div>
                
                <p className="text-sm text-gray-400 mb-3">{chapter.description}</p>
                
                {chapter.reward && (
                  <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                    {chapter.reward.exp && (
                      <div className="bg-gray-700 p-2 rounded">
                        <span className="text-blue-400">EXP Reward:</span>
                        <span className="block">{chapter.reward.exp}</span>
                      </div>
                    )}
                    {chapter.reward.currency && (
                      <div className="bg-gray-700 p-2 rounded">
                        <span className="text-amber-400">Gold Reward:</span>
                        <span className="block">{chapter.reward.currency}</span>
                      </div>
                    )}
                    {chapter.reward.unlockCharacter && (
                      <div className="bg-gray-700 p-2 rounded col-span-2">
                        <span className="text-purple-400">Unlocks Character:</span>
                        <span className="block">{chapter.reward.unlockCharacter}</span>
                      </div>
                    )}
                  </div>
                )}
                
                <GameButton 
                  onClick={() => handleStartChapter(chapter.id)}
                  variant={isCompleted ? "secondary" : "default"}
                  size="sm"
                >
                  {isCompleted ? 'Replay Chapter' : 'Start Chapter'}
                </GameButton>
              </div>
            );
          })}
        </div>
        
        {availableChapters.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            No story chapters available yet. Level up to unlock more content.
          </div>
        )}
        
        {/* Tutorial hint for new players */}
        {!tutorialCompleted && (
          <div className="mt-6 bg-blue-900/50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">New Player?</h3>
            <p className="text-sm">
              Complete the tutorial chapter to unlock all game features!
            </p>
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav - Only show when not in active story mode */}
      {!activeStoryMode && <MainMenu isCompact />}
      
      {/* Story Content */}
      <div className="flex-1 overflow-hidden">
        {activeStoryMode ? (
          <StoryScene
            dialogue={currentDialogue}
            onComplete={handleCompleteStory}
            onChoice={handleChoice}
          />
        ) : (
          renderStorySelection()
        )}
      </div>
    </div>
  );
};

export default StoryPage;
