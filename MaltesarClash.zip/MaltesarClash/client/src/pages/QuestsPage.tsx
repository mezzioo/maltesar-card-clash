import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuestSystem } from '@/lib/stores/useQuestSystem';
import { QuestLog } from '@/components/QuestLog';
import { GameWrapper } from '@/components/GameWrapper';
import { X } from 'lucide-react';
import { MainMenu } from '@/components/MainMenu';

export default function QuestsPage() {
  const navigate = useNavigate();
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Back button */}
        <button 
          onClick={() => navigate('/')}
          className="absolute top-4 right-4 z-20 bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors shadow-md border border-gray-700"
          aria-label="Close quest log"
        >
          <X size={20} className="text-white" />
        </button>
        
        <QuestLog />
      </div>
    </div>
  );
}