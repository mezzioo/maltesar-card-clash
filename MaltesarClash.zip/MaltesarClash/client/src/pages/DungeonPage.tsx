import React, { useState, useEffect } from "react";
import { MainMenu } from "../components/MainMenu";
import { DungeonMap } from "../components/DungeonMap";
import { BattleField } from "../components/BattleField";
import { StoryScene } from "../components/StoryScene";
import { useGameState } from "../lib/stores/useGameState";
import { useDungeon } from "../lib/stores/useDungeon";
import { useBattleSystem } from "../lib/stores/useBattleSystem";
import { useAudio } from "../lib/stores/useAudio";
import { getCharacterById } from "../data/characters";
import { getEnemyById, Enemy } from "../data/enemies";
import { DungeonEvent } from "../data/dungeons";
import { GameButton } from "../components/ui/game-button";
import { toast } from "sonner";

const DungeonPage: React.FC = () => {
  const { setCurrentScreen, unlockedCharacters } = useGameState();
  const { 
    enterDungeon, 
    exitDungeon, 
    getCurrentDungeon, 
    getCurrentStage, 
    currentEvent,
    processBattleVictory 
  } = useDungeon();
  const { initializeBattle, resetBattle, phase } = useBattleSystem();
  const { backgroundMusic, playHit } = useAudio();
  
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>('hamid');
  const [selectedDungeonId, setSelectedDungeonId] = useState<string | null>(null);
  const [currentEventState, setCurrentEventState] = useState<DungeonEvent | null>(null);
  const [eventMode, setEventMode] = useState<'map' | 'battle' | 'story' | 'reward' | 'choice'>('map');
  const [enemies, setEnemies] = useState<Enemy[]>([]);
  
  // Initialize page
  useEffect(() => {
    setCurrentScreen("dungeon");
    
    if (backgroundMusic && !backgroundMusic.playing()) {
      backgroundMusic.play();
    }
    
    return () => {
      // Reset battle system when leaving page
      resetBattle();
    };
  }, [backgroundMusic, resetBattle, setCurrentScreen]);
  
  // Update when dungeon event changes
  useEffect(() => {
    if (currentEvent) {
      setCurrentEventState(currentEvent);
      
      switch (currentEvent.type) {
        case 'battle':
          setEventMode('battle');
          setupBattle(currentEvent);
          break;
        case 'story':
          setEventMode('story');
          break;
        case 'reward':
          setEventMode('reward');
          break;
        case 'choice':
          setEventMode('choice');
          break;
      }
    }
  }, [currentEvent]);
  
  // Setup battle with enemies from event
  const setupBattle = (event: DungeonEvent) => {
    if (event.enemies && event.enemies.length > 0) {
      const battleEnemies = event.enemies
        .map(enemyId => getEnemyById(enemyId))
        .filter((enemy): enemy is Enemy => enemy !== undefined);
      
      setEnemies(battleEnemies);
      
      const character = getCharacterById(selectedCharacterId);
      if (character && battleEnemies.length > 0) {
        initializeBattle(character, battleEnemies);
      }
    }
  };
  
  // Handle dungeon selection
  const handleSelectDungeon = (dungeonId: string) => {
    setSelectedDungeonId(dungeonId);
    enterDungeon(dungeonId);
    playHit();
    toast.success(`Entering dungeon: ${getCurrentDungeon()?.name}`);
  };
  
  // Handle event selection
  const handleSelectEvent = (event: DungeonEvent) => {
    setCurrentEventState(event);
    
    switch (event.type) {
      case 'battle':
        setEventMode('battle');
        setupBattle(event);
        toast.info(`Battle begins: ${event.title}`);
        break;
      case 'story':
        setEventMode('story');
        toast.info(`Story event: ${event.title}`);
        break;
      case 'reward':
        setEventMode('reward');
        toast.success(`Found a reward: ${event.title}`);
        break;
      case 'choice':
        setEventMode('choice');
        toast.info(`Choice event: ${event.title}`);
        break;
    }
  };
  
  // Handle battle victory
  const handleBattleVictory = () => {
    if (currentEventState && currentEventState.type === 'battle') {
      processBattleVictory(enemies);
      toast.success("Victory! You've defeated all enemies!");
      setEventMode('map');
    }
  };
  
  // Handle battle defeat
  const handleBattleDefeat = () => {
    exitDungeon();
    toast.error("Defeated! You've been forced to retreat from the dungeon.");
    setEventMode('map');
  };
  
  // Handle story completion
  const handleStoryComplete = () => {
    setEventMode('map');
  };
  
  // Handle choice selection
  const handleChoice = (choiceIndex: number) => {
    // Process choice outcome
    if (currentEventState && currentEventState.type === 'choice' && currentEventState.choices) {
      const choice = currentEventState.choices[choiceIndex];
      toast.info(`You chose: ${choice.text}`);
      setEventMode('map');
    }
  };
  
  // Handle reward collection
  const handleCollectReward = () => {
    // Process reward collection
    if (currentEventState && currentEventState.type === 'reward' && currentEventState.reward) {
      toast.success("Reward collected!");
      setEventMode('map');
    }
  };
  
  // Return to dungeon map
  const handleReturnToMap = () => {
    setEventMode('map');
  };
  
  // Handle character selection
  const handleCharacterSelect = (charId: string) => {
    setSelectedCharacterId(charId);
  };
  
  // Render content based on current event mode
  const renderContent = () => {
    switch (eventMode) {
      case 'map':
        return <DungeonMap onSelectDungeon={handleSelectDungeon} onSelectEvent={handleSelectEvent} />;
        
      case 'battle':
        return <BattleField onVictory={handleBattleVictory} onDefeat={handleBattleDefeat} />;
        
      case 'story':
        if (currentEventState && currentEventState.dialogueId) {
          // Create simple dialogue for the story event
          const dialogue = [
            {
              speaker: "Narrator",
              text: currentEventState.description,
            }
          ];
          return <StoryScene dialogue={dialogue} onComplete={handleStoryComplete} />;
        }
        return (
          <div className="flex flex-col items-center justify-center p-6">
            <h2 className="text-2xl mb-4">{currentEventState?.title}</h2>
            <p className="text-gray-300 mb-6">{currentEventState?.description}</p>
            <GameButton onClick={handleReturnToMap}>Continue</GameButton>
          </div>
        );
        
      case 'reward':
        return (
          <div className="flex flex-col items-center justify-center p-6">
            <h2 className="text-2xl text-amber-500 mb-4">{currentEventState?.title}</h2>
            <p className="text-gray-300 mb-6">{currentEventState?.description}</p>
            
            {currentEventState?.reward && (
              <div className="bg-gray-800 rounded-lg p-4 mb-6 w-full max-w-md">
                <h3 className="font-semibold mb-2">Rewards:</h3>
                <ul className="space-y-2">
                  {currentEventState.reward.exp && (
                    <li className="flex items-center">
                      <span className="text-blue-400 mr-2">EXP:</span> 
                      <span>{currentEventState.reward.exp}</span>
                    </li>
                  )}
                  {currentEventState.reward.currency && (
                    <li className="flex items-center">
                      <span className="text-amber-400 mr-2">Gold:</span> 
                      <span>{currentEventState.reward.currency}</span>
                    </li>
                  )}
                  {currentEventState.reward.cards && currentEventState.reward.cards.length > 0 && (
                    <li className="flex items-center">
                      <span className="text-purple-400 mr-2">Cards:</span> 
                      <span>{currentEventState.reward.cards.join(', ')}</span>
                    </li>
                  )}
                </ul>
              </div>
            )}
            
            <GameButton onClick={handleCollectReward}>Collect Rewards</GameButton>
          </div>
        );
        
      case 'choice':
        return (
          <div className="flex flex-col items-center justify-center p-6">
            <h2 className="text-2xl mb-4">{currentEventState?.title}</h2>
            <p className="text-gray-300 mb-6">{currentEventState?.description}</p>
            
            {currentEventState?.choices && (
              <div className="space-y-3 w-full max-w-md">
                {currentEventState.choices.map((choice, index) => (
                  <GameButton 
                    key={index}
                    onClick={() => handleChoice(index)}
                    variant="outline"
                    className="w-full text-left"
                  >
                    {choice.text}
                  </GameButton>
                ))}
              </div>
            )}
          </div>
        );
        
      default:
        return <div>Loading...</div>;
    }
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Character selection bar - shown only in map mode */}
      {eventMode === 'map' && (
        <div className="bg-gray-800 p-2 border-b border-gray-700 flex items-center">
          <div className="mr-4 text-sm">Select Character:</div>
          <div className="flex space-x-2">
            {unlockedCharacters.map(charId => {
              const character = getCharacterById(charId);
              return character ? (
                <div 
                  key={charId}
                  className={`cursor-pointer p-1 rounded ${selectedCharacterId === charId ? 'bg-amber-700' : 'bg-gray-700'}`}
                  onClick={() => handleCharacterSelect(charId)}
                >
                  <div 
                    className="w-8 h-8" 
                    dangerouslySetInnerHTML={{ __html: character.portrait }}
                    title={character.name}
                  />
                </div>
              ) : null;
            })}
          </div>
        </div>
      )}
      
      {/* Dungeon Content */}
      <div className="flex-1 overflow-hidden">
        {renderContent()}
      </div>
    </div>
  );
};

export default DungeonPage;
