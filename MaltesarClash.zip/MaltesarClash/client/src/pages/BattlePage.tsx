import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MainMenu } from "../components/MainMenu";
import { BattleField } from "../components/BattleField";
import { useBattleSystem } from "../lib/stores/useBattleSystem";
import { useGameState } from "../lib/stores/useGameState";
import { useCardCollection } from "../lib/stores/useCardCollection";
import { GameButton } from "../components/ui/game-button";
import { useAudio } from "../lib/stores/useAudio";
import { getCharacterById } from "../data/characters";
import { getEnemyById, Enemy } from "../data/enemies";
import { toast } from "sonner";
import { ArrowLeftCircle } from "lucide-react";

const BattlePage: React.FC = () => {
  const { 
    initializeBattle, 
    resetBattle, 
    phase 
  } = useBattleSystem();
  
  const { 
    playerLevel, 
    setCurrentScreen,
    gainExp,
    unlockedCharacters
  } = useGameState();
  
  const { getActiveDeck } = useCardCollection();
  const navigate = useNavigate();
  const { backgroundMusic, isMuted, toggleMute } = useAudio();
  
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>('hamid');
  const [battleReady, setBattleReady] = useState<boolean>(false);
  const [battleCompleted, setBattleCompleted] = useState<boolean>(false);
  const [battleResult, setBattleResult] = useState<'victory' | 'defeat' | null>(null);
  
  // Define enemies based on player level
  const getRandomEnemies = (): Enemy[] => {
    const enemyPool = ['minion-weak', 'minion-medium', 'minion-strong'];
    const count = Math.min(3, Math.ceil(playerLevel / 2));
    const selectedEnemies: Enemy[] = [];
    
    for (let i = 0; i < count; i++) {
      // More difficult enemies as player progresses
      let enemyId = enemyPool[Math.min(Math.floor(playerLevel / 3), enemyPool.length - 1)];
      
      // Boss fight every 5 levels
      if (playerLevel % 5 === 0 && i === 0) {
        if (playerLevel >= 15) {
          enemyId = 'mr-crashout';
        } else if (playerLevel >= 10) {
          enemyId = 'tilawa-crashout';
        } else if (playerLevel >= 5) {
          enemyId = 'history-crashout';
        }
      }
      
      const enemy = getEnemyById(enemyId);
      if (enemy) selectedEnemies.push(enemy);
    }
    
    return selectedEnemies;
  };
  
  // Set up the battle
  useEffect(() => {
    // Update current screen in game state
    setCurrentScreen("battle");
    
    // Stop background music and play battle music if available
    if (backgroundMusic) {
      backgroundMusic.pause();
    }
    
    return () => {
      // Clean up battle
      resetBattle();
      
      // Resume background music
      if (backgroundMusic && !isMuted) {
        backgroundMusic.play();
      }
    };
  }, [backgroundMusic, isMuted, resetBattle, setCurrentScreen]);
  
  // Start battle with selected character
  const handleStartBattle = () => {
    const character = getCharacterById(selectedCharacterId);
    const enemies = getRandomEnemies();
    
    if (character && enemies.length > 0) {
      // Check if player has an active deck
      const activeDeck = getActiveDeck();
      if (!activeDeck || activeDeck.cards.length === 0) {
        toast.error("You need to create a deck with cards before battling!");
        return;
      }
      
      initializeBattle(character, enemies);
      setBattleReady(true);
    } else {
      toast.error("Failed to initialize battle. Please try again.");
    }
  };
  
  // Handle battle completion
  const handleVictory = () => {
    setBattleCompleted(true);
    setBattleResult('victory');
    // Reward is handled in the battle system
    toast.success("Victory! You've earned experience and rewards!");
  };
  
  const handleDefeat = () => {
    setBattleCompleted(true);
    setBattleResult('defeat');
    toast.error("Defeated! Better luck next time!");
  };
  
  // Return to character selection
  const handleReturnToSelection = () => {
    setBattleReady(false);
    setBattleCompleted(false);
    setBattleResult(null);
    resetBattle();
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-900 text-white">
      {/* Top Nav */}
      <MainMenu isCompact />
      
      {/* Battle Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {!battleReady ? (
          // Character selection screen
          <div className="flex-1 flex flex-col items-center justify-center p-6 relative">
            {/* Back button */}
            <button 
              onClick={() => navigate('/')}
              className="absolute top-4 left-4 flex items-center text-gray-400 hover:text-white"
            >
              <ArrowLeftCircle className="w-5 h-5 mr-1" />
              <span>Back to Menu</span>
            </button>
            
            <h2 className="text-2xl font-bold mb-6">Select Your Character</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-5xl mb-8 overflow-y-auto max-h-[60vh] p-2">
              {unlockedCharacters.map(charId => {
                const character = getCharacterById(charId);
                return character ? (
                  <div 
                    key={charId}
                    className={`bg-gray-800 p-4 rounded-lg cursor-pointer transition-all ${selectedCharacterId === charId ? 'ring-2 ring-amber-500 transform scale-105' : 'hover:bg-gray-700'}`}
                    onClick={() => setSelectedCharacterId(charId)}
                  >
                    <div className="flex justify-center mb-3">
                      <div 
                        className="w-24 h-24" 
                        dangerouslySetInnerHTML={{ __html: character.portrait }}
                      />
                    </div>
                    <h3 className="text-center font-semibold mb-1">{character.name}</h3>
                    <p className="text-xs text-gray-400 text-center mb-2">{character.rarity}</p>
                    
                    <div className="grid grid-cols-2 gap-1 text-xs">
                      <div className="bg-gray-700 p-1 rounded">HP: {character.baseHP}</div>
                      <div className="bg-gray-700 p-1 rounded">ATK: {character.baseAttack}</div>
                      <div className="bg-gray-700 p-1 rounded">DEF: {character.baseDefense}</div>
                      <div className="bg-gray-700 p-1 rounded">SPD: {character.baseSpeed}</div>
                    </div>
                  </div>
                ) : null;
              })}
            </div>
            
            <GameButton onClick={handleStartBattle} size="lg" className="mt-4">
              Start Battle
            </GameButton>
          </div>
        ) : battleCompleted ? (
          // Battle results screen
          <div className="flex-1 flex flex-col items-center justify-center p-6">
            <h2 className={`text-3xl font-bold mb-4 ${battleResult === 'victory' ? 'text-green-500' : 'text-red-500'}`}>
              {battleResult === 'victory' ? 'Victory!' : 'Defeat!'}
            </h2>
            
            <p className="text-lg mb-8">
              {battleResult === 'victory'
                ? "You've defeated all enemies and earned rewards!"
                : "You were defeated. Better luck next time!"}
            </p>
            
            <div className="space-x-4">
              <GameButton onClick={handleReturnToSelection} size="lg">
                New Battle
              </GameButton>
              
              <GameButton variant="secondary" onClick={() => navigate('/')} size="lg">
                Return to Menu
              </GameButton>
            </div>
          </div>
        ) : (
          // Active battle
          <div className="flex-1 relative">
            {/* Back button for battle */}
            <button 
              onClick={handleReturnToSelection}
              className="absolute top-4 left-4 z-10 flex items-center text-gray-400 hover:text-white bg-gray-800/70 px-2 py-1 rounded"
            >
              <ArrowLeftCircle className="w-5 h-5 mr-1" />
              <span>Return to Selection</span>
            </button>
            <BattleField onVictory={handleVictory} onDefeat={handleDefeat} />
          </div>
        )}
      </div>
    </div>
  );
};

export default BattlePage;
