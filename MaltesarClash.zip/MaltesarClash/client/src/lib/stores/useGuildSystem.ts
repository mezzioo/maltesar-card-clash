import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';
import { useGame } from './useGame';
import { useCurrency } from './useCurrency';
import { useQuestSystem } from './useQuestSystem';

export type GuildRank = "Leader" | "Officer" | "Veteran" | "Member";

export interface GuildMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: number; // UNIX timestamp
  isSystem: boolean;
}

export interface GuildMember {
  id: string;
  name: string;
  level: number;
  joinDate: number; // UNIX timestamp
  rank: GuildRank;
  lastActiveDate: number; // UNIX timestamp
  contributionPoints: number;
}

export interface Guild {
  id: string;
  name: string;
  description: string;
  emblem: string; // Path or ID to emblem
  level: number;
  exp: number;
  expToNextLevel: number;
  creationDate: number; // UNIX timestamp
  members: GuildMember[];
  messages: GuildMessage[];
  dailyCheckins: string[]; // Array of member IDs who checked in today
  lastDailyReset: number; // UNIX timestamp
}

export type GuildInvite = {
  guildId: string;
  guildName: string;
  inviterId: string;
  inviterName: string;
  timestamp: number;
};

interface GuildSystemState {
  // Player guild info
  playerGuildId: string | null;
  pendingInvites: GuildInvite[];
  
  // All guilds in the game
  guilds: Guild[];
  
  // Guild actions
  createGuild: (name: string, description: string, emblem: string) => string | null;
  joinGuild: (guildId: string) => boolean;
  leaveGuild: () => boolean;
  sendGuildInvite: (playerId: string, playerName: string) => boolean;
  acceptInvite: (guildId: string) => boolean;
  declineInvite: (guildId: string) => void;
  kickMember: (memberId: string) => boolean;
  promoteMember: (memberId: string) => boolean;
  demoteMember: (memberId: string) => boolean;
  updateGuildDescription: (description: string) => boolean;
  updateGuildEmblem: (emblem: string) => boolean;
  sendGuildMessage: (content: string) => string | null;
  dailyCheckin: () => boolean;
  
  // Guild utility functions
  getPlayerGuild: () => Guild | null;
  getGuildByName: (name: string) => Guild | null;
  getGuildById: (id: string) => Guild | null;
  getPlayerGuildRank: () => GuildRank | null;
  canManageGuild: () => boolean;
  getGuildMembers: () => GuildMember[];
  getGuildMessages: () => GuildMessage[];
  getRecentMessages: (count?: number) => GuildMessage[];
  hasCheckedInToday: () => boolean;
  getDailyCheckinCount: () => number;
}

export const useGuildSystem = create<GuildSystemState>()(
  persist(
    (set, get) => ({
      // Initial state
      playerGuildId: null,
      pendingInvites: [],
      guilds: [],

      // Create a new guild
      createGuild: (name, description, emblem) => {
        // Check if name is already taken
        if (get().getGuildByName(name)) {
          return null; // Guild name already exists
        }

        const { playerLevel } = useGame.getState();
        const id = nanoid();

        // Create the guild
        const newGuild: Guild = {
          id,
          name,
          description,
          emblem,
          level: 1,
          exp: 0,
          expToNextLevel: 500,
          creationDate: Date.now(),
          members: [],
          messages: [],
          dailyCheckins: [],
          lastDailyReset: Date.now()
        };

        // Add player as leader
        const playerId = nanoid(); // In a real app, this would be the actual player ID
        const playerName = 'Player'; // In a real app, this would be the actual player name

        const newMember: GuildMember = {
          id: playerId,
          name: playerName,
          level: playerLevel,
          joinDate: Date.now(),
          rank: 'Leader',
          lastActiveDate: Date.now(),
          contributionPoints: 0
        };

        newGuild.members.push(newMember);

        // Add system message
        const welcomeMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `Guild "${name}" has been created! Welcome to your new guild.`,
          timestamp: Date.now(),
          isSystem: true
        };

        newGuild.messages.push(welcomeMessage);

        // Update state
        set(state => ({
          guilds: [...state.guilds, newGuild],
          playerGuildId: id,
        }));

        // Progress guild-related quests
        useQuestSystem.getState().progressQuest('guild_activity');

        return id;
      },

      // Join an existing guild
      joinGuild: (guildId) => {
        // Check if player is already in a guild
        if (get().playerGuildId) {
          return false; // Already in a guild
        }

        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }

        const { playerLevel } = useGame.getState();
        const playerId = nanoid(); // In a real app, this would be the actual player ID
        const playerName = 'Player'; // In a real app, this would be the actual player name

        // Create player as member
        const newMember: GuildMember = {
          id: playerId,
          name: playerName,
          level: playerLevel,
          joinDate: Date.now(),
          rank: 'Member',
          lastActiveDate: Date.now(),
          contributionPoints: 0
        };

        // Add system message
        const joinMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `${playerName} has joined the guild!`,
          timestamp: Date.now(),
          isSystem: true
        };

        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              return {
                ...g,
                members: [...g.members, newMember],
                messages: [...g.messages, joinMessage]
              };
            }
            return g;
          }),
          playerGuildId: guildId,
        }));

        // Progress guild-related quests
        useQuestSystem.getState().progressQuest('guild_activity');

        return true;
      },

      // Leave current guild
      leaveGuild: () => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }

        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }

        const playerRank = get().getPlayerGuildRank();
        
        // If player is the leader and there are other members, promote someone else
        if (playerRank === 'Leader' && guild.members.length > 1) {
          // Find highest ranking member that's not the player
          const membersExceptPlayer = guild.members.filter(m => m.rank !== 'Leader');
          const nextLeader = membersExceptPlayer.reduce((highest, member) => {
            const rankOrder = { Officer: 3, Veteran: 2, Member: 1 };
            const currentRank = rankOrder[member.rank as keyof typeof rankOrder] || 0;
            const highestRank = rankOrder[highest.rank as keyof typeof rankOrder] || 0;
            
            if (currentRank > highestRank) return member;
            if (currentRank === highestRank && member.contributionPoints > highest.contributionPoints) return member;
            return highest;
          }, membersExceptPlayer[0]);
          
          // Promote to leader
          nextLeader.rank = 'Leader';
        }
        
        // If player is the last member, disband the guild
        if (guild.members.length <= 1) {
          set(state => ({
            guilds: state.guilds.filter(g => g.id !== guildId),
            playerGuildId: null,
          }));
          return true;
        }
        
        // Leave the guild (remove player from members)
        const playerId = guild.members.find(m => m.rank === playerRank)?.id;
        
        if (!playerId) {
          return false; // Couldn't find player in guild
        }
        
        // Add system message
        const leaveMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `A member has left the guild.`,
          timestamp: Date.now(),
          isSystem: true
        };
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              return {
                ...g,
                members: g.members.filter(m => m.id !== playerId),
                messages: [...g.messages, leaveMessage]
              };
            }
            return g;
          }),
          playerGuildId: null,
        }));
        
        return true;
      },

      // Send invite to another player
      sendGuildInvite: (playerId, playerName) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const playerRank = get().getPlayerGuildRank();
        if (playerRank !== 'Leader' && playerRank !== 'Officer') {
          return false; // Not authorized to invite
        }
        
        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }
        
        // In a real app, we would check if the player being invited exists
        // and add the invite to their account
        
        // For now, we'll just simulate inviting another player (not implemented in demo)
        // This method could be expanded in a multiplayer implementation
        
        return true;
      },

      // Accept a guild invite
      acceptInvite: (guildId) => {
        // Find the invite
        const invite = get().pendingInvites.find(inv => inv.guildId === guildId);
        if (!invite) {
          return false; // Invite doesn't exist
        }
        
        // Join the guild
        const joined = get().joinGuild(guildId);
        
        if (joined) {
          // Remove the invite
          set(state => ({
            pendingInvites: state.pendingInvites.filter(inv => inv.guildId !== guildId)
          }));
        }
        
        return joined;
      },

      // Decline a guild invite
      declineInvite: (guildId) => {
        // Remove the invite
        set(state => ({
          pendingInvites: state.pendingInvites.filter(inv => inv.guildId !== guildId)
        }));
      },

      // Kick a member from the guild
      kickMember: (memberId) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const playerRank = get().getPlayerGuildRank();
        if (playerRank !== 'Leader' && playerRank !== 'Officer') {
          return false; // Not authorized to kick
        }
        
        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }
        
        // Find the member
        const member = guild.members.find(m => m.id === memberId);
        if (!member) {
          return false; // Member doesn't exist
        }
        
        // Check if player can kick this member
        if (playerRank === 'Officer' && (member.rank === 'Leader' || member.rank === 'Officer')) {
          return false; // Officers can't kick Leaders or other Officers
        }
        
        // Add system message
        const kickMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `${member.name} has been removed from the guild.`,
          timestamp: Date.now(),
          isSystem: true
        };
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              return {
                ...g,
                members: g.members.filter(m => m.id !== memberId),
                messages: [...g.messages, kickMessage]
              };
            }
            return g;
          })
        }));
        
        return true;
      },

      // Promote a member
      promoteMember: (memberId) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const playerRank = get().getPlayerGuildRank();
        if (playerRank !== 'Leader') {
          return false; // Only leaders can promote
        }
        
        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }
        
        // Find the member
        const memberIndex = guild.members.findIndex(m => m.id === memberId);
        if (memberIndex === -1) {
          return false; // Member doesn't exist
        }
        
        const member = guild.members[memberIndex];
        
        // Determine new rank
        let newRank: GuildRank = member.rank;
        if (member.rank === 'Member') {
          newRank = 'Veteran';
        } else if (member.rank === 'Veteran') {
          newRank = 'Officer';
        }
        
        // If rank didn't change, do nothing
        if (newRank === member.rank) {
          return false;
        }
        
        // Add system message
        const promoteMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `${member.name} has been promoted to ${newRank}.`,
          timestamp: Date.now(),
          isSystem: true
        };
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              const updatedMembers = [...g.members];
              updatedMembers[memberIndex] = { ...member, rank: newRank };
              
              return {
                ...g,
                members: updatedMembers,
                messages: [...g.messages, promoteMessage]
              };
            }
            return g;
          })
        }));
        
        return true;
      },

      // Demote a member
      demoteMember: (memberId) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const playerRank = get().getPlayerGuildRank();
        if (playerRank !== 'Leader') {
          return false; // Only leaders can demote
        }
        
        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }
        
        // Find the member
        const memberIndex = guild.members.findIndex(m => m.id === memberId);
        if (memberIndex === -1) {
          return false; // Member doesn't exist
        }
        
        const member = guild.members[memberIndex];
        
        // Can't demote Leaders through this method
        if (member.rank === 'Leader') {
          return false;
        }
        
        // Determine new rank
        let newRank: GuildRank = member.rank;
        if (member.rank === 'Officer') {
          newRank = 'Veteran';
        } else if (member.rank === 'Veteran') {
          newRank = 'Member';
        }
        
        // If rank didn't change, do nothing
        if (newRank === member.rank) {
          return false;
        }
        
        // Add system message
        const demoteMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `${member.name} has been demoted to ${newRank}.`,
          timestamp: Date.now(),
          isSystem: true
        };
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              const updatedMembers = [...g.members];
              updatedMembers[memberIndex] = { ...member, rank: newRank };
              
              return {
                ...g,
                members: updatedMembers,
                messages: [...g.messages, demoteMessage]
              };
            }
            return g;
          })
        }));
        
        return true;
      },

      // Update guild description
      updateGuildDescription: (description) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const playerRank = get().getPlayerGuildRank();
        if (playerRank !== 'Leader' && playerRank !== 'Officer') {
          return false; // Not authorized to update description
        }
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              return {
                ...g,
                description
              };
            }
            return g;
          })
        }));
        
        return true;
      },

      // Update guild emblem
      updateGuildEmblem: (emblem) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const playerRank = get().getPlayerGuildRank();
        if (playerRank !== 'Leader') {
          return false; // Only leaders can change emblem
        }
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              return {
                ...g,
                emblem
              };
            }
            return g;
          })
        }));
        
        return true;
      },

      // Send a message to the guild chat
      sendGuildMessage: (content) => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return null; // Not in a guild
        }
        
        const guild = get().getGuildById(guildId);
        if (!guild) {
          return null; // Guild doesn't exist
        }
        
        // Get player info
        const memberInfo = guild.members.find(m => m.rank === get().getPlayerGuildRank());
        if (!memberInfo) {
          return null; // Couldn't find player in guild
        }
        
        const messageId = nanoid();
        
        // Create message
        const message: GuildMessage = {
          id: messageId,
          senderId: memberInfo.id,
          senderName: memberInfo.name,
          content,
          timestamp: Date.now(),
          isSystem: false
        };
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              // Keep at most 100 messages
              const messages = [...g.messages, message];
              if (messages.length > 100) {
                messages.shift(); // Remove oldest message
              }
              
              return {
                ...g,
                messages
              };
            }
            return g;
          })
        }));
        
        // Update last active date
        get().updateMemberLastActive(memberInfo.id);
        
        // Progress guild-related quests
        useQuestSystem.getState().progressQuest('guild_activity');
        
        return messageId;
      },

      // Perform daily check-in
      dailyCheckin: () => {
        const guildId = get().playerGuildId;
        if (!guildId) {
          return false; // Not in a guild
        }
        
        const guild = get().getGuildById(guildId);
        if (!guild) {
          return false; // Guild doesn't exist
        }
        
        // Get player info
        const memberInfo = guild.members.find(m => m.rank === get().getPlayerGuildRank());
        if (!memberInfo) {
          return false; // Couldn't find player in guild
        }
        
        // Check if already checked in today
        if (guild.dailyCheckins.includes(memberInfo.id)) {
          return false; // Already checked in
        }
        
        // Add guild exp
        const expGain = 20;
        let newExp = guild.exp + expGain;
        let newLevel = guild.level;
        let newExpToNextLevel = guild.expToNextLevel;
        
        // Level up if necessary
        while (newExp >= newExpToNextLevel) {
          newExp -= newExpToNextLevel;
          newLevel++;
          newExpToNextLevel = Math.floor(newExpToNextLevel * 1.5);
          
          // Rewards for leveling up (gold for each member)
          const { addCurrency } = useCurrency.getState();
          const levelUpReward = 50 * newLevel;
          addCurrency(levelUpReward, 'gold');
        }
        
        // Add contribution points to member
        const contributionGain = 10;
        
        // Add system message for check-in
        const checkinMessage: GuildMessage = {
          id: nanoid(),
          senderId: 'system',
          senderName: 'System',
          content: `${memberInfo.name} has checked in today (+${expGain} Guild EXP)`,
          timestamp: Date.now(),
          isSystem: true
        };
        
        // Add level up message if applicable
        let levelUpMessage: GuildMessage | null = null;
        if (newLevel > guild.level) {
          levelUpMessage = {
            id: nanoid(),
            senderId: 'system',
            senderName: 'System',
            content: `The guild has reached level ${newLevel}! All members receive ${50 * newLevel} gold.`,
            timestamp: Date.now() + 1,
            isSystem: true
          };
        }
        
        // Update guild
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              const updatedMembers = g.members.map(m => {
                if (m.id === memberInfo.id) {
                  return {
                    ...m,
                    contributionPoints: m.contributionPoints + contributionGain,
                    lastActiveDate: Date.now()
                  };
                }
                return m;
              });
              
              const messages = levelUpMessage 
                ? [...g.messages, checkinMessage, levelUpMessage]
                : [...g.messages, checkinMessage];
              
              return {
                ...g,
                level: newLevel,
                exp: newExp,
                expToNextLevel: newExpToNextLevel,
                members: updatedMembers,
                dailyCheckins: [...g.dailyCheckins, memberInfo.id],
                messages
              };
            }
            return g;
          })
        }));
        
        // Progress guild-related quests
        useQuestSystem.getState().progressQuest('guild_activity');
        
        return true;
      },

      // Check if daily reset is needed and perform it
      checkDailyReset: () => {
        const now = Date.now();
        
        set(state => {
          // Update guilds that need reset
          const updatedGuilds = state.guilds.map(guild => {
            // Check if it's been more than a day since last reset
            const dayInMs = 24 * 60 * 60 * 1000;
            if (now - guild.lastDailyReset >= dayInMs) {
              return {
                ...guild,
                dailyCheckins: [],
                lastDailyReset: now
              };
            }
            return guild;
          });
          
          return {
            guilds: updatedGuilds
          };
        });
      },

      // Update a member's last active date (used internally)
      updateMemberLastActive: (memberId) => {
        const guildId = get().playerGuildId;
        if (!guildId) return;
        
        set(state => ({
          guilds: state.guilds.map(g => {
            if (g.id === guildId) {
              const updatedMembers = g.members.map(m => {
                if (m.id === memberId) {
                  return {
                    ...m,
                    lastActiveDate: Date.now()
                  };
                }
                return m;
              });
              
              return {
                ...g,
                members: updatedMembers
              };
            }
            return g;
          })
        }));
      },

      // Utility functions
      getPlayerGuild: () => {
        const guildId = get().playerGuildId;
        if (!guildId) return null;
        
        return get().getGuildById(guildId);
      },

      getGuildByName: (name) => {
        return get().guilds.find(g => g.name.toLowerCase() === name.toLowerCase()) || null;
      },

      getGuildById: (id) => {
        return get().guilds.find(g => g.id === id) || null;
      },

      getPlayerGuildRank: () => {
        const guild = get().getPlayerGuild();
        if (!guild) return null;
        
        // In a real implementation, this would look up the player's actual ID
        // For demo purposes, we'll assume the player is the first member matching Leader, Officer, etc.
        const rankOrder = ['Leader', 'Officer', 'Veteran', 'Member'];
        
        for (const rank of rankOrder) {
          const member = guild.members.find(m => m.rank === rank);
          if (member) {
            return rank as GuildRank;
          }
        }
        
        return null;
      },

      canManageGuild: () => {
        const rank = get().getPlayerGuildRank();
        return rank === 'Leader' || rank === 'Officer';
      },

      getGuildMembers: () => {
        const guild = get().getPlayerGuild();
        if (!guild) return [];
        
        // Sort by rank and then contribution
        return [...guild.members].sort((a, b) => {
          const rankOrder = { Leader: 4, Officer: 3, Veteran: 2, Member: 1 };
          const aRank = rankOrder[a.rank as keyof typeof rankOrder] || 0;
          const bRank = rankOrder[b.rank as keyof typeof rankOrder] || 0;
          
          if (aRank !== bRank) return bRank - aRank;
          return b.contributionPoints - a.contributionPoints;
        });
      },

      getGuildMessages: () => {
        const guild = get().getPlayerGuild();
        if (!guild) return [];
        
        return guild.messages;
      },

      getRecentMessages: (count = 20) => {
        const messages = get().getGuildMessages();
        return messages.slice(-count).sort((a, b) => a.timestamp - b.timestamp);
      },

      hasCheckedInToday: () => {
        const guild = get().getPlayerGuild();
        if (!guild) return false;
        
        // Get player info
        const memberInfo = guild.members.find(m => m.rank === get().getPlayerGuildRank());
        if (!memberInfo) return false;
        
        return guild.dailyCheckins.includes(memberInfo.id);
      },

      getDailyCheckinCount: () => {
        const guild = get().getPlayerGuild();
        if (!guild) return 0;
        
        return guild.dailyCheckins.length;
      }
    }),
    {
      name: 'maltesar-guild-system',
      // On rehydration (loading from storage)
      onRehydrateStorage: (state) => {
        return (rehydratedState, error) => {
          if (error || !rehydratedState) {
            console.error('Failed to rehydrate guild system store:', error);
            return;
          }
          
          // Check if daily reset is needed
          rehydratedState.checkDailyReset();
          
          // If there are no sample guilds, create some
          if (rehydratedState.guilds.length === 0) {
            setTimeout(() => {
              if (rehydratedState.guilds.length === 0) {
                // Create a sample guilds
                createSampleGuilds(rehydratedState);
              }
            }, 100);
          }
        };
      },
    }
  )
);

// Helper function to create sample guilds
const createSampleGuilds = (state: GuildSystemState) => {
  // Create sample guild 1
  const guild1: Guild = {
    id: nanoid(),
    name: 'Knights of Valor',
    description: 'A prestigious guild dedicated to honor and excellence in battle!',
    emblem: 'sword',
    level: 5,
    exp: 250,
    expToNextLevel: 1000,
    creationDate: Date.now() - 60 * 24 * 60 * 60 * 1000, // 60 days ago
    members: [
      {
        id: nanoid(),
        name: 'Sir Galahad',
        level: 25,
        joinDate: Date.now() - 60 * 24 * 60 * 60 * 1000,
        rank: 'Leader',
        lastActiveDate: Date.now() - 1 * 24 * 60 * 60 * 1000,
        contributionPoints: 2500
      },
      {
        id: nanoid(),
        name: 'Lady Morgana',
        level: 22,
        joinDate: Date.now() - 58 * 24 * 60 * 60 * 1000,
        rank: 'Officer',
        lastActiveDate: Date.now() - 2 * 24 * 60 * 60 * 1000,
        contributionPoints: 2200
      },
      {
        id: nanoid(),
        name: 'Sir Lancelot',
        level: 20,
        joinDate: Date.now() - 45 * 24 * 60 * 60 * 1000,
        rank: 'Veteran',
        lastActiveDate: Date.now() - 5 * 24 * 60 * 60 * 1000,
        contributionPoints: 1800
      },
      {
        id: nanoid(),
        name: 'Squire Timothy',
        level: 15,
        joinDate: Date.now() - 10 * 24 * 60 * 60 * 1000,
        rank: 'Member',
        lastActiveDate: Date.now() - 3 * 24 * 60 * 60 * 1000,
        contributionPoints: 500
      }
    ],
    messages: [
      {
        id: nanoid(),
        senderId: 'system',
        senderName: 'System',
        content: 'Guild "Knights of Valor" has been created!',
        timestamp: Date.now() - 60 * 24 * 60 * 60 * 1000,
        isSystem: true
      }
    ],
    dailyCheckins: [],
    lastDailyReset: Date.now()
  };

  // Create sample guild 2
  const guild2: Guild = {
    id: nanoid(),
    name: 'Mystic Mages',
    description: 'For those who seek power through arcane knowledge and magical studies.',
    emblem: 'phoenix',
    level: 3,
    exp: 150,
    expToNextLevel: 800,
    creationDate: Date.now() - 30 * 24 * 60 * 60 * 1000, // 30 days ago
    members: [
      {
        id: nanoid(),
        name: 'Archmagus Zephyr',
        level: 18,
        joinDate: Date.now() - 30 * 24 * 60 * 60 * 1000,
        rank: 'Leader',
        lastActiveDate: Date.now() - 2 * 24 * 60 * 60 * 1000,
        contributionPoints: 1500
      },
      {
        id: nanoid(),
        name: 'Enchantress Lyra',
        level: 16,
        joinDate: Date.now() - 28 * 24 * 60 * 60 * 1000,
        rank: 'Officer',
        lastActiveDate: Date.now() - 1 * 24 * 60 * 60 * 1000,
        contributionPoints: 1200
      },
      {
        id: nanoid(),
        name: 'Conjurer Thorn',
        level: 14,
        joinDate: Date.now() - 20 * 24 * 60 * 60 * 1000,
        rank: 'Member',
        lastActiveDate: Date.now() - 4 * 24 * 60 * 60 * 1000,
        contributionPoints: 800
      }
    ],
    messages: [
      {
        id: nanoid(),
        senderId: 'system',
        senderName: 'System',
        content: 'Guild "Mystic Mages" has been created!',
        timestamp: Date.now() - 30 * 24 * 60 * 60 * 1000,
        isSystem: true
      }
    ],
    dailyCheckins: [],
    lastDailyReset: Date.now()
  };

  // Add to state
  state.guilds.push(guild1);
  state.guilds.push(guild2);
};