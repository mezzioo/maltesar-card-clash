import { create } from "zustand";
import { persist } from "zustand/middleware";
import { storyChapters, StoryChapter, DialogueLine } from "../../data/story";
import { useGameState } from "./useGameState";
import { useCurrency } from "./useCurrency";
import { useCardCollection } from "./useCardCollection";

export type StoryState = {
  // Story progress
  currentChapterId: string | null;
  currentLineIndex: number;
  completedChapters: string[];
  
  // Choices
  choiceHistory: { [chapterId: string]: number[] }; // Maps chapterID to choice indices
  
  // Actions
  startChapter: (chapterId: string) => void;
  nextLine: () => DialogueLine | null;
  makeChoice: (choiceIndex: number) => void;
  completeChapter: () => void;
  
  // Utility functions
  getCurrentChapter: () => StoryChapter | null;
  getCurrentLine: () => DialogueLine | null;
  isChapterCompleted: (chapterId: string) => boolean;
  getAvailableChapters: () => StoryChapter[];
  resetStoryProgress: () => void;
};

export const useStoryMode = create<StoryState>()(
  persist(
    (set, get) => ({
      // Initial state
      currentChapterId: null,
      currentLineIndex: 0,
      completedChapters: [],
      choiceHistory: {},
      
      // Start a story chapter
      startChapter: (chapterId: string) => {
        const chapter = storyChapters.find(c => c.id === chapterId);
        if (!chapter) return;
        
        set({
          currentChapterId: chapterId,
          currentLineIndex: 0
        });
      },
      
      // Advance to the next dialogue line
      nextLine: () => {
        const { currentChapterId, currentLineIndex } = get();
        const chapter = storyChapters.find(c => c.id === currentChapterId);
        
        if (!chapter) return null;
        
        const lines = chapter.dialogue;
        
        // Check if there are more lines
        if (currentLineIndex < lines.length - 1) {
          // Move to next line
          set({ currentLineIndex: currentLineIndex + 1 });
          return lines[currentLineIndex + 1];
        } else {
          // Chapter is complete
          get().completeChapter();
          return null;
        }
      },
      
      // Make a choice in a dialogue
      makeChoice: (choiceIndex: number) => {
        const { currentChapterId, choiceHistory } = get();
        
        if (!currentChapterId) return;
        
        // Record the choice
        const chapterChoices = choiceHistory[currentChapterId] || [];
        
        set({
          choiceHistory: {
            ...choiceHistory,
            [currentChapterId]: [...chapterChoices, choiceIndex]
          }
        });
        
        // Get the current line
        const currentLine = get().getCurrentLine();
        
        if (!currentLine || !currentLine.choices) return;
        
        // Process choice effects if any
        const choice = currentLine.choices[choiceIndex];
        
        if (choice.effect) {
          // Apply effects
          switch (choice.effect.type) {
            case "currency":
              const { addCurrency } = useCurrency.getState();
              addCurrency(choice.effect.value || 0);
              break;
              
            case "exp":
              const { gainExp } = useGameState.getState();
              gainExp(choice.effect.value || 0);
              break;
              
            case "continue":
              // Just continue to the next line (handled after this switch)
              break;
              
            case "cards":
              // Immediately add the cards to the player's collection
              const cardCount = choice.effect.value || 0;
              if (cardCount > 0) {
                const chapter = get().getCurrentChapter();
                if (chapter && chapter.reward && chapter.reward.cards) {
                  // Get the card names for display
                  const cards = chapter.reward.cards.slice(0, cardCount);
                  const cardNames = cards
                    .map(cardId => cardId.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '))
                    .join(' and ');
                  
                  // Add each card to the collection immediately
                  const { addCard } = useCardCollection.getState();
                  cards.forEach(cardId => {
                    addCard(cardId);
                    console.log(`Card added to collection: ${cardId}`);
                  });
                  
                  console.log(`You received ${cardCount} cards: ${cardNames}`);
                  
                  // Show a notification if window is available
                  if (typeof window !== 'undefined') {
                    // This is a browser-side notification
                    console.log(`CARDS ADDED: ${cardNames}`);
                  }
                }
              }
              break;
              
            // Add more effect types as needed
          }
        }
        
        // Advance to next line
        get().nextLine();
      },
      
      // Complete the current chapter
      completeChapter: () => {
        const { currentChapterId, completedChapters } = get();
        
        if (!currentChapterId) return;
        
        // Add to completed if not already there
        if (!completedChapters.includes(currentChapterId)) {
          set({
            completedChapters: [...completedChapters, currentChapterId]
          });
          
          // Update story progress in game state
          const { completeStoryChapter } = useGameState.getState();
          completeStoryChapter(parseInt(currentChapterId.replace('chapter-', ''), 10));
          
          // Get chapter rewards if any
          const chapter = storyChapters.find(c => c.id === currentChapterId);
          
          if (chapter && chapter.reward) {
            // Currency reward
            if (chapter.reward.currency) {
              const { addCurrency } = useCurrency.getState();
              addCurrency(chapter.reward.currency);
              console.log(`Reward: ${chapter.reward.currency} gold added`);
            }
            
            // EXP reward
            if (chapter.reward.exp) {
              const { gainExp } = useGameState.getState();
              gainExp(chapter.reward.exp);
              console.log(`Reward: ${chapter.reward.exp} experience points added`);
            }
            
            // Card rewards
            if (chapter.reward.cards && chapter.reward.cards.length > 0) {
              const { addCard } = useCardCollection.getState();
              
              // Add each card to the collection
              chapter.reward.cards.forEach(cardId => {
                addCard(cardId);
                console.log(`Reward: Card "${cardId}" added to collection`);
              });
              
              // Add a toast notification about the cards
              if (typeof window !== 'undefined') {
                // This should be done in the component, but we'll use window.setTimeout as a fallback
                setTimeout(() => {
                  console.log(`You received ${chapter.reward?.cards?.length || 0} new cards!`);
                }, 100);
              }
            }
            
            // Unlock character if any
            if (chapter.reward.unlockCharacter) {
              const { unlockCharacter } = useGameState.getState();
              unlockCharacter(chapter.reward.unlockCharacter);
              console.log(`Reward: Character "${chapter.reward.unlockCharacter}" unlocked`);
            }
          }
        }
        
        // Reset current chapter
        set({
          currentChapterId: null,
          currentLineIndex: 0
        });
      },
      
      // Get current chapter
      getCurrentChapter: () => {
        const { currentChapterId } = get();
        return storyChapters.find(c => c.id === currentChapterId) || null;
      },
      
      // Get current dialogue line
      getCurrentLine: () => {
        const chapter = get().getCurrentChapter();
        const { currentLineIndex } = get();
        
        if (!chapter) return null;
        
        return chapter.dialogue[currentLineIndex] || null;
      },
      
      // Check if chapter is completed
      isChapterCompleted: (chapterId: string) => {
        return get().completedChapters.includes(chapterId);
      },
      
      // Get available chapters based on game progress
      getAvailableChapters: () => {
        const { storyProgress } = useGameState.getState();
        
        return storyChapters.filter(chapter => {
          const chapterNumber = parseInt(chapter.id.replace('chapter-', ''), 10);
          return chapterNumber <= storyProgress + 1;
        });
      },
      
      // Reset all story progress (for debugging)
      resetStoryProgress: () => {
        set({
          currentChapterId: null,
          currentLineIndex: 0,
          completedChapters: [],
          choiceHistory: {}
        });
      }
    }),
    {
      name: "maltesar-story-state"
    }
  )
);
