import { create } from "zustand";
import { persist } from "zustand/middleware";
import { dungeons, Dungeon, DungeonStage, DungeonEvent } from "../../data/dungeons";
import { Enemy } from "../../data/enemies";
import { useGameState } from "./useGameState";
import { useCurrency } from "./useCurrency";

export type DungeonState = {
  // Current dungeon progress
  currentDungeonId: string | null;
  currentStageIndex: number;
  stageProgress: number; // Tracks progress within a stage (for multi-battle stages)
  dungeonHistory: string[]; // IDs of completed dungeons
  
  // Current event
  currentEvent: DungeonEvent | null;
  
  // Player state in dungeon
  playerHealth: number;
  maxPlayerHealth: number;
  
  // Actions
  enterDungeon: (dungeonId: string) => void;
  exitDungeon: () => void;
  advanceStage: () => void;
  completeDungeon: () => void;
  processBattleVictory: (enemiesDefeated: Enemy[]) => void;
  takeDamage: (amount: number) => void;
  healPlayer: (amount: number) => void;
  setMaxHealth: (amount: number) => void;
  
  // Utility functions
  getCurrentDungeon: () => Dungeon | null;
  getCurrentStage: () => DungeonStage | null;
  getNextEvent: () => DungeonEvent | null;
  getProgress: () => number; // Percentage of current dungeon completed
  isDungeonCompleted: (dungeonId: string) => boolean;
};

export const useDungeon = create<DungeonState>()(
  persist(
    (set, get) => ({
      // Initial state
      currentDungeonId: null,
      currentStageIndex: 0,
      stageProgress: 0,
      dungeonHistory: [],
      
      currentEvent: null,
      
      playerHealth: 100,
      maxPlayerHealth: 100,
      
      // Enter a dungeon
      enterDungeon: (dungeonId: string) => {
        const dungeon = dungeons.find(d => d.id === dungeonId);
        if (!dungeon) return;
        
        set({
          currentDungeonId: dungeonId,
          currentStageIndex: 0,
          stageProgress: 0,
          playerHealth: 100,
          maxPlayerHealth: 100,
          currentEvent: null
        });
        
        // Set first event
        get().getNextEvent();
      },
      
      // Exit the current dungeon
      exitDungeon: () => {
        set({
          currentDungeonId: null,
          currentStageIndex: 0,
          stageProgress: 0,
          currentEvent: null
        });
      },
      
      // Advance to the next stage
      advanceStage: () => {
        const { currentDungeonId, currentStageIndex } = get();
        const dungeon = dungeons.find(d => d.id === currentDungeonId);
        
        if (!dungeon) return;
        
        // Check if there are more stages
        if (currentStageIndex < dungeon.stages.length - 1) {
          set({
            currentStageIndex: currentStageIndex + 1,
            stageProgress: 0,
            currentEvent: null
          });
          
          // Set next event
          get().getNextEvent();
        } else {
          // Dungeon is complete
          get().completeDungeon();
        }
      },
      
      // Complete the current dungeon
      completeDungeon: () => {
        const { currentDungeonId, dungeonHistory } = get();
        
        if (!currentDungeonId) return;
        
        // Add to history if not already there
        if (!dungeonHistory.includes(currentDungeonId)) {
          set({
            dungeonHistory: [...dungeonHistory, currentDungeonId]
          });
        }
        
        // Get dungeon rewards
        const dungeon = dungeons.find(d => d.id === currentDungeonId);
        if (dungeon) {
          // Add currency reward
          const { addCurrency } = useCurrency.getState();
          addCurrency(dungeon.reward.currency || 0);
          
          // Mark dungeon progress
          const { completeDungeon } = useGameState.getState();
          completeDungeon(parseInt(dungeon.id.replace('dungeon-', ''), 10));
        }
        
        // Exit dungeon
        set({
          currentDungeonId: null,
          currentStageIndex: 0,
          stageProgress: 0,
          currentEvent: null
        });
      },
      
      // Process battle victory
      processBattleVictory: (enemiesDefeated: Enemy[]) => {
        const { currentStageIndex, stageProgress } = get();
        const currentStage = get().getCurrentStage();
        
        if (!currentStage) return;
        
        // Calculate rewards
        const expReward = enemiesDefeated.reduce((sum, enemy) => sum + enemy.expReward, 0);
        const currencyReward = enemiesDefeated.reduce((sum, enemy) => sum + enemy.currencyReward, 0);
        
        // Apply rewards
        const { gainExp } = useGameState.getState();
        const { addCurrency } = useCurrency.getState();
        
        gainExp(expReward);
        addCurrency(currencyReward);
        
        // Check if stage is complete
        const battleEvents = currentStage.events.filter(e => e.type === "battle");
        
        if (stageProgress >= battleEvents.length - 1) {
          // Stage complete, move to next stage
          get().advanceStage();
        } else {
          // Increment stage progress
          set({
            stageProgress: stageProgress + 1,
            currentEvent: null
          });
          
          // Set next event
          get().getNextEvent();
        }
      },
      
      // Take damage
      takeDamage: (amount: number) => {
        set(state => ({
          playerHealth: Math.max(0, state.playerHealth - amount)
        }));
        
        // Check if player is defeated
        if (get().playerHealth <= 0) {
          get().exitDungeon();
        }
      },
      
      // Heal player
      healPlayer: (amount: number) => {
        set(state => ({
          playerHealth: Math.min(state.maxPlayerHealth, state.playerHealth + amount)
        }));
      },
      
      // Set max health
      setMaxHealth: (amount: number) => {
        set({
          maxPlayerHealth: amount,
          playerHealth: Math.min(get().playerHealth, amount)
        });
      },
      
      // Get current dungeon
      getCurrentDungeon: () => {
        const { currentDungeonId } = get();
        return dungeons.find(d => d.id === currentDungeonId) || null;
      },
      
      // Get current stage
      getCurrentStage: () => {
        const dungeon = get().getCurrentDungeon();
        const { currentStageIndex } = get();
        
        if (!dungeon) return null;
        
        return dungeon.stages[currentStageIndex] || null;
      },
      
      // Get next event
      getNextEvent: () => {
        const currentStage = get().getCurrentStage();
        const { stageProgress } = get();
        
        if (!currentStage) return null;
        
        // Find next event
        const battleEvents = currentStage.events.filter(e => e.type === "battle");
        let nextEvent = null;
        
        if (stageProgress < battleEvents.length) {
          nextEvent = battleEvents[stageProgress];
        } else {
          // No more battle events, check for story events
          const storyEvents = currentStage.events.filter(e => e.type === "story");
          if (storyEvents.length > 0) {
            nextEvent = storyEvents[0];
          }
        }
        
        // Set current event
        set({ currentEvent: nextEvent });
        
        return nextEvent;
      },
      
      // Get dungeon progress as percentage
      getProgress: () => {
        const dungeon = get().getCurrentDungeon();
        const { currentStageIndex, stageProgress } = get();
        
        if (!dungeon) return 0;
        
        const totalStages = dungeon.stages.length;
        const currentStage = dungeon.stages[currentStageIndex];
        
        if (!currentStage) return 0;
        
        const totalBattlesInStage = currentStage.events.filter(e => e.type === "battle").length;
        const currentProgress = (currentStageIndex / totalStages) + (stageProgress / totalBattlesInStage / totalStages);
        
        return Math.min(1, Math.max(0, currentProgress)) * 100;
      },
      
      // Check if dungeon is completed
      isDungeonCompleted: (dungeonId: string) => {
        return get().dungeonHistory.includes(dungeonId);
      }
    }),
    {
      name: "maltesar-dungeon-state"
    }
  )
);
