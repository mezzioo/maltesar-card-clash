import { create } from "zustand";
import { Enemy } from "../../data/enemies";
import { CardType, CardEffect } from "../../data/cards";
import { Character } from "../../data/characters";
import { useCardCollection } from "./useCardCollection";
import { useGameState } from "./useGameState";
import { useAudio } from "./useAudio";

export type BattlePhase = 
  | "setup" 
  | "playerTurn" 
  | "enemyTurn" 
  | "victory" 
  | "defeat";

export type BattleParticipant = {
  id: string;
  name: string;
  maxHp: number;
  currentHp: number;
  attack: number;
  defense: number;
  speed: number;
  isEnemy: boolean;
  buffs: CardEffect[];
  debuffs: CardEffect[];
};

type BattleState = {
  // Battle setup
  phase: BattlePhase;
  player: BattleParticipant | null;
  enemies: BattleParticipant[];
  currentRound: number;
  
  // Player hand
  deck: CardType[]; // Cards in player's deck
  hand: CardType[]; // Cards in player's hand
  discardPile: CardType[]; // Cards that have been played
  
  // Combat
  selectedCard: CardType | null;
  selectedTarget: BattleParticipant | null;
  
  // Turn management
  playerMana: number;
  maxPlayerMana: number;
  
  // State management
  initializeBattle: (playerCharacter: Character, enemies: Enemy[]) => void;
  drawCards: (count: number) => void;
  playCard: (cardIndex: number, targetId: string) => void;
  selectCard: (card: CardType | null) => void;
  selectTarget: (target: BattleParticipant | null) => void;
  endPlayerTurn: () => void;
  processEnemyTurn: () => void;
  checkBattleEnd: () => void;
  resetBattle: () => void;
  applyCardEffect: (card: CardType, source: BattleParticipant, target: BattleParticipant) => void;
  damageTarget: (target: BattleParticipant, amount: number) => void;
  healTarget: (target: BattleParticipant, amount: number) => void;
  addBuff: (target: BattleParticipant, effect: CardEffect) => void;
  addDebuff: (target: BattleParticipant, effect: CardEffect) => void;
  processTurnEffects: (participant: BattleParticipant) => BattleParticipant;
};

export const useBattleSystem = create<BattleState>((set, get) => {
  // Helper function to generate a participant from a character
  const createParticipantFromCharacter = (character: Character): BattleParticipant => ({
    id: character.id,
    name: character.name,
    maxHp: character.baseHP,
    currentHp: character.baseHP,
    attack: character.baseAttack,
    defense: character.baseDefense,
    speed: character.baseSpeed,
    isEnemy: false,
    buffs: [],
    debuffs: []
  });
  
  // Helper function to generate a participant from an enemy
  const createParticipantFromEnemy = (enemy: Enemy): BattleParticipant => ({
    id: enemy.id,
    name: enemy.name,
    maxHp: enemy.hp,
    currentHp: enemy.hp,
    attack: enemy.attack,
    defense: enemy.defense,
    speed: enemy.speed,
    isEnemy: true,
    buffs: [],
    debuffs: []
  });
  
  return {
    // Initial state
    phase: "setup",
    player: null,
    enemies: [],
    currentRound: 1,
    
    deck: [],
    hand: [],
    discardPile: [],
    
    selectedCard: null,
    selectedTarget: null,
    
    playerMana: 3, // Start with 3 mana
    maxPlayerMana: 3,
    
    // Initialize battle with player character and enemies
    initializeBattle: (playerCharacter, battleEnemies) => {
      // Convert character to battle participant
      const playerParticipant = createParticipantFromCharacter(playerCharacter);
      
      // Convert enemies to battle participants
      const enemyParticipants = battleEnemies.map(createParticipantFromEnemy);
      
      // Get player's active deck
      const { getActiveCards, getCardDetails } = useCardCollection.getState();
      const activeCards = getActiveCards();
      const deckCards = activeCards
        .map(playerCard => getCardDetails(playerCard.id))
        .filter((card): card is CardType => card !== undefined);
      
      // Shuffle the deck
      const shuffledDeck = [...deckCards].sort(() => Math.random() - 0.5);
      
      set({
        phase: "playerTurn",
        player: playerParticipant,
        enemies: enemyParticipants,
        currentRound: 1,
        deck: shuffledDeck,
        hand: [],
        discardPile: [],
        playerMana: 3,
        maxPlayerMana: 3
      });
      
      // Draw initial hand
      get().drawCards(5);
    },
    
    // Draw cards from deck to hand
    drawCards: (count) => {
      const { deck, hand, discardPile } = get();
      
      // If deck is empty, shuffle discard pile back
      let currentDeck = [...deck];
      if (currentDeck.length < count && discardPile.length > 0) {
        const shuffledDiscard = [...discardPile].sort(() => Math.random() - 0.5);
        currentDeck = [...currentDeck, ...shuffledDiscard];
        set({ discardPile: [] });
      }
      
      // Draw cards
      const newHand = [...hand];
      const drawnCards = currentDeck.slice(0, count);
      newHand.push(...drawnCards);
      
      // Update state
      set({
        deck: currentDeck.slice(count),
        hand: newHand
      });
      
      return drawnCards;
    },
    
    // Play a card from hand on a target
    playCard: (cardIndex, targetId) => {
      const { hand, player, enemies, playerMana } = get();
      const card = hand[cardIndex];
      
      // Check if valid card and enough mana
      if (!card || playerMana < card.manaCost) {
        return false;
      }
      
      // Find the target
      let target;
      if (targetId === player?.id) {
        target = player;
      } else {
        target = enemies.find(enemy => enemy.id === targetId);
      }
      
      if (!target) {
        return false;
      }
      
      // Apply card effect
      if (player) {
        get().applyCardEffect(card, player, target);
        
        // Move card to discard pile
        const newHand = [...hand];
        const playedCard = newHand.splice(cardIndex, 1)[0];
        
        // Play the hit sound
        const { playHit } = useAudio.getState();
        playHit();
        
        // Update state
        set(state => ({
          hand: newHand,
          discardPile: [...state.discardPile, playedCard],
          playerMana: state.playerMana - card.manaCost,
          selectedCard: null,
          selectedTarget: null
        }));
        
        // Check if battle is over
        get().checkBattleEnd();
        
        return true;
      }
      
      return false;
    },
    
    // Select a card to play
    selectCard: (card) => {
      set({ selectedCard: card });
    },
    
    // Select a target for the card
    selectTarget: (target) => {
      set({ selectedTarget: target });
    },
    
    // End player's turn
    endPlayerTurn: () => {
      // Process any end-of-turn effects for the player
      const { player } = get();
      if (player) {
        const updatedPlayer = get().processTurnEffects(player);
        set({ player: updatedPlayer });
      }
      
      set({ phase: "enemyTurn" });
      
      // Process enemy turn
      get().processEnemyTurn();
    },
    
    // Process enemy turn
    processEnemyTurn: () => {
      const { enemies, player } = get();
      
      if (!player) return;
      
      // Process each enemy's turn
      const updatedEnemies = enemies.map(enemy => {
        // Skip dead enemies
        if (enemy.currentHp <= 0) return enemy;
        
        // Process buffs/debuffs
        const updatedEnemy = get().processTurnEffects(enemy);
        
        // Basic enemy AI - attack player
        if (player.currentHp > 0) {
          const damage = Math.max(1, updatedEnemy.attack - player.defense);
          get().damageTarget(player, damage);
        }
        
        return updatedEnemy;
      });
      
      set({ enemies: updatedEnemies });
      
      // Check if battle is over
      get().checkBattleEnd();
      
      // If battle isn't over, start player's turn
      if (get().phase !== "victory" && get().phase !== "defeat") {
        // Increment round counter
        const newRound = get().currentRound + 1;
        
        // Restore some mana for the next turn
        const newMana = Math.min(
          get().maxPlayerMana,
          get().playerMana + 2
        );
        
        set({
          phase: "playerTurn",
          currentRound: newRound,
          playerMana: newMana
        });
        
        // Draw cards for new turn
        get().drawCards(1);
      }
    },
    
    // Check if battle is over
    checkBattleEnd: () => {
      const { player, enemies } = get();
      
      // Player is defeated
      if (player && player.currentHp <= 0) {
        set({ phase: "defeat" });
        return;
      }
      
      // All enemies are defeated
      if (enemies.every(enemy => enemy.currentHp <= 0)) {
        set({ phase: "victory" });
        
        // Award EXP and currency
        const { gainExp } = useGameState.getState();
        const totalExp = enemies.reduce((total, enemy) => total + (enemy.maxHp / 2), 0);
        gainExp(Math.floor(totalExp));
        
        // Play victory sound
        const { playSuccess } = useAudio.getState();
        playSuccess();
        
        return;
      }
    },
    
    // Reset battle state
    resetBattle: () => {
      set({
        phase: "setup",
        player: null,
        enemies: [],
        currentRound: 1,
        deck: [],
        hand: [],
        discardPile: [],
        selectedCard: null,
        selectedTarget: null,
        playerMana: 3,
        maxPlayerMana: 3
      });
    },
    
    // Apply a card's effect to a target
    applyCardEffect: (card, source, target) => {
      switch (card.type) {
        case "attack":
          // Calculate damage
          const baseDamage = card.value + source.attack;
          const actualDamage = Math.max(1, baseDamage - target.defense);
          get().damageTarget(target, actualDamage);
          break;
          
        case "defense":
          // Add defense buff
          get().addBuff(target, {
            type: "defense",
            value: card.value,
            duration: 2
          });
          break;
          
        case "heal":
          // Calculate healing
          const healAmount = card.value;
          get().healTarget(target, healAmount);
          break;
          
        case "buff":
          // Add buff effect
          if (card.effect) {
            get().addBuff(target, card.effect);
          }
          break;
          
        case "debuff":
          // Add debuff effect
          if (card.effect) {
            get().addDebuff(target, card.effect);
          }
          break;
      }
      
      // Apply any additional effects
      if (card.additionalEffects) {
        card.additionalEffects.forEach(effect => {
          switch (effect.type) {
            case "draw":
              get().drawCards(effect.value || 1);
              break;
              
            case "mana":
              set(state => ({
                playerMana: Math.min(
                  state.maxPlayerMana,
                  state.playerMana + (effect.value || 0)
                )
              }));
              break;
              
            // Add more effect types as needed
          }
        });
      }
    },
    
    // Damage a target
    damageTarget: (target, amount) => {
      const newHp = Math.max(0, target.currentHp - amount);
      
      if (target.isEnemy) {
        // Update enemy HP
        set(state => ({
          enemies: state.enemies.map(enemy =>
            enemy.id === target.id
              ? { ...enemy, currentHp: newHp }
              : enemy
          )
        }));
      } else {
        // Update player HP
        set(state => ({
          player: state.player
            ? { ...state.player, currentHp: newHp }
            : null
        }));
      }
    },
    
    // Heal a target
    healTarget: (target, amount) => {
      const newHp = Math.min(target.maxHp, target.currentHp + amount);
      
      if (target.isEnemy) {
        // Update enemy HP
        set(state => ({
          enemies: state.enemies.map(enemy =>
            enemy.id === target.id
              ? { ...enemy, currentHp: newHp }
              : enemy
          )
        }));
      } else {
        // Update player HP
        set(state => ({
          player: state.player
            ? { ...state.player, currentHp: newHp }
            : null
        }));
      }
    },
    
    // Add a buff to a target
    addBuff: (target, effect) => {
      const updatedBuffs = [...target.buffs, { ...effect }];
      
      if (target.isEnemy) {
        // Update enemy buffs
        set(state => ({
          enemies: state.enemies.map(enemy =>
            enemy.id === target.id
              ? { ...enemy, buffs: updatedBuffs }
              : enemy
          )
        }));
      } else {
        // Update player buffs
        set(state => ({
          player: state.player
            ? { ...state.player, buffs: updatedBuffs }
            : null
        }));
      }
    },
    
    // Add a debuff to a target
    addDebuff: (target, effect) => {
      const updatedDebuffs = [...target.debuffs, { ...effect }];
      
      if (target.isEnemy) {
        // Update enemy debuffs
        set(state => ({
          enemies: state.enemies.map(enemy =>
            enemy.id === target.id
              ? { ...enemy, debuffs: updatedDebuffs }
              : enemy
          )
        }));
      } else {
        // Update player debuffs
        set(state => ({
          player: state.player
            ? { ...state.player, debuffs: updatedDebuffs }
            : null
        }));
      }
    },
    
    // Process turn effects (reducing duration, applying effects)
    processTurnEffects: (participant) => {
      // Temporary copy of the participant
      let updatedParticipant = { ...participant };
      
      // Process buffs
      const updatedBuffs = updatedParticipant.buffs
        .map(buff => {
          // Apply buff effect
          switch (buff.type) {
            case "attack":
              updatedParticipant.attack += buff.value || 0;
              break;
            case "defense":
              updatedParticipant.defense += buff.value || 0;
              break;
            // Add more buff types as needed
          }
          
          // Reduce duration
          return {
            ...buff,
            duration: (buff.duration || 1) - 1
          };
        })
        .filter(buff => (buff.duration || 0) > 0); // Remove expired buffs
      
      // Process debuffs
      const updatedDebuffs = updatedParticipant.debuffs
        .map(debuff => {
          // Apply debuff effect
          switch (debuff.type) {
            case "attack":
              updatedParticipant.attack = Math.max(0, updatedParticipant.attack - (debuff.value || 0));
              break;
            case "defense":
              updatedParticipant.defense = Math.max(0, updatedParticipant.defense - (debuff.value || 0));
              break;
            case "poison":
              const damage = debuff.value || 1;
              updatedParticipant.currentHp = Math.max(0, updatedParticipant.currentHp - damage);
              break;
            // Add more debuff types as needed
          }
          
          // Reduce duration
          return {
            ...debuff,
            duration: (debuff.duration || 1) - 1
          };
        })
        .filter(debuff => (debuff.duration || 0) > 0); // Remove expired debuffs
      
      // Update the participant
      updatedParticipant.buffs = updatedBuffs;
      updatedParticipant.debuffs = updatedDebuffs;
      
      return updatedParticipant;
    }
  };
});
