import { create } from "zustand";
import { Howl } from "howler";

type SoundType = 
  | "hit" 
  | "success" 
  | "battle" 
  | "cardFlip" 
  | "victory" 
  | "gachaPull" 
  | "combo" 
  | "error" 
  | "notification" 
  | "quest" 
  | "levelUp"
  | "unlock";

interface AudioState {
  sounds: Record<SoundType | string, Howl | null>;
  backgroundMusic: Howl | null;
  battleMusic: Howl | null;
  isMuted: boolean;
  
  // Setter functions
  setBackgroundMusic: (music: Howl) => void;
  setBattleMusic: (music: Howl) => void;
  setSound: (type: SoundType | string, sound: Howl) => void;
  
  // Legacy setters (for compatibility)
  setHitSound: (sound: Howl) => void;
  setSuccessSound: (sound: Howl) => void;
  setBattleSound: (sound: Howl) => void;
  setCardFlipSound: (sound: Howl) => void;
  setVictorySound: (sound: Howl) => void;
  setGachaPullSound: (sound: Howl) => void;
  
  // Control functions
  toggleMute: () => void;
  playBackgroundMusic: () => void;
  stopBackgroundMusic: () => void;
  playBattleMusic: () => void;
  stopBattleMusic: () => void;
  playSound: (type: SoundType | string) => void;
  
  // Convenience methods for common sounds
  playHit: () => void;
  playSuccess: () => void;
  playCardFlip: () => void;
  playVictory: () => void;
  playGachaPull: () => void;
  playCombo: () => void;
  playError: () => void;
  playNotification: () => void;
  playQuestComplete: () => void;
  playLevelUp: () => void;
  playUnlock: () => void;
}

export const useAudio = create<AudioState>((set, get) => ({
  // Initialize sound storage
  sounds: {},
  backgroundMusic: null,
  battleMusic: null,
  isMuted: false, // Start with sound enabled
  
  // Setter functions
  setBackgroundMusic: (music: Howl) => set({ backgroundMusic: music }),
  
  setBattleMusic: (music: Howl) => set({ battleMusic: music }),
  
  setSound: (type: SoundType | string, sound: Howl) => set(state => ({
    sounds: {
      ...state.sounds,
      [type]: sound
    }
  })),
  
  // Legacy setters (for compatibility)
  setHitSound: (sound: Howl) => get().setSound("hit", sound),
  setSuccessSound: (sound: Howl) => get().setSound("success", sound),
  setBattleSound: (sound: Howl) => get().setBattleMusic(sound),
  setCardFlipSound: (sound: Howl) => get().setSound("cardFlip", sound),
  setVictorySound: (sound: Howl) => get().setSound("victory", sound),
  setGachaPullSound: (sound: Howl) => get().setSound("gachaPull", sound),
  
  // Toggle mute state
  toggleMute: () => {
    const { isMuted, backgroundMusic, battleMusic, sounds } = get();
    const newMutedState = !isMuted;
    
    // Mute background music
    if (backgroundMusic) {
      backgroundMusic.mute(newMutedState);
    }
    
    // Mute battle music
    if (battleMusic) {
      battleMusic.mute(newMutedState);
    }
    
    // Mute all sound effects
    Object.values(sounds).forEach(sound => {
      if (sound) {
        sound.mute(newMutedState);
      }
    });
    
    // Update the state
    set({ isMuted: newMutedState });
    
    // Log the change
    console.log(`Sound ${newMutedState ? 'muted' : 'unmuted'}`);
  },
  
  // Play background music
  playBackgroundMusic: () => {
    const { backgroundMusic, isMuted } = get();
    if (backgroundMusic) {
      backgroundMusic.mute(isMuted);
      
      if (!backgroundMusic.playing()) {
        backgroundMusic.play();
      }
    }
  },
  
  // Stop background music
  stopBackgroundMusic: () => {
    const { backgroundMusic } = get();
    if (backgroundMusic && backgroundMusic.playing()) {
      backgroundMusic.stop();
    }
  },
  
  // Play battle music
  playBattleMusic: () => {
    const { battleMusic, isMuted, backgroundMusic } = get();
    
    // Stop background music if it's playing
    if (backgroundMusic && backgroundMusic.playing()) {
      backgroundMusic.stop();
    }
    
    if (battleMusic) {
      battleMusic.mute(isMuted);
      
      if (!battleMusic.playing()) {
        battleMusic.play();
      }
    }
  },
  
  // Stop battle music
  stopBattleMusic: () => {
    const { battleMusic } = get();
    if (battleMusic && battleMusic.playing()) {
      battleMusic.stop();
    }
  },
  
  // Play any sound by type
  playSound: (type: SoundType | string) => {
    const { sounds, isMuted } = get();
    const sound = sounds[type];
    
    if (sound && !isMuted) {
      sound.play();
    }
  },
  
  // Convenience methods for common sounds
  playHit: () => get().playSound("hit"),
  playSuccess: () => get().playSound("success"),
  playCardFlip: () => get().playSound("cardFlip"),
  playVictory: () => {
    const { stopBattleMusic, playSound } = get();
    stopBattleMusic();
    playSound("victory");
  },
  playGachaPull: () => get().playSound("gachaPull"),
  playCombo: () => get().playSound("combo"),
  playError: () => get().playSound("error"),
  playNotification: () => get().playSound("notification"),
  playQuestComplete: () => get().playSound("quest"),
  playLevelUp: () => get().playSound("levelUp"),
  playUnlock: () => get().playSound("unlock")
}));