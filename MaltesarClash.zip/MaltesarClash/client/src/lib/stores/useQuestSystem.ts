import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';
import { useGame } from './useGame';
import { useCurrency } from './useCurrency';
import { useCardCollection } from './useCardCollection';

export type QuestType = 'daily' | 'weekly' | 'achievement';

export type QuestObjective = {
  type: 'battle_win' | 'card_collect' | 'currency_spend' | 'dungeon_complete' | 'login' | 'story_progress' | 'guild_activity';
  target: number;
  progress: number;
  specificId?: string; // For specific cards, dungeons, etc.
};

export interface QuestRewards {
  exp?: number;
  gold?: number;
  gems?: number;
  cardId?: string;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  type: QuestType;
  objective: QuestObjective;
  rewards: QuestRewards;
  completed: boolean;
  claimed: boolean;
  expiresAt?: number; // Timestamp for dailies and weeklies
  createdAt: number; // When the quest was assigned
}

export interface QuestSystemState {
  // Quest Collections
  dailyQuests: Quest[];
  weeklyQuests: Quest[];
  achievements: Quest[];
  
  // Quest Management
  addQuest: (quest: Omit<Quest, 'id' | 'completed' | 'claimed' | 'createdAt'>) => string;
  progressQuest: (objectiveType: QuestObjective['type'], amount?: number, specificId?: string) => void;
  completeQuest: (questId: string) => boolean;
  claimQuestReward: (questId: string) => boolean;
  resetDailyQuests: () => void;
  resetWeeklyQuests: () => void;
  
  // Utility Functions
  getQuestById: (questId: string) => Quest | undefined;
  getQuestsByType: (type: QuestType) => Quest[];
  getDailyQuestCompletion: () => number;
  getWeeklyQuestCompletion: () => number;
  getAchievementCompletion: () => number;
  getClaimableQuests: () => Quest[];
}

export const useQuestSystem = create<QuestSystemState>()(
  persist(
    (set, get) => ({
      // Quest Collections
      dailyQuests: [],
      weeklyQuests: [],
      achievements: [],
      
      // Quest Management Functions
      addQuest: (quest) => {
        const newId = nanoid();
        const newQuest: Quest = {
          ...quest,
          id: newId,
          completed: false,
          claimed: false,
          createdAt: Date.now(),
        };
        
        set((state) => {
          switch (quest.type) {
            case 'daily':
              // Set expiration to end of the current day (UTC)
              const dailyExpiration = new Date();
              dailyExpiration.setUTCHours(23, 59, 59, 999);
              newQuest.expiresAt = dailyExpiration.getTime();
              return { dailyQuests: [...state.dailyQuests, newQuest] };
              
            case 'weekly':
              // Set expiration to end of the current week (Sunday, UTC)
              const weeklyExpiration = new Date();
              const daysToSunday = 7 - weeklyExpiration.getUTCDay();
              weeklyExpiration.setUTCDate(weeklyExpiration.getUTCDate() + daysToSunday);
              weeklyExpiration.setUTCHours(23, 59, 59, 999);
              newQuest.expiresAt = weeklyExpiration.getTime();
              return { weeklyQuests: [...state.weeklyQuests, newQuest] };
              
            case 'achievement':
              return { achievements: [...state.achievements, newQuest] };
              
            default:
              return {};
          }
        });
        
        return newId;
      },
      
      progressQuest: (objectiveType, amount = 1, specificId) => {
        // Update all relevant quests with this objective type
        const updateQuests = (quests: Quest[]): Quest[] => {
          return quests.map(quest => {
            // Skip if already completed or claimed
            if (quest.completed || quest.claimed) return quest;
            
            // Check if this quest matches the objective type
            if (quest.objective.type !== objectiveType) return quest;
            
            // If specificId is required, check it matches
            if (quest.objective.specificId && specificId) {
              if (quest.objective.specificId !== specificId) return quest;
            }
            
            // Update progress
            const newProgress = Math.min(quest.objective.target, quest.objective.progress + amount);
            const completed = newProgress >= quest.objective.target;
            
            return {
              ...quest,
              objective: {
                ...quest.objective,
                progress: newProgress,
              },
              completed,
            };
          });
        };
        
        set(state => ({
          dailyQuests: updateQuests(state.dailyQuests),
          weeklyQuests: updateQuests(state.weeklyQuests),
          achievements: updateQuests(state.achievements),
        }));
      },
      
      completeQuest: (questId) => {
        const quest = get().getQuestById(questId);
        if (!quest) return false;
        
        set(state => {
          const updateQuestsList = (quests: Quest[]): Quest[] => {
            return quests.map(q => q.id === questId ? { ...q, completed: true } : q);
          };
          
          switch (quest.type) {
            case 'daily':
              return { dailyQuests: updateQuestsList(state.dailyQuests) };
            case 'weekly':
              return { weeklyQuests: updateQuestsList(state.weeklyQuests) };
            case 'achievement':
              return { achievements: updateQuestsList(state.achievements) };
            default:
              return {};
          }
        });
        
        return true;
      },
      
      claimQuestReward: (questId) => {
        const quest = get().getQuestById(questId);
        
        if (!quest || !quest.completed || quest.claimed) {
          return false;
        }
        
        // Apply rewards
        const { rewards } = quest;
        const { addCurrency } = useCurrency.getState();
        const { addExp } = useGame.getState();
        const { addCardToCollection } = useCardCollection.getState();
        
        if (rewards.exp) addExp(rewards.exp);
        if (rewards.gold) addCurrency(rewards.gold, "gold");
        if (rewards.gems) addCurrency(rewards.gems, "gems");
        if (rewards.cardId) addCardToCollection(rewards.cardId);
        
        // Mark quest as claimed
        set(state => {
          const updateQuestsList = (quests: Quest[]): Quest[] => {
            return quests.map(q => q.id === questId ? { ...q, claimed: true } : q);
          };
          
          switch (quest.type) {
            case 'daily':
              return { dailyQuests: updateQuestsList(state.dailyQuests) };
            case 'weekly':
              return { weeklyQuests: updateQuestsList(state.weeklyQuests) };
            case 'achievement':
              return { achievements: updateQuestsList(state.achievements) };
            default:
              return {};
          }
        });
        
        return true;
      },
      
      resetDailyQuests: () => {
        // Archive completed quests, remove uncompleted
        set(state => ({
          dailyQuests: [],
        }));
        
        // Generate new daily quests
        get().generateDailyQuests();
      },
      
      resetWeeklyQuests: () => {
        // Archive completed quests, remove uncompleted
        set(state => ({
          weeklyQuests: [],
        }));
        
        // Generate new weekly quests
        get().generateWeeklyQuests();
      },
      
      // Utility Functions
      getQuestById: (questId) => {
        const { dailyQuests, weeklyQuests, achievements } = get();
        
        const allQuests = [...dailyQuests, ...weeklyQuests, ...achievements];
        return allQuests.find(quest => quest.id === questId);
      },
      
      getQuestsByType: (type) => {
        switch (type) {
          case 'daily':
            return get().dailyQuests;
          case 'weekly':
            return get().weeklyQuests;
          case 'achievement':
            return get().achievements;
          default:
            return [];
        }
      },
      
      getDailyQuestCompletion: () => {
        const dailyQuests = get().dailyQuests;
        
        if (dailyQuests.length === 0) return 0;
        
        const completed = dailyQuests.filter(q => q.completed).length;
        return (completed / dailyQuests.length) * 100;
      },
      
      getWeeklyQuestCompletion: () => {
        const weeklyQuests = get().weeklyQuests;
        
        if (weeklyQuests.length === 0) return 0;
        
        const completed = weeklyQuests.filter(q => q.completed).length;
        return (completed / weeklyQuests.length) * 100;
      },
      
      getAchievementCompletion: () => {
        const achievements = get().achievements;
        
        if (achievements.length === 0) return 0;
        
        const completed = achievements.filter(q => q.completed).length;
        return (completed / achievements.length) * 100;
      },
      
      getClaimableQuests: () => {
        const { dailyQuests, weeklyQuests, achievements } = get();
        
        const allQuests = [...dailyQuests, ...weeklyQuests, ...achievements];
        return allQuests.filter(quest => quest.completed && !quest.claimed);
      },
      
      // Internal helper functions - not exposed in the store interface
      generateDailyQuests: () => {
        const dailyQuestTemplates = [
          // Battle quests
          {
            title: 'Daily Duelist',
            description: 'Win 3 battles today',
            type: 'daily' as QuestType,
            objective: {
              type: 'battle_win' as const,
              target: 3,
              progress: 0,
            },
            rewards: {
              exp: 50,
              gold: 100,
            }
          },
          
          // Currency quests
          {
            title: 'Big Spender',
            description: 'Spend 200 gold in the shop',
            type: 'daily' as QuestType,
            objective: {
              type: 'currency_spend' as const,
              target: 200,
              progress: 0,
            },
            rewards: {
              exp: 30,
              gems: 5,
            }
          },
          
          // Card quests
          {
            title: 'Card Collector',
            description: 'Collect 2 new cards today',
            type: 'daily' as QuestType,
            objective: {
              type: 'card_collect' as const,
              target: 2,
              progress: 0,
            },
            rewards: {
              exp: 40,
              gold: 75,
            }
          },
          
          // Dungeon quests
          {
            title: 'Dungeon Explorer',
            description: 'Complete any dungeon run',
            type: 'daily' as QuestType,
            objective: {
              type: 'dungeon_complete' as const,
              target: 1,
              progress: 0,
            },
            rewards: {
              exp: 60,
              gold: 150,
            }
          },
          
          // Guild quests
          {
            title: 'Guild Member',
            description: 'Participate in any guild activity',
            type: 'daily' as QuestType,
            objective: {
              type: 'guild_activity' as const,
              target: 1,
              progress: 0,
            },
            rewards: {
              exp: 25,
              gems: 3,
            }
          },
        ];
        
        // Select 3 random daily quests
        const selectedTemplates = [...dailyQuestTemplates]
          .sort(() => Math.random() - 0.5)
          .slice(0, 3);
        
        // Add the quests
        selectedTemplates.forEach(template => {
          get().addQuest(template);
        });
      },
      
      generateWeeklyQuests: () => {
        const weeklyQuestTemplates = [
          // Battle quests
          {
            title: 'Battle Master',
            description: 'Win 15 battles this week',
            type: 'weekly' as QuestType,
            objective: {
              type: 'battle_win' as const,
              target: 15,
              progress: 0,
            },
            rewards: {
              exp: 200,
              gold: 500,
              gems: 10,
            }
          },
          
          // Currency quests
          {
            title: 'Fortune Hunter',
            description: 'Earn 1000 gold this week',
            type: 'weekly' as QuestType,
            objective: {
              type: 'currency_spend' as const,
              target: 1000,
              progress: 0,
            },
            rewards: {
              exp: 150,
              gems: 15,
            }
          },
          
          // Dungeon quests
          {
            title: 'Dungeon Raider',
            description: 'Complete 5 dungeon runs',
            type: 'weekly' as QuestType,
            objective: {
              type: 'dungeon_complete' as const,
              target: 5,
              progress: 0,
            },
            rewards: {
              exp: 250,
              gold: 400,
              gems: 8,
            }
          },
          
          // Story quests
          {
            title: 'Story Seeker',
            description: 'Make progress in the story mode',
            type: 'weekly' as QuestType,
            objective: {
              type: 'story_progress' as const,
              target: 3,
              progress: 0,
            },
            rewards: {
              exp: 180,
              gold: 300,
              gems: 12,
            }
          },
          
          // Login quests
          {
            title: 'Regular Player',
            description: 'Log in for 5 days this week',
            type: 'weekly' as QuestType,
            objective: {
              type: 'login' as const,
              target: 5,
              progress: 0,
            },
            rewards: {
              exp: 100,
              gold: 250,
              gems: 10,
            }
          },
        ];
        
        // Select 3 random weekly quests
        const selectedTemplates = [...weeklyQuestTemplates]
          .sort(() => Math.random() - 0.5)
          .slice(0, 3);
        
        // Add the quests
        selectedTemplates.forEach(template => {
          get().addQuest(template);
        });
      },
      
      generateAchievements: () => {
        const achievementTemplates = [
          // Collection achievements
          {
            title: 'Card Enthusiast',
            description: 'Collect 10 different cards',
            type: 'achievement' as QuestType,
            objective: {
              type: 'card_collect' as const,
              target: 10,
              progress: 0,
            },
            rewards: {
              exp: 100,
              gold: 200,
              gems: 5,
            }
          },
          {
            title: 'Card Fanatic',
            description: 'Collect 25 different cards',
            type: 'achievement' as QuestType,
            objective: {
              type: 'card_collect' as const,
              target: 25,
              progress: 0,
            },
            rewards: {
              exp: 250,
              gold: 500,
              gems: 15,
            }
          },
          {
            title: 'Card Master',
            description: 'Collect 50 different cards',
            type: 'achievement' as QuestType,
            objective: {
              type: 'card_collect' as const,
              target: 50,
              progress: 0,
            },
            rewards: {
              exp: 500,
              gold: 1000,
              gems: 30,
            }
          },
          
          // Battle achievements
          {
            title: 'Battle Novice',
            description: 'Win 10 battles',
            type: 'achievement' as QuestType,
            objective: {
              type: 'battle_win' as const,
              target: 10,
              progress: 0,
            },
            rewards: {
              exp: 80,
              gold: 150,
            }
          },
          {
            title: 'Battle Expert',
            description: 'Win 50 battles',
            type: 'achievement' as QuestType,
            objective: {
              type: 'battle_win' as const,
              target: 50,
              progress: 0,
            },
            rewards: {
              exp: 200,
              gold: 400,
              gems: 10,
            }
          },
          {
            title: 'Battle Legend',
            description: 'Win 100 battles',
            type: 'achievement' as QuestType,
            objective: {
              type: 'battle_win' as const,
              target: 100,
              progress: 0,
            },
            rewards: {
              exp: 500,
              gold: 1000,
              gems: 25,
            }
          },
          
          // Story achievements
          {
            title: 'Story Beginner',
            description: 'Complete Chapter 1 of the story',
            type: 'achievement' as QuestType,
            objective: {
              type: 'story_progress' as const,
              target: 1,
              progress: 0,
            },
            rewards: {
              exp: 100,
              gold: 200,
            }
          },
          {
            title: 'Story Adventurer',
            description: 'Complete Chapter 3 of the story',
            type: 'achievement' as QuestType,
            objective: {
              type: 'story_progress' as const,
              target: 3,
              progress: 0,
            },
            rewards: {
              exp: 300,
              gold: 600,
              gems: 15,
            }
          },
          {
            title: 'Story Hero',
            description: 'Complete the main story',
            type: 'achievement' as QuestType,
            objective: {
              type: 'story_progress' as const,
              target: 5,
              progress: 0,
            },
            rewards: {
              exp: 1000,
              gold: 2000,
              gems: 50,
            }
          },
          
          // Dungeon achievements
          {
            title: 'Dungeon Beginner',
            description: 'Complete 5 dungeons',
            type: 'achievement' as QuestType,
            objective: {
              type: 'dungeon_complete' as const,
              target: 5,
              progress: 0,
            },
            rewards: {
              exp: 150,
              gold: 300,
              gems: 5,
            }
          },
          {
            title: 'Dungeon Expert',
            description: 'Complete 20 dungeons',
            type: 'achievement' as QuestType,
            objective: {
              type: 'dungeon_complete' as const,
              target: 20,
              progress: 0,
            },
            rewards: {
              exp: 400,
              gold: 800,
              gems: 20,
            }
          },
          {
            title: 'Dungeon Master',
            description: 'Complete 50 dungeons',
            type: 'achievement' as QuestType,
            objective: {
              type: 'dungeon_complete' as const,
              target: 50,
              progress: 0,
            },
            rewards: {
              exp: 800,
              gold: 1500,
              gems: 40,
            }
          },
        ];
        
        // Add all achievements
        achievementTemplates.forEach(template => {
          get().addQuest(template);
        });
      }
    }),
    {
      name: 'maltesar-quest-system',
      // Initialize with default quests on first load
      onRehydrateStorage: (state) => {
        return (rehydratedState, error) => {
          if (error || !rehydratedState) {
            console.error('Failed to rehydrate quest system store:', error);
            return;
          }
          
          // Check if we need to generate new daily quests
          if (rehydratedState.dailyQuests.length === 0) {
            setTimeout(() => {
              rehydratedState.generateDailyQuests();
            }, 100); // Small delay to ensure store is ready
          }
          
          // Check if we need to generate new weekly quests
          if (rehydratedState.weeklyQuests.length === 0) {
            setTimeout(() => {
              rehydratedState.generateWeeklyQuests();
            }, 100);
          }
          
          // Check if we need to generate achievements
          if (rehydratedState.achievements.length === 0) {
            setTimeout(() => {
              rehydratedState.generateAchievements();
            }, 100);
          }
          
          // Check for expired quests
          const now = Date.now();
          
          // Filter out expired daily quests
          const expiredDaily = rehydratedState.dailyQuests.some(q => q.expiresAt && q.expiresAt < now);
          if (expiredDaily) {
            setTimeout(() => {
              rehydratedState.resetDailyQuests();
            }, 100);
          }
          
          // Filter out expired weekly quests
          const expiredWeekly = rehydratedState.weeklyQuests.some(q => q.expiresAt && q.expiresAt < now);
          if (expiredWeekly) {
            setTimeout(() => {
              rehydratedState.resetWeeklyQuests();
            }, 100);
          }
        };
      },
    }
  )
);