import { useState, useCallback } from "react";
import { useGameState } from "@/lib/stores/useGameState";
import { useCardCollection } from "@/lib/stores/useCardCollection";
import { cards } from "@/data/cards";
import { Character, characters, CharacterRarity } from "@/data/characters";
import { useAudio } from "@/lib/stores/useAudio";
import { toast } from "sonner";

export type SummonType = "normal" | "premium";
export type SummonResult = {
  characterId: number;
  cardId: number;
  isNew: boolean;
  rarity: CharacterRarity;
};

export function useSummon() {
  const [isAnimating, setIsAnimating] = useState(false);
  const [results, setResults] = useState<SummonResult[]>([]);
  const { spendGold, spendGems, claimDailySummon, unlockCharacter } = useGameState();
  const { addCard, collection } = useCardCollection();
  const { playSuccess } = useAudio();
  
  // Helper to check if character is already owned
  const isCharacterOwned = useCallback((characterId: number) => {
    return useGameState.getState().unlockedCharacters.includes(characterId);
  }, []);
  
  // Helper to perform rarity weighting
  const getWeightedRarity = useCallback((type: SummonType): CharacterRarity => {
    const rand = Math.random();
    
    if (type === "normal") {
      if (rand < 0.80) return CharacterRarity.COMMON;
      if (rand < 0.95) return CharacterRarity.RARE;
      if (rand < 0.99) return CharacterRarity.EPIC;
      return CharacterRarity.LEGENDARY;
    } else {
      // Premium summon has better odds
      if (rand < 0.50) return CharacterRarity.COMMON;
      if (rand < 0.80) return CharacterRarity.RARE;
      if (rand < 0.95) return CharacterRarity.EPIC;
      return CharacterRarity.LEGENDARY;
    }
  }, []);
  
  // Get a random character of the specified rarity
  const getRandomCharacter = useCallback((rarity: CharacterRarity): Character => {
    const charactersOfRarity = characters.filter(c => c.rarity === rarity);
    const randomIndex = Math.floor(Math.random() * charactersOfRarity.length);
    return charactersOfRarity[randomIndex];
  }, []);
  
  // Get a random card for the character
  const getRandomCard = useCallback((characterId: number) => {
    const characterCards = cards.filter(c => c.characterId === characterId || c.characterId === 0);
    const randomIndex = Math.floor(Math.random() * characterCards.length);
    return characterCards[randomIndex];
  }, []);
  
  // Implement pity system (guaranteed rare+ every 10 pulls)
  const applyPitySystem = useCallback((results: SummonResult[]): SummonResult[] => {
    // Count how many pulls in this batch are common
    const commonCount = results.filter(r => r.rarity === CharacterRarity.COMMON).length;
    
    // If all pulls were common, upgrade one to rare
    if (commonCount === results.length && results.length > 0) {
      const indexToUpgrade = Math.floor(Math.random() * results.length);
      const upgradedChar = getRandomCharacter(CharacterRarity.RARE);
      
      results[indexToUpgrade] = {
        ...results[indexToUpgrade],
        characterId: upgradedChar.id,
        rarity: CharacterRarity.RARE
      };
    }
    
    return results;
  }, [getRandomCharacter]);
  
  // Perform a summon
  const performSummon = useCallback((type: SummonType, count: number) => {
    setIsAnimating(true);
    
    // Check if player can afford the summon
    let canAfford = false;
    
    if (type === "normal") {
      if (count === 1) {
        // Try daily free summon first
        if (claimDailySummon()) {
          canAfford = true;
        } else if (spendGold(100)) {
          canAfford = true;
        }
      } else if (spendGold(count * 80)) { // Bulk discount
        canAfford = true;
      }
    } else if (type === "premium") {
      if (count === 1 && spendGems(10)) {
        canAfford = true;
      } else if (count === 10 && spendGems(90)) { // Bulk discount
        canAfford = true;
      }
    }
    
    if (!canAfford) {
      setIsAnimating(false);
      toast.error("Not enough currency for summon");
      return;
    }
    
    // Perform the summons
    const newResults: SummonResult[] = [];
    
    for (let i = 0; i < count; i++) {
      const rarity = getWeightedRarity(type);
      const character = getRandomCharacter(rarity);
      const card = getRandomCard(character.id);
      
      const isNew = !isCharacterOwned(character.id);
      
      // Unlock character if new
      if (isNew) {
        unlockCharacter(character.id);
      }
      
      // Add card to collection
      addCard(card.id, character.id);
      
      newResults.push({
        characterId: character.id,
        cardId: card.id,
        isNew,
        rarity
      });
    }
    
    // Apply pity system
    const finalResults = applyPitySystem(newResults);
    
    // Update state
    setResults(finalResults);
    
    // Play success sound
    playSuccess();
    
    // Animation delay before completing
    setTimeout(() => {
      setIsAnimating(false);
    }, 2000);
    
  }, [getWeightedRarity, getRandomCharacter, getRandomCard, isCharacterOwned, unlockCharacter, 
      addCard, applyPitySystem, spendGold, spendGems, claimDailySummon, playSuccess]);
  
  return {
    performSummon,
    isAnimating,
    results,
    resetResults: () => setResults([])
  };
}
