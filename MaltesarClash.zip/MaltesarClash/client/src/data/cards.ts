import { Rarity } from "../lib/stores/useGameState";

export type CardEffect = {
  type: string;
  value?: number;
  duration?: number;
};

export interface CardType {
  id: string;
  name: string;
  description: string;
  type: "attack" | "defense" | "heal" | "buff" | "debuff";
  rarity: Rarity;
  manaCost: number;
  value: number;
  effect?: CardEffect;
  additionalEffects?: CardEffect[];
  isUltimate?: boolean;
  combos?: string[]; // IDs of cards this card combos with
  artwork: string; // SVG string
}

export interface CharacterCard {
  characterId: string;
  cardId: string;
}

// SVG card art
const cardArtSVGs = {
  fireball: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <circle cx="16" cy="16" r="12" fill="#FF5722"/>
    <circle cx="16" cy="16" r="9" fill="#FFAB91"/>
    <circle cx="14" cy="12" r="2" fill="#FFFFFF" opacity="0.7"/>
  </svg>`,
  
  shield: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 8 L16 4 L24 8 L24 16 C24 20 20 24 16 26 C12 24 8 20 8 16 Z" fill="#2196F3"/>
    <path d="M10 9 L16 6 L22 9 L22 16 C22 19 19 22 16 24 C13 22 10 19 10 16 Z" fill="#64B5F6"/>
  </svg>`,
  
  healing: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <circle cx="16" cy="16" r="12" fill="#4CAF50"/>
    <rect x="12" y="10" width="8" height="12" fill="#FFFFFF"/>
    <rect x="10" y="12" width="12" height="8" fill="#FFFFFF"/>
  </svg>`,
  
  lightning: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <polygon points="16,4 20,15 26,15 14,28 14,17 8,17" fill="#FFC107"/>
    <polygon points="17,8 19,14 23,14 14,24 14,18 12,18" fill="#FFFFFF" opacity="0.7"/>
  </svg>`,
  
  buff: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <circle cx="16" cy="16" r="12" fill="#9C27B0"/>
    <polygon points="16,8 19,14 25,14 20,18 22,24 16,20 10,24 12,18 7,14 13,14" fill="#E1BEE7"/>
  </svg>`,
  
  debuff: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <circle cx="16" cy="16" r="12" fill="#F44336"/>
    <rect x="10" y="15" width="12" height="2" fill="#FFFFFF"/>
  </svg>`,
  
  combo: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <circle cx="10" cy="16" r="6" fill="#3F51B5"/>
    <circle cx="22" cy="16" r="6" fill="#F44336"/>
    <circle cx="16" cy="16" r="4" fill="#9C27B0"/>
  </svg>`,
  
  ultimate: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="4" y="4" width="24" height="24" fill="#FF9800"/>
    <rect x="6" y="6" width="20" height="20" fill="#FFC107"/>
    <text x="16" y="21" font-family="Arial" font-size="14" text-anchor="middle" fill="#FFFFFF">U</text>
  </svg>`
};

// Base cards available to all characters
export const cards: CardType[] = [
  {
    id: "basic-strike",
    name: "Basic Strike",
    description: "A simple attack that deals moderate damage.",
    type: "attack",
    rarity: "Common",
    manaCost: 1,
    value: 5,
    artwork: cardArtSVGs.fireball
  },
  {
    id: "defensive-stance",
    name: "Defensive Stance",
    description: "Increase defense for 2 turns.",
    type: "defense",
    rarity: "Common",
    manaCost: 1,
    value: 3,
    effect: {
      type: "defense",
      value: 3,
      duration: 2
    },
    artwork: cardArtSVGs.shield
  },
  {
    id: "healing-touch",
    name: "Healing Touch",
    description: "Restore health to a character.",
    type: "heal",
    rarity: "Common",
    manaCost: 2,
    value: 8,
    artwork: cardArtSVGs.healing
  },
  {
    id: "power-up",
    name: "Power Up",
    description: "Increase attack strength for 2 turns.",
    type: "buff",
    rarity: "Common",
    manaCost: 1,
    value: 0,
    effect: {
      type: "attack",
      value: 3,
      duration: 2
    },
    artwork: cardArtSVGs.buff
  },
  {
    id: "weaken",
    name: "Weaken",
    description: "Reduce enemy's attack for 2 turns.",
    type: "debuff",
    rarity: "Common",
    manaCost: 1,
    value: 0,
    effect: {
      type: "attack",
      value: -3,
      duration: 2
    },
    artwork: cardArtSVGs.debuff
  },
  
  // Hamid special cards
  {
    id: "shield-wall",
    name: "Shield Wall",
    description: "Significantly increase defense and draw a card.",
    type: "defense",
    rarity: "Rare",
    manaCost: 2,
    value: 5,
    effect: {
      type: "defense",
      value: 5,
      duration: 3
    },
    additionalEffects: [
      {
        type: "draw",
        value: 1
      }
    ],
    artwork: cardArtSVGs.shield
  },
  {
    id: "endurance",
    name: "Endurance",
    description: "Restore health and gain defense.",
    type: "heal",
    rarity: "Rare",
    manaCost: 2,
    value: 6,
    effect: {
      type: "defense",
      value: 3,
      duration: 2
    },
    artwork: cardArtSVGs.healing
  },
  
  // Soraya special cards
  {
    id: "strategic-planning",
    name: "Strategic Planning",
    description: "Draw 2 cards and reduce their mana cost by 1.",
    type: "buff",
    rarity: "Epic",
    manaCost: 3,
    value: 0,
    additionalEffects: [
      {
        type: "draw",
        value: 2
      },
      {
        type: "mana",
        value: 1
      }
    ],
    artwork: cardArtSVGs.buff
  },
  {
    id: "critical-analysis",
    name: "Critical Analysis",
    description: "Apply a debuff that increases damage taken by the target.",
    type: "debuff",
    rarity: "Rare",
    manaCost: 2,
    value: 0,
    effect: {
      type: "defense",
      value: -3,
      duration: 3
    },
    artwork: cardArtSVGs.debuff
  },
  
  // Faris special cards
  {
    id: "power-strike",
    name: "Power Strike",
    description: "A powerful attack that deals high damage.",
    type: "attack",
    rarity: "Rare",
    manaCost: 2,
    value: 10,
    artwork: cardArtSVGs.fireball
  },
  {
    id: "rage",
    name: "Rage",
    description: "Increase attack but decrease defense.",
    type: "buff",
    rarity: "Rare",
    manaCost: 1,
    value: 0,
    effect: {
      type: "attack",
      value: 6,
      duration: 3
    },
    additionalEffects: [
      {
        type: "defense",
        value: -2,
        duration: 3
      }
    ],
    artwork: cardArtSVGs.buff
  },
  
  // Mr. Polycarp special cards
  {
    id: "wisdom-share",
    name: "Wisdom Share",
    description: "All allies gain attack and defense bonuses.",
    type: "buff",
    rarity: "Epic",
    manaCost: 3,
    value: 0,
    effect: {
      type: "attack",
      value: 3,
      duration: 3
    },
    additionalEffects: [
      {
        type: "defense",
        value: 3,
        duration: 3
      }
    ],
    artwork: cardArtSVGs.buff
  },
  
  // Ultimate cards
  {
    id: "ultimate-defense",
    name: "Ultimate Defense",
    description: "Block all incoming damage for 1 turn and counter-attack.",
    type: "defense",
    rarity: "Legendary",
    manaCost: 4,
    value: 10,
    effect: {
      type: "shield",
      value: 999,
      duration: 1
    },
    additionalEffects: [
      {
        type: "counter",
        value: 8,
        duration: 1
      }
    ],
    isUltimate: true,
    artwork: cardArtSVGs.ultimate
  },
  {
    id: "ultimate-strike",
    name: "Ultimate Strike",
    description: "Deal massive damage to an enemy and apply a debuff.",
    type: "attack",
    rarity: "Legendary",
    manaCost: 5,
    value: 20,
    effect: {
      type: "defense",
      value: -5,
      duration: 2
    },
    isUltimate: true,
    artwork: cardArtSVGs.ultimate
  },
  
  // Combo cards
  {
    id: "combo-attack",
    name: "Combo Attack",
    description: "Attack that gets stronger when played after 'Power Strike'.",
    type: "attack",
    rarity: "Epic",
    manaCost: 2,
    value: 8,
    combos: ["power-strike"],
    artwork: cardArtSVGs.combo
  }
];

// Mapping of characters to their special cards
export const characterCards: CharacterCard[] = [
  // Hamid cards
  { characterId: "hamid", cardId: "shield-wall" },
  { characterId: "hamid", cardId: "endurance" },
  { characterId: "hamid", cardId: "defensive-stance" },
  { characterId: "hamid", cardId: "basic-strike" },
  
  // Soraya cards
  { characterId: "soraya", cardId: "strategic-planning" },
  { characterId: "soraya", cardId: "critical-analysis" },
  { characterId: "soraya", cardId: "basic-strike" },
  { characterId: "soraya", cardId: "weaken" },
  
  // Faris cards
  { characterId: "faris", cardId: "power-strike" },
  { characterId: "faris", cardId: "rage" },
  { characterId: "faris", cardId: "combo-attack" },
  { characterId: "faris", cardId: "basic-strike" },
  
  // Mr. Polycarp cards
  { characterId: "polycarp", cardId: "wisdom-share" },
  { characterId: "polycarp", cardId: "healing-touch" },
  { characterId: "polycarp", cardId: "power-up" },
  { characterId: "polycarp", cardId: "basic-strike" },
  
  // Other characters
  { characterId: "emmanuel", cardId: "ultimate-defense" },
  { characterId: "layla", cardId: "healing-touch" },
  { characterId: "idris", cardId: "basic-strike" },
  { characterId: "zane", cardId: "weaken" },
  { characterId: "tariq", cardId: "ultimate-strike" }
];

// Helper functions
export const getCardById = (id: string): CardType | undefined => {
  return cards.find(card => card.id === id);
};

export const getCardsByRarity = (rarity: Rarity): CardType[] => {
  return cards.filter(card => card.rarity === rarity);
};

export const getCardsByCharacter = (characterId: string): CardType[] => {
  const cardIds = characterCards
    .filter(cc => cc.characterId === characterId)
    .map(cc => cc.cardId);
  
  return cards.filter(card => cardIds.includes(card.id));
};
