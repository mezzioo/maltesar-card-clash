export interface Enemy {
  id: string;
  name: string;
  description: string;
  hp: number;
  attack: number;
  defense: number;
  speed: number;
  element: string;
  expReward: number;
  currencyReward: number;
  difficulty: "easy" | "medium" | "hard" | "boss";
  attacks: EnemyAttack[];
  portrait: string; // SVG string
}

interface EnemyAttack {
  name: string;
  damage: number;
  effects?: {
    type: string;
    value: number;
    duration: number;
  }[];
}

// Enemy portraits as SVG strings
const enemyPortraits = {
  crashout: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="6" width="16" height="20" fill="#424242"/>
    <rect x="10" y="8" width="12" height="6" fill="#212121"/>
    <rect x="12" y="16" width="8" height="2" fill="#FF5252"/>
    <rect x="10" y="12" width="3" height="3" fill="#F44336"/>
    <rect x="19" y="12" width="3" height="3" fill="#F44336"/>
    <rect x="6" y="22" width="20" height="4" fill="#212121"/>
  </svg>`,
  
  tilawa: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="6" width="16" height="20" fill="#5D4037"/>
    <rect x="10" y="8" width="12" height="6" fill="#3E2723"/>
    <rect x="12" y="16" width="8" height="2" fill="#FFEB3B"/>
    <rect x="10" y="12" width="3" height="3" fill="#76FF03"/>
    <rect x="19" y="12" width="3" height="3" fill="#76FF03"/>
    <rect x="6" y="22" width="20" height="4" fill="#3E2723"/>
  </svg>`,
  
  history: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="6" width="16" height="20" fill="#7986CB"/>
    <rect x="10" y="8" width="12" height="6" fill="#3F51B5"/>
    <rect x="12" y="16" width="8" height="2" fill="#E0E0E0"/>
    <rect x="10" y="12" width="3" height="3" fill="#B39DDB"/>
    <rect x="19" y="12" width="3" height="3" fill="#B39DDB"/>
    <rect x="6" y="22" width="20" height="4" fill="#3F51B5"/>
  </svg>`,
  
  minion: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="11" y="8" width="10" height="16" fill="#616161"/>
    <rect x="13" y="10" width="6" height="4" fill="#424242"/>
    <rect x="13" y="15" width="6" height="2" fill="#E0E0E0"/>
    <rect x="9" y="22" width="14" height="2" fill="#424242"/>
  </svg>`
};

export const enemies: Enemy[] = [
  {
    id: "minion-weak",
    name: "Weak Crashout Minion",
    description: "A basic minion with limited capabilities.",
    hp: 30,
    attack: 5,
    defense: 3,
    speed: 8,
    element: "Neutral",
    expReward: 10,
    currencyReward: 5,
    difficulty: "easy",
    attacks: [
      {
        name: "Weak Punch",
        damage: 5
      }
    ],
    portrait: enemyPortraits.minion
  },
  {
    id: "minion-medium",
    name: "Crashout Minion",
    description: "A standard minion with moderate strength.",
    hp: 50,
    attack: 8,
    defense: 5,
    speed: 10,
    element: "Neutral",
    expReward: 20,
    currencyReward: 10,
    difficulty: "medium",
    attacks: [
      {
        name: "Punch",
        damage: 8
      },
      {
        name: "Intimidate",
        damage: 0,
        effects: [
          {
            type: "attack",
            value: -2,
            duration: 2
          }
        ]
      }
    ],
    portrait: enemyPortraits.minion
  },
  {
    id: "minion-strong",
    name: "Elite Crashout Minion",
    description: "A powerful minion with enhanced capabilities.",
    hp: 80,
    attack: 12,
    defense: 8,
    speed: 12,
    element: "Neutral",
    expReward: 35,
    currencyReward: 20,
    difficulty: "hard",
    attacks: [
      {
        name: "Strong Punch",
        damage: 12
      },
      {
        name: "Disrupt",
        damage: 5,
        effects: [
          {
            type: "defense",
            value: -3,
            duration: 2
          }
        ]
      }
    ],
    portrait: enemyPortraits.minion
  },
  {
    id: "mr-crashout",
    name: "Mr. Crashout",
    description: "The brutal leader of the Crashouts, capable of devastating attacks.",
    hp: 150,
    attack: 18,
    defense: 12,
    speed: 14,
    element: "Dark",
    expReward: 100,
    currencyReward: 75,
    difficulty: "boss",
    attacks: [
      {
        name: "Crushing Blow",
        damage: 20
      },
      {
        name: "Intimidating Presence",
        damage: 5,
        effects: [
          {
            type: "attack",
            value: -5,
            duration: 3
          }
        ]
      },
      {
        name: "Knockout",
        damage: 30
      }
    ],
    portrait: enemyPortraits.crashout
  },
  {
    id: "tilawa-crashout",
    name: "Tilawa Crashout",
    description: "A chanting Crashout that boosts allies and summons minions.",
    hp: 120,
    attack: 10,
    defense: 15,
    speed: 16,
    element: "Nature",
    expReward: 90,
    currencyReward: 65,
    difficulty: "boss",
    attacks: [
      {
        name: "Empowering Chant",
        damage: 0,
        effects: [
          {
            type: "attack",
            value: 5,
            duration: 3
          }
        ]
      },
      {
        name: "Nature's Wrath",
        damage: 15
      },
      {
        name: "Summon Minion",
        damage: 0
      }
    ],
    portrait: enemyPortraits.tilawa
  },
  {
    id: "history-crashout",
    name: "History Crashout",
    description: "A Crashout that creates illusions from the past to weaken enemies.",
    hp: 100,
    attack: 12,
    defense: 18,
    speed: 15,
    element: "Illusion",
    expReward: 85,
    currencyReward: 70,
    difficulty: "boss",
    attacks: [
      {
        name: "Past Trauma",
        damage: 10,
        effects: [
          {
            type: "defense",
            value: -4,
            duration: 3
          }
        ]
      },
      {
        name: "Illusion Strike",
        damage: 15
      },
      {
        name: "Memory Drain",
        damage: 8,
        effects: [
          {
            type: "attack",
            value: -3,
            duration: 2
          }
        ]
      }
    ],
    portrait: enemyPortraits.history
  }
];

// Helper function to get enemy by ID
export const getEnemyById = (id: string): Enemy | undefined => {
  return enemies.find(enemy => enemy.id === id);
};

// Get enemies by difficulty
export const getEnemiesByDifficulty = (difficulty: "easy" | "medium" | "hard" | "boss"): Enemy[] => {
  return enemies.filter(enemy => enemy.difficulty === difficulty);
};
