export interface DungeonReward {
  exp?: number;
  currency?: number;
  cards?: string[];
  characters?: string[];
}

export interface DungeonEvent {
  type: "battle" | "story" | "choice" | "reward";
  id: string;
  title: string;
  description: string;
  enemies?: string[]; // Enemy IDs for battle events
  dialogueId?: string; // Dialogue ID for story events
  choices?: {
    text: string;
    outcome: string;
    effect?: {
      type: string;
      value: number;
    };
  }[]; // Choices for choice events
  reward?: DungeonReward; // Rewards for reward events
}

export interface DungeonStage {
  name: string;
  description: string;
  events: DungeonEvent[];
}

export interface Dungeon {
  id: string;
  name: string;
  description: string;
  difficulty: 1 | 2 | 3 | 4 | 5; // 1 easiest, 5 hardest
  unlockRequirement: {
    type: "level" | "story" | "dungeon";
    value: number;
  };
  stages: DungeonStage[];
  reward: DungeonReward;
}

export const dungeons: Dungeon[] = [
  {
    id: "dungeon-1",
    name: "Academy Grounds",
    description: "The first area around the Academy, overrun with weak Crashouts.",
    difficulty: 1,
    unlockRequirement: {
      type: "level",
      value: 1 // Available from the start
    },
    stages: [
      {
        name: "Entrance",
        description: "The entrance to the Academy grounds.",
        events: [
          {
            type: "story",
            id: "intro-academy",
            title: "Academy Entrance",
            description: "You stand at the entrance to the Academy. The once peaceful grounds are now crawling with Crashouts.",
            dialogueId: "dungeon-1-intro"
          },
          {
            type: "battle",
            id: "battle-1",
            title: "First Encounter",
            description: "A weak Crashout minion notices you and attacks!",
            enemies: ["minion-weak"]
          },
          {
            type: "battle",
            id: "battle-2",
            title: "Continuing Forward",
            description: "More Crashouts block your path.",
            enemies: ["minion-weak", "minion-weak"]
          }
        ]
      },
      {
        name: "Courtyard",
        description: "The main courtyard of the Academy.",
        events: [
          {
            type: "story",
            id: "courtyard-story",
            title: "Courtyard",
            description: "You enter the Academy courtyard, once a place of learning and friendship.",
            dialogueId: "dungeon-1-courtyard"
          },
          {
            type: "battle",
            id: "battle-3",
            title: "Courtyard Defense",
            description: "A group of Crashouts tries to surround you!",
            enemies: ["minion-weak", "minion-medium"]
          },
          {
            type: "reward",
            id: "reward-1",
            title: "Hidden Cache",
            description: "You find a hidden cache of supplies left by Academy students.",
            reward: {
              currency: 20,
              exp: 15
            }
          }
        ]
      },
      {
        name: "Main Hall",
        description: "The final area of the first dungeon.",
        events: [
          {
            type: "story",
            id: "main-hall-story",
            title: "Main Hall",
            description: "You reach the main hall, where a stronger Crashout awaits.",
            dialogueId: "dungeon-1-main-hall"
          },
          {
            type: "battle",
            id: "battle-final",
            title: "Hall Guardian",
            description: "A powerful Crashout minion guards the hall!",
            enemies: ["minion-strong"]
          }
        ]
      }
    ],
    reward: {
      exp: 50,
      currency: 100,
      cards: ["power-up"]
    }
  },
  {
    id: "dungeon-2",
    name: "Library Wing",
    description: "The Academy's library, now a hunting ground for Crashouts.",
    difficulty: 2,
    unlockRequirement: {
      type: "dungeon",
      value: 1 // Requires completing dungeon 1
    },
    stages: [
      {
        name: "Library Entrance",
        description: "The entrance to the vast Academy library.",
        events: [
          {
            type: "story",
            id: "library-intro",
            title: "Library Entrance",
            description: "Books lie scattered on the floor. The once peaceful library is now eerily quiet.",
            dialogueId: "dungeon-2-intro"
          },
          {
            type: "battle",
            id: "battle-lib-1",
            title: "Ambush",
            description: "Crashouts spring from behind bookshelves!",
            enemies: ["minion-medium", "minion-weak"]
          }
        ]
      },
      {
        name: "Archives",
        description: "The ancient archives of the Academy.",
        events: [
          {
            type: "battle",
            id: "battle-lib-2",
            title: "Archive Defense",
            description: "Elite Crashouts guard important documents.",
            enemies: ["minion-strong", "minion-medium"]
          },
          {
            type: "choice",
            id: "archive-choice",
            title: "Ancient Tome",
            description: "You find an ancient tome with strange markings.",
            choices: [
              {
                text: "Study it carefully",
                outcome: "You gain insights into Crashout weaknesses.",
                effect: {
                  type: "buff",
                  value: 10
                }
              },
              {
                text: "Quickly scan through it",
                outcome: "You miss crucial details but save time.",
                effect: {
                  type: "heal",
                  value: 5
                }
              }
            ]
          }
        ]
      },
      {
        name: "Restricted Section",
        description: "The forbidden area of the library.",
        events: [
          {
            type: "story",
            id: "restricted-story",
            title: "Restricted Section",
            description: "You enter the forbidden section where the most dangerous knowledge is kept.",
            dialogueId: "dungeon-2-restricted"
          },
          {
            type: "battle",
            id: "battle-boss",
            title: "History Crashout",
            description: "The History Crashout appears, summoning illusions from the past!",
            enemies: ["history-crashout"]
          }
        ]
      }
    ],
    reward: {
      exp: 100,
      currency: 150,
      cards: ["critical-analysis"]
    }
  },
  {
    id: "dungeon-3",
    name: "Professors' Quarters",
    description: "The private chambers of Academy professors, now occupied by powerful Crashouts.",
    difficulty: 3,
    unlockRequirement: {
      type: "dungeon",
      value: 2 // Requires completing dungeon 2
    },
    stages: [
      {
        name: "Hallway",
        description: "The hallway leading to professors' chambers.",
        events: [
          {
            type: "story",
            id: "quarters-intro",
            title: "Professors' Hallway",
            description: "The portraits of famous professors watch you as you enter the hallway.",
            dialogueId: "dungeon-3-intro"
          },
          {
            type: "battle",
            id: "battle-hall-1",
            title: "Hallway Patrol",
            description: "Elite Crashouts patrol the hallway!",
            enemies: ["minion-strong", "minion-strong"]
          }
        ]
      },
      {
        name: "Study Rooms",
        description: "The professors' private study areas.",
        events: [
          {
            type: "battle",
            id: "battle-study-1",
            title: "Study Room Ambush",
            description: "Crashouts ambush you from the study rooms!",
            enemies: ["minion-strong", "minion-medium", "minion-medium"]
          },
          {
            type: "reward",
            id: "study-reward",
            title: "Professor's Safe",
            description: "You find a professor's hidden safe with valuable items.",
            reward: {
              currency: 100,
              cards: ["wisdom-share"]
            }
          }
        ]
      },
      {
        name: "Main Chamber",
        description: "The grand chamber where professors gather.",
        events: [
          {
            type: "story",
            id: "chamber-story",
            title: "Main Chamber",
            description: "You enter the grand chamber where Academy decisions are made.",
            dialogueId: "dungeon-3-chamber"
          },
          {
            type: "battle",
            id: "battle-boss-2",
            title: "Tilawa Crashout",
            description: "The Tilawa Crashout appears, chanting loudly to summon reinforcements!",
            enemies: ["tilawa-crashout", "minion-medium"]
          }
        ]
      }
    ],
    reward: {
      exp: 200,
      currency: 250,
      characters: ["zane"]
    }
  },
  {
    id: "dungeon-4",
    name: "Academy Peak",
    description: "The summit of the Academy pyramid, where the final battle awaits.",
    difficulty: 5,
    unlockRequirement: {
      type: "dungeon",
      value: 3 // Requires completing dungeon 3
    },
    stages: [
      {
        name: "Approach",
        description: "The winding path to the peak.",
        events: [
          {
            type: "story",
            id: "peak-intro",
            title: "The Approach",
            description: "You begin the treacherous climb to the Academy peak.",
            dialogueId: "dungeon-4-intro"
          },
          {
            type: "battle",
            id: "battle-approach-1",
            title: "Guardian Elites",
            description: "Elite Crashouts guard the path!",
            enemies: ["minion-strong", "minion-strong", "minion-strong"]
          }
        ]
      },
      {
        name: "Observatory",
        description: "The Academy observatory, just before the peak.",
        events: [
          {
            type: "battle",
            id: "battle-observatory",
            title: "Observatory Defense",
            description: "Powerful Crashouts defend the observatory.",
            enemies: ["history-crashout", "minion-strong"]
          },
          {
            type: "reward",
            id: "observatory-reward",
            title: "Telescope View",
            description: "Through the telescope, you spot a weakness in the final boss.",
            reward: {
              exp: 50,
              cards: ["ultimate-defense"]
            }
          }
        ]
      },
      {
        name: "Summit",
        description: "The final confrontation at the Academy peak.",
        events: [
          {
            type: "story",
            id: "summit-story",
            title: "The Summit",
            description: "You reach the summit, where Mr. Crashout awaits.",
            dialogueId: "dungeon-4-summit"
          },
          {
            type: "battle",
            id: "final-boss",
            title: "Mr. Crashout",
            description: "The leader of the Crashouts confronts you in a final battle!",
            enemies: ["mr-crashout"]
          }
        ]
      }
    ],
    reward: {
      exp: 500,
      currency: 1000,
      characters: ["tariq"],
      cards: ["ultimate-strike"]
    }
  }
];

// Helper functions
export const getDungeonById = (id: string): Dungeon | undefined => {
  return dungeons.find(dungeon => dungeon.id === id);
};

export const getAvailableDungeons = (playerLevel: number, completedDungeons: string[]): Dungeon[] => {
  return dungeons.filter(dungeon => {
    // Check level requirement
    if (dungeon.unlockRequirement.type === "level" && 
        playerLevel >= dungeon.unlockRequirement.value) {
      return true;
    }
    
    // Check dungeon completion requirement
    if (dungeon.unlockRequirement.type === "dungeon") {
      const requiredDungeonId = `dungeon-${dungeon.unlockRequirement.value}`;
      return completedDungeons.includes(requiredDungeonId);
    }
    
    return false;
  });
};
