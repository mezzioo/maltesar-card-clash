import { Rarity } from "../lib/stores/useGameState";

export interface Character {
  id: string;
  name: string;
  description: string;
  rarity: Rarity;
  baseHP: number;
  baseAttack: number;
  baseDefense: number;
  baseSpeed: number;
  element: string;
  skills: string[];
  catchphrase: string;
  unlockCondition?: string;
  portrait: string; // SVG path
}

// Character SVG portraits as strings
const portraitSVGs = {
  hamid: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#F5D393"/>
    <rect x="10" y="6" width="12" height="6" fill="#5D4037"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#03A9F4"/>
  </svg>`,
  
  soraya: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#FFCC80"/>
    <path d="M10 6 L22 6 L16 2 Z" fill="#8D6E63"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#4CAF50"/>
  </svg>`,
  
  faris: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#A1887F"/>
    <path d="M10 8 L14 2 L18 2 L22 8 Z" fill="#3E2723"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#F44336"/>
  </svg>`,
  
  polycarp: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#E0E0E0"/>
    <ellipse cx="16" cy="6" rx="8" ry="3" fill="#9E9E9E"/>
    <rect x="12" y="12" width="8" height="2" fill="#616161"/>
    <rect x="12" y="16" width="8" height="1" fill="#616161"/>
    <rect x="8" y="22" width="16" height="4" fill="#3F51B5"/>
  </svg>`,
  
  emmanuel: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#795548"/>
    <rect x="9" y="4" width="14" height="4" fill="#212121"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#FFFFFF"/>
    <rect x="18" y="12" width="2" height="2" fill="#FFFFFF"/>
    <rect x="8" y="22" width="16" height="4" fill="#4CAF50"/>
  </svg>`,
  
  layla: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#FFECB3"/>
    <path d="M8 8 L10 6 L22 6 L24 8 L24 12 L8 12 Z" fill="#FFA000"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#EC407A"/>
  </svg>`,
  
  idris: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="6" width="12" height="18" fill="#D7CCC8"/>
    <rect x="8" y="4" width="16" height="3" fill="#3E2723"/>
    <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
    <rect x="12" y="12" width="2" height="2" fill="#212121"/>
    <rect x="18" y="12" width="2" height="2" fill="#212121"/>
    <rect x="8" y="22" width="16" height="4" fill="#607D8B"/>
  </svg>`
};

export const characters: Character[] = [
  {
    id: "hamid",
    name: "Hamid",
    description: "A resilient student with a talent for defensive tactics.",
    rarity: "Common",
    baseHP: 120,
    baseAttack: 10,
    baseDefense: 15,
    baseSpeed: 8,
    element: "Earth",
    skills: ["Shield Wall", "Persistent Strike", "Endurance"],
    catchphrase: "I'll stand my ground!",
    portrait: portraitSVGs.hamid
  },
  {
    id: "soraya",
    name: "Soraya",
    description: "A brilliant strategist who excels at planning and execution.",
    rarity: "Rare",
    baseHP: 90,
    baseAttack: 12,
    baseDefense: 10,
    baseSpeed: 14,
    element: "Wind",
    skills: ["Strategic Planning", "Critical Analysis", "Team Buff"],
    catchphrase: "Every move has a counter!",
    portrait: portraitSVGs.soraya
  },
  {
    id: "faris",
    name: "Faris",
    description: "An aggressive fighter who delivers powerful attacks.",
    rarity: "Common",
    baseHP: 100,
    baseAttack: 18,
    baseDefense: 8,
    baseSpeed: 12,
    element: "Fire",
    skills: ["Power Strike", "Combo Attack", "Rage"],
    catchphrase: "Strike first, strike hard!",
    portrait: portraitSVGs.faris
  },
  {
    id: "polycarp",
    name: "Mr. Polycarp",
    description: "The wise instructor who strengthens allies with knowledge.",
    rarity: "Epic",
    baseHP: 110,
    baseAttack: 14,
    baseDefense: 12,
    baseSpeed: 9,
    element: "Light",
    skills: ["Wisdom Share", "Knowledge Barrier", "Enlightenment"],
    catchphrase: "Knowledge is your strongest weapon!",
    portrait: portraitSVGs.polycarp
  },
  {
    id: "emmanuel",
    name: "Mr. Emmanuel",
    description: "The strict but fair teacher who excels at balancing offense and defense.",
    rarity: "Epic",
    baseHP: 115,
    baseAttack: 15,
    baseDefense: 15,
    baseSpeed: 10,
    element: "Light",
    skills: ["Discipline", "Fair Judgment", "Balance Restoration"],
    catchphrase: "Order must be maintained!",
    portrait: portraitSVGs.emmanuel
  },
  {
    id: "layla",
    name: "Layla",
    description: "A supportive healer who can restore health and remove debuffs.",
    rarity: "Rare",
    baseHP: 85,
    baseAttack: 8,
    baseDefense: 12,
    baseSpeed: 16,
    element: "Water",
    skills: ["Healing Touch", "Purify", "Rejuvenation"],
    catchphrase: "Let me ease your pain!",
    portrait: portraitSVGs.layla
  },
  {
    id: "idris",
    name: "Idris",
    description: "A balanced fighter who adapts to different situations.",
    rarity: "Rare",
    baseHP: 105,
    baseAttack: 14,
    baseDefense: 14,
    baseSpeed: 14,
    element: "Neutral",
    skills: ["Adaptable Strike", "Situational Defense", "Quick Thinking"],
    catchphrase: "I'll adapt to any challenge!",
    portrait: portraitSVGs.idris
  },
  {
    id: "zane",
    name: "Zane",
    description: "A tech genius who uses gadgets to control the battlefield.",
    rarity: "Epic",
    baseHP: 95,
    baseAttack: 16,
    baseDefense: 10,
    baseSpeed: 15,
    element: "Electric",
    skills: ["Tech Barrier", "Disruptor Field", "System Hack"],
    catchphrase: "Technology is always the answer!",
    unlockCondition: "Complete Chapter 3",
    portrait: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="6" width="12" height="18" fill="#B3E5FC"/>
      <path d="M8 9 L16 4 L24 9 L24 12 L8 12 Z" fill="#0D47A1"/>
      <rect x="14" y="16" width="4" height="2" fill="#FF5252"/>
      <rect x="12" y="12" width="2" height="2" fill="#212121"/>
      <rect x="18" y="12" width="2" height="2" fill="#212121"/>
      <rect x="8" y="22" width="16" height="4" fill="#1976D2"/>
    </svg>`
  },
  {
    id: "tariq",
    name: "Tariq",
    description: "A mysterious student with unique abilities tied to shadows.",
    rarity: "Legendary",
    baseHP: 110,
    baseAttack: 18,
    baseDefense: 12,
    baseSpeed: 18,
    element: "Dark",
    skills: ["Shadow Strike", "Disappear", "Dark Embrace"],
    catchphrase: "The shadows reveal all truths...",
    unlockCondition: "Defeat Mr. Crashout",
    portrait: `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="6" width="12" height="18" fill="#455A64"/>
      <rect x="10" y="6" width="12" height="6" fill="#263238"/>
      <rect x="14" y="16" width="4" height="2" fill="#7E57C2"/>
      <rect x="12" y="12" width="2" height="2" fill="#B388FF"/>
      <rect x="18" y="12" width="2" height="2" fill="#B388FF"/>
      <rect x="8" y="22" width="16" height="4" fill="#512DA8"/>
    </svg>`
  }
];

// Helper functions
export const getCharacterById = (id: string): Character | undefined => {
  return characters.find(character => character.id === id);
};

export const getCharactersByRarity = (rarity: Rarity): Character[] => {
  return characters.filter(character => character.rarity === rarity);
};
